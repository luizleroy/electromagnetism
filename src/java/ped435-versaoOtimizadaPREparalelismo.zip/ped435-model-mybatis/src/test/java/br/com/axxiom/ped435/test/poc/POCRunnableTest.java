package br.com.axxiom.ped435.test.poc;

public class POCRunnableTest {
	public static void main(String[] args) {

		System.out.println("=== RunnableTest ===");

//		// Anonymous Runnable
//		Runnable r1 = new Runnable() {
//			@Override
//			public void run() {
//				System.out.println("Hello world one!");
//			}
//		};
//		r1.run();

		// Lambda Runnable
		Runnable runnable = () -> System.out.println("Hello world!");
		// Run em!
		runnable.run();
	}
}