package br.com.axxiom.ped435.test.poc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class POCHelloJava8 {
	public static void main(String[] args) {
		List<String> listString = new ArrayList<String>();
		listString.add("Primeiro");
		listString.add("Seu Lugar");
		listString.add("Sem Rir");
		listString.add("Sem chorar");

		System.out.println("Hello Word forEach");
		listString.forEach(value -> {
			System.out.println(value);
		});
		System.out.println("Antes: " + listString);
		Collections
				.sort(listString, (String p1, String p2) -> p1.compareTo(p2));
		System.out.println("Depois: " + listString);
	}
}

