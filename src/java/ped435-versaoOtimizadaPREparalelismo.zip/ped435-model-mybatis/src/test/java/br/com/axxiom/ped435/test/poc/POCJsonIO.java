package br.com.axxiom.ped435.test.poc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Ttemperatura;

import com.cedarsoftware.util.io.JsonReader;
import com.cedarsoftware.util.io.JsonWriter;

/**
 * @author lhipolito
 * TODO modificar para TestJsonIO e inserir a anotação @Test
 */

public class POCJsonIO {
	private static Logger log = Logger.getLogger(POCJsonIO.class);
//	public static void main(String[] args) throws Exception {
//		// Usage json-io can be used directly on JSON Strings or with Java's
//		// Streams.
//
//		// Example 1: String to Java object
//		Object objH = JsonReader.jsonToJava("[\"Hello, World\"]");
//		// This will convert the JSON String to a Java Object graph. In this
//		// case,
//		// it would consist of an Object[] of one String element.
//		System.out.println(JsonWriter.objectToJson(objH));
//		
//		// Example 2: Java object to JSON String
//		Ttemperatura temp = new Ttemperatura();
//		// Emp fetched from database
//		String json = JsonWriter.objectToJson(temp);
//		// This example will convert the Employee instance to a JSON String.
//		// If the JsonReader were used on this String, it would reconstitute a
//		// Java instance.
//		System.out.println("Example 2: Java object to JSON String\n"+json);
//		String relativePath = "src/test/resources/temperatura.json";
//		temp.setValTemperaturaMax(777.777);
//		createJSONFile(relativePath, temp);
//		Thread.sleep(1);
//		Object obj = loadJSONFile(relativePath);
//		System.out.println("((Ttemperatura) obj1).getValTemperaturaMax(): " + ((Ttemperatura) obj).getValTemperaturaMax());
//	}

	/**
	 * @param relativePath
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private static Object loadJSONFile(String relativePath)
			throws FileNotFoundException, IOException {
		// Exempl. conforme: https://code.google.com/p/json-io/
		// Example 3: InputStream to Java object
		JsonReader jsonReader = new JsonReader(new FileInputStream(new File(relativePath)));
		Object obj = jsonReader.readObject();
		jsonReader.close();
		// In this example, an InputStream (could be from a File, the Network,
		// etc.) is supplying an unknown amount of JSON. The JsonReader is used
		// to wrap the stream to parse it, and return the Java object graph it
		// represents.
		return obj;
	}
}
