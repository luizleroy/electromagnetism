package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tferiado;

public interface TferiadoMapper {
	
    int deleteByPrimaryKey(Integer codFeriado);
    
    int deleteByPrimaryKey(Integer codFeriado, SqlSession sqlSession);

    int insert(Tferiado record);
    
    int insert(Tferiado record, SqlSession sqlSession);

    int insertSelective(Tferiado record);
    
    int insertSelective(Tferiado record, SqlSession sqlSession);

    Tferiado selectByPrimaryKey(Integer codFeriado);
    
    Tferiado selectByPrimaryKey(Integer codFeriado, SqlSession sqlSession);
    
    Integer selectLastPrimaryKey();
    
    Integer selectLastPrimaryKey(SqlSession sqlSession);

    int updateByPrimaryKeySelective(Tferiado record);
    
    int updateByPrimaryKeySelective(Tferiado record, SqlSession sqlSession);

    int updateByPrimaryKey(Tferiado record);
    
    int updateByPrimaryKey(Tferiado record, SqlSession sqlSession);
}