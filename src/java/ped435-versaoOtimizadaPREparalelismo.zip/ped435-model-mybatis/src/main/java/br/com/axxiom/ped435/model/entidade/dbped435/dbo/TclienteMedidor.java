package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class TclienteMedidor {
    private Integer codCliente;

    private String codMedidor;

    public TclienteMedidor(Integer codCliente, String codMedidor) {
        this.codCliente = codCliente;
        this.codMedidor = codMedidor;
    }

    public TclienteMedidor() {
        super();
    }

    public Integer getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(Integer codCliente) {
        this.codCliente = codCliente;
    }

    public String getCodMedidor() {
        return codMedidor;
    }

    public void setCodMedidor(String codMedidor) {
        this.codMedidor = codMedidor;
    }
}