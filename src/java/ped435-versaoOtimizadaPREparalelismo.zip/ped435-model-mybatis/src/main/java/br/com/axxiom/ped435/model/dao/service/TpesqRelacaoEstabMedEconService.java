package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqRelacaoEstabMedEconMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqRelacaoEstabMedEcon;

public class TpesqRelacaoEstabMedEconService extends BaseDBCON435DAO implements TpesqRelacaoEstabMedEconMapper{

	@Override
	public int deleteByPrimaryKey(Integer codMedidaEconomica,
			Integer codEstabelecimento) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer codMedidaEconomica,
			Integer codEstabelecimento, SqlSession session) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqRelacaoEstabMedEcon record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqRelacaoEstabMedEcon record, SqlSession sqlSession) {
		int ret = 0;
		TpesqRelacaoEstabMedEconMapper mapper = sqlSession.getMapper(TpesqRelacaoEstabMedEconMapper.class);
		ret = mapper.insert(record);
		return ret;	
	}

	@Override
	public int insertSelective(TpesqRelacaoEstabMedEcon record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqRelacaoEstabMedEcon record,
			SqlSession session) {
		// TODO Auto-generated method stub
		return 0;
	}

}
