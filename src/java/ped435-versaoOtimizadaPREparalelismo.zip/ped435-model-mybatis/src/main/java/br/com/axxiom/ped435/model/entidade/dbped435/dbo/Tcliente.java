package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class Tcliente {
    private Integer codCliente;

    private String numInstalacao;

    private Double valConstPerdas;

    public Tcliente(Integer codCliente, String numInstalacao, Double valConstPerdas) {
        this.codCliente = codCliente;
        this.numInstalacao = numInstalacao;
        this.valConstPerdas = valConstPerdas;
    }

    public Tcliente() {
        super();
    }

    public Integer getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(Integer codCliente) {
        this.codCliente = codCliente;
    }

    public String getNumInstalacao() {
        return numInstalacao;
    }

    public void setNumInstalcao(String numInstalacao) {
        this.numInstalacao = numInstalacao;
    }

    public Double getValConstPerdas() {
        return valConstPerdas;
    }

    public void setValConstPerdas(Double valConstPerdas) {
        this.valConstPerdas = valConstPerdas;
    }

	public Boolean isNotNull() {
		return this != null;
	}
}