package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqGrauInstrucaoChefeMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqGrauInstrucaoChefe;

public class TpesqGrauInstrucaoChefeService extends BaseDBCON435DAO implements TpesqGrauInstrucaoChefeMapper{

	@Override
	public int deleteByPrimaryKey(String codGrauInstrucaoChefe) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(String codGrauInstrucaoChefe,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqGrauInstrucaoChefe record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqGrauInstrucaoChefe record, SqlSession sqlSession) {
		int ret = 0;
		TpesqGrauInstrucaoChefeMapper mapper = sqlSession.getMapper(TpesqGrauInstrucaoChefeMapper.class);
		ret = mapper.insert(record);
		return ret;		
	}

	@Override
	public int insertSelective(TpesqGrauInstrucaoChefe record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqGrauInstrucaoChefe record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqGrauInstrucaoChefe selectByPrimaryKey(
			String codGrauInstrucaoChefe) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqGrauInstrucaoChefe selectByPrimaryKey(
			String codGrauInstrucaoChefe, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqGrauInstrucaoChefe record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqGrauInstrucaoChefe record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqGrauInstrucaoChefe record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqGrauInstrucaoChefe record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
