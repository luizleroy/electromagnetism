package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TferiadoMapper;
import br.com.axxiom.ped435.model.dao.dbped435.dbo.TsituacaoMedicaoMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tferiado;

public class TferiadoService extends BaseDBPED435DAO implements TferiadoMapper{

	@Override
	public int deleteByPrimaryKey(Integer codFeriado) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
			ret = mapper.deleteByPrimaryKey(codFeriado);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}
	}
	
	@Override
	public int deleteByPrimaryKey(Integer codFeriado, SqlSession sqlSession) {
		
		int ret = 0;		
		TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
		ret = mapper.deleteByPrimaryKey(codFeriado);
		return ret;		
	}

	@Override
	public int insert(Tferiado record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insert(Tferiado record, SqlSession sqlSession) {
		int ret = 0;
		TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
		ret = mapper.insert(record);
		return ret;	
	}

	@Override
	public int insertSelective(Tferiado record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insertSelective(Tferiado record, SqlSession sqlSession) {
		int ret = 0;
		TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
		ret = mapper.insertSelective(record);
		return ret;	
	}

	@Override
	public Tferiado selectByPrimaryKey(Integer codFeriado) {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
			Tferiado obj = mapper.selectByPrimaryKey(codFeriado);
			return obj;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public Tferiado selectByPrimaryKey(Integer codSituacaoMedicao,
			SqlSession sqlSession) {
		TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
		Tferiado obj = mapper.selectByPrimaryKey(codSituacaoMedicao);
		return obj;
	}
	
	@Override
	public Integer selectLastPrimaryKey() {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
			Integer obj = mapper.selectLastPrimaryKey();
			if (obj == null)
				obj = 0;
			return obj;
		}finally{
			sqlSession.close();
		}		
	}

	@Override
	public Integer selectLastPrimaryKey(SqlSession sqlSession) {
		TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
		Integer obj = mapper.selectLastPrimaryKey();
		if (obj == null)
			obj = 0;
		return obj;	
	}

	@Override
	public int updateByPrimaryKeySelective(Tferiado record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int updateByPrimaryKeySelective(Tferiado record,
			SqlSession sqlSession) {
		int ret = 0;
		TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
		ret = mapper.updateByPrimaryKeySelective(record);
		return ret;		
	}

	@Override
	public int updateByPrimaryKey(Tferiado record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int updateByPrimaryKey(Tferiado record, SqlSession sqlSession) {
		int ret = 0;
		TferiadoMapper mapper = sqlSession.getMapper(TferiadoMapper.class);
		ret = mapper.updateByPrimaryKey(record);
		return ret;
	}
}
