package br.com.axxiom.ped435.model.dao.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.Grupo13FCMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidGrupo13FC;

public class TValidGrupo13FCService extends BaseDBPED435DAO implements
Grupo13FCMapper {
	@Override
	public List<TValidGrupo13FC> select() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<TValidGrupo13FC> obj = new ArrayList<TValidGrupo13FC>();
		try {
			Grupo13FCMapper mapper = sqlSession
					.getMapper(Grupo13FCMapper.class);
			obj = mapper.select();
			return obj;
		} finally {
			sqlSession.close();
		}
	}
}