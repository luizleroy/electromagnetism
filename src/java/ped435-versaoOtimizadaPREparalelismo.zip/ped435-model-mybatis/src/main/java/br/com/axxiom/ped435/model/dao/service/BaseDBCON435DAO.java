package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSessionFactory;

import br.com.axxiom.ped435.model.factory.ConnectionFactory;

public class BaseDBCON435DAO {
	
	protected static SqlSessionFactory sqlSessionFactory = null;
	
	static{
		if (sqlSessionFactory == null)
			sqlSessionFactory = ConnectionFactory.getSqlSessionFactory("DBCON435");
	}	
	
	public SqlSessionFactory getSqlSessionFacotry(){
		return sqlSessionFactory;
	}
}
