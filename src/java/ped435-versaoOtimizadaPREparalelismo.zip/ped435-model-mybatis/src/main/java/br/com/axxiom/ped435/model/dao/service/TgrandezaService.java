package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TgrandezaMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tgrandeza;

public class TgrandezaService extends BaseDBPED435DAO implements TgrandezaMapper{
	
	@Override
	public int deleteByPrimaryKey(Integer codGrandeza) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TgrandezaMapper mapper = sqlSession.getMapper(TgrandezaMapper.class);
			ret = mapper.deleteByPrimaryKey(codGrandeza);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}
	}

	@Override
	public int insert(Tgrandeza record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TgrandezaMapper mapper = sqlSession.getMapper(TgrandezaMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insert(Tgrandeza record, SqlSession sqlSession) {
		int ret = 0;
		TgrandezaMapper mapper = sqlSession.getMapper(TgrandezaMapper.class);
		ret = mapper.insert(record);
		return ret;		
	}

	@Override
	public int insertSelective(Tgrandeza record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TgrandezaMapper mapper = sqlSession.getMapper(TgrandezaMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public Tgrandeza selectByPrimaryKey(Integer codGrandeza) {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TgrandezaMapper mapper = sqlSession.getMapper(TgrandezaMapper.class);
			Tgrandeza obj = mapper.selectByPrimaryKey(codGrandeza);
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public Integer selectLastPrimaryKey() {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TgrandezaMapper mapper = sqlSession.getMapper(TgrandezaMapper.class);
			Integer obj = mapper.selectLastPrimaryKey();
			if (obj == null)
				obj = 0;
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public Integer selectLastPrimaryKey(SqlSession sqlSession) {
		
		TgrandezaMapper mapper = sqlSession.getMapper(TgrandezaMapper.class);
		Integer obj = mapper.selectLastPrimaryKey();
		if (obj == null)
			obj = 0;
		return obj;		
	}

	@Override
	public int updateByPrimaryKeySelective(Tgrandeza record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TgrandezaMapper mapper = sqlSession.getMapper(TgrandezaMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}

	@Override
	public int updateByPrimaryKey(Tgrandeza record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TgrandezaMapper mapper = sqlSession.getMapper(TgrandezaMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}		
	}	
}
