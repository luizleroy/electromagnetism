package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tcliente;

public interface TclienteMapper {
	
    int deleteByPrimaryKey(Integer codCliente);
    
    int deleteByPrimaryKey(Integer codCliente, SqlSession sqlSession);
    
    int insert(Tcliente record);
    
    int insert(Tcliente record, SqlSession sqlSession);

    int insertSelective(Tcliente record);
    
    int insertSelective(Tcliente record, SqlSession sqlSession);

    Tcliente selectByPrimaryKey(Integer codCliente);
    
    Tcliente selectByPrimaryKey(Integer codCliente, SqlSession sqlSession);
    
    Integer selectLastPrimaryKey();
    
    Integer selectLastPrimaryKey(SqlSession sqlSession);
    
    List<String> selectListClientesAprovadosRevisaoTarifaria();

    int updateByPrimaryKeySelective(Tcliente record);
    
    int updateByPrimaryKeySelective(Tcliente record, SqlSession sqlSession);

    int updateByPrimaryKey(Tcliente record);
    
    int updateByPrimaryKey(Tcliente record, SqlSession sqlSession);
}