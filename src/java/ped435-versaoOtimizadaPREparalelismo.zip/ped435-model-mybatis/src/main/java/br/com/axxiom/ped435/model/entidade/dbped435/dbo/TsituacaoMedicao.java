package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class TsituacaoMedicao {

	private Integer codSituacaoMedicao;
	private String tipSituacaoMedicao;
	private String desSituacaoMedicao;
	
	public TsituacaoMedicao(Integer codSituacaoMedicao, String tipSituacaoMedicao, String desSituacaoMedicao) {
        this.codSituacaoMedicao = codSituacaoMedicao;
        this.tipSituacaoMedicao = tipSituacaoMedicao;
        this.desSituacaoMedicao = desSituacaoMedicao;
    }

    public TsituacaoMedicao() {
        super();
    }

	public Integer getCodSituacaoMedicao() {
		return codSituacaoMedicao;
	}

	public void setCodSituacaoMedicao(Integer codSituacaoMedicao) {
		this.codSituacaoMedicao = codSituacaoMedicao;
	}

	public String getTipSituacaoMedicao() {
		return tipSituacaoMedicao;
	}

	public void setTipSituacaoMedicao(String tipSituacaoMedicao) {
		this.tipSituacaoMedicao = tipSituacaoMedicao;
	}

	public String getDesSituacaoMedicao() {
		return desSituacaoMedicao;
	}

	public void setDesSituacaoMedicao(String desSituacaoMedicao) {
		this.desSituacaoMedicao = desSituacaoMedicao;
	}
    
    
}
