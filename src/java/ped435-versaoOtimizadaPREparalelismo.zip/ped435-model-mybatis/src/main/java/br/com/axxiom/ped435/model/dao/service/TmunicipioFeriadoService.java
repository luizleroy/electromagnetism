package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TmunicipioFeriadoMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TmunicipioFeriado;

public class TmunicipioFeriadoService extends BaseDBPED435DAO implements TmunicipioFeriadoMapper{

	@Override
	public int deleteByPrimaryKey(Integer codMunicipio, Integer codFeriado) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmunicipioFeriadoMapper mapper = sqlSession.getMapper(TmunicipioFeriadoMapper.class);
			ret = mapper.deleteByPrimaryKey(codMunicipio, codFeriado);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}
	}
	
	@Override
	public int deleteByPrimaryKey(Integer codMunicipio, Integer codFeriado, SqlSession sqlSession) {
		int ret = 0;
		TmunicipioFeriadoMapper mapper = sqlSession.getMapper(TmunicipioFeriadoMapper.class);
		ret = mapper.deleteByPrimaryKey(codMunicipio, codFeriado);
		sqlSession.commit();
		return ret;		
	}

	@Override
	public int insert(TmunicipioFeriado record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmunicipioFeriadoMapper mapper = sqlSession.getMapper(TmunicipioFeriadoMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public int insert(TmunicipioFeriado record, SqlSession sqlSession) {		
		int ret = 0;	
		TmunicipioFeriadoMapper mapper = sqlSession.getMapper(TmunicipioFeriadoMapper.class);
		ret = mapper.insert(record);
		sqlSession.commit();
		return ret;
	}
	
	@Override
	public int insertSelective(TmunicipioFeriado record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmunicipioFeriadoMapper mapper = sqlSession.getMapper(TmunicipioFeriadoMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public int insertSelective(TmunicipioFeriado record, SqlSession sqlSession) {		
		int ret = 0;		
		TmunicipioFeriadoMapper mapper = sqlSession.getMapper(TmunicipioFeriadoMapper.class);
		ret = mapper.insertSelective(record);
		sqlSession.commit();
		return ret;			
	}
}
