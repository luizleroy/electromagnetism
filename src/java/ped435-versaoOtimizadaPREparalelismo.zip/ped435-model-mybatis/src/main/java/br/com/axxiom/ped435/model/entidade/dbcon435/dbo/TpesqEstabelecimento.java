package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqEstabelecimento {
    private Integer codEstabelecimento;

    private Integer numUnidadeConsumidora;

    private Integer numDdd;

    private String numTelefone;

    private String codDomicilio;

    private Double valAreaConstruida;

    private Integer numMoradores;

    private Integer numCriancasMenor10Anos;

    private Integer numAdolescentes;

    private Integer numAposentados;

    private Integer numEmpregadosDormem;

    private Integer numEmpregadosNaoDormem;

    private String codGrauInstrucaoChefe;

    private String codLocalUtilizadoComInd;

    private String codEscala;

    private String codRendaMensalFamiliar;

    private Integer numContribuintes;

    public TpesqEstabelecimento(Integer codEstabelecimento, Integer numUnidadeConsumidora, Integer numDdd, String numTelefone, String codDomicilio, Double valAreaConstruida, Integer numMoradores, Integer numCriancasMenor10Anos, Integer numAdolescentes, Integer numAposentados, Integer numEmpregadosDormem, Integer numEmpregadosNaoDormem, String codGrauInstrucaoChefe, String codLocalUtilizadoComInd, String codEscala, String codRendaMensalFamiliar, Integer numContribuintes) {
        this.codEstabelecimento = codEstabelecimento;
        this.numUnidadeConsumidora = numUnidadeConsumidora;
        this.numDdd = numDdd;
        this.numTelefone = numTelefone;
        this.codDomicilio = codDomicilio;
        this.valAreaConstruida = valAreaConstruida;
        this.numMoradores = numMoradores;
        this.numCriancasMenor10Anos = numCriancasMenor10Anos;
        this.numAdolescentes = numAdolescentes;
        this.numAposentados = numAposentados;
        this.numEmpregadosDormem = numEmpregadosDormem;
        this.numEmpregadosNaoDormem = numEmpregadosNaoDormem;
        this.codGrauInstrucaoChefe = codGrauInstrucaoChefe;
        this.codLocalUtilizadoComInd = codLocalUtilizadoComInd;
        this.codEscala = codEscala;
        this.codRendaMensalFamiliar = codRendaMensalFamiliar;
        this.numContribuintes = numContribuintes;
    }

    public TpesqEstabelecimento() {
        super();
    }

    public Integer getCodEstabelecimento() {
        return codEstabelecimento;
    }

    public void setCodEstabelecimento(Integer codEstabelecimento) {
        this.codEstabelecimento = codEstabelecimento;
    }

    public Integer getNumUnidadeConsumidora() {
        return numUnidadeConsumidora;
    }

    public void setNumUnidadeConsumidora(Integer numUnidadeConsumidora) {
        this.numUnidadeConsumidora = numUnidadeConsumidora;
    }

    public Integer getNumDdd() {
        return numDdd;
    }

    public void setNumDdd(Integer numDdd) {
        this.numDdd = numDdd;
    }

    public String getNumTelefone() {
        return numTelefone;
    }

    public void setNumTelefone(String numTelefone) {
        this.numTelefone = numTelefone;
    }

    public String getCodDomicilio() {
        return codDomicilio;
    }

    public void setCodDomicilio(String codDomicilio) {
        this.codDomicilio = codDomicilio;
    }

    public Double getValAreaConstruida() {
        return valAreaConstruida;
    }

    public void setValAreaConstruida(Double valAreaConstruida) {
        this.valAreaConstruida = valAreaConstruida;
    }

    public Integer getNumMoradores() {
        return numMoradores;
    }

    public void setNumMoradores(Integer numMoradores) {
        this.numMoradores = numMoradores;
    }

    public Integer getNumCriancasMenor10Anos() {
        return numCriancasMenor10Anos;
    }

    public void setNumCriancasMenor10Anos(Integer numCriancasMenor10Anos) {
        this.numCriancasMenor10Anos = numCriancasMenor10Anos;
    }

    public Integer getNumAdolescentes() {
        return numAdolescentes;
    }

    public void setNumAdolescentes(Integer numAdolescentes) {
        this.numAdolescentes = numAdolescentes;
    }

    public Integer getNumAposentados() {
        return numAposentados;
    }

    public void setNumAposentados(Integer numAposentados) {
        this.numAposentados = numAposentados;
    }

    public Integer getNumEmpregadosDormem() {
        return numEmpregadosDormem;
    }

    public void setNumEmpregadosDormem(Integer numEmpregadosDormem) {
        this.numEmpregadosDormem = numEmpregadosDormem;
    }

    public Integer getNumEmpregadosNaoDormem() {
        return numEmpregadosNaoDormem;
    }

    public void setNumEmpregadosNaoDormem(Integer numEmpregadosNaoDormem) {
        this.numEmpregadosNaoDormem = numEmpregadosNaoDormem;
    }

    public String getCodGrauInstrucaoChefe() {
        return codGrauInstrucaoChefe;
    }

    public void setCodGrauInstrucaoChefe(String codGrauInstrucaoChefe) {
        this.codGrauInstrucaoChefe = codGrauInstrucaoChefe;
    }

    public String getCodLocalUtilizadoComInd() {
        return codLocalUtilizadoComInd;
    }

    public void setCodLocalUtilizadoComInd(String codLocalUtilizadoComInd) {
        this.codLocalUtilizadoComInd = codLocalUtilizadoComInd;
    }

    public String getCodEscala() {
        return codEscala;
    }

    public void setCodEscala(String codEscala) {
        this.codEscala = codEscala;
    }

    public String getCodRendaMensalFamiliar() {
        return codRendaMensalFamiliar;
    }

    public void setCodRendaMensalFamiliar(String codRendaMensalFamiliar) {
        this.codRendaMensalFamiliar = codRendaMensalFamiliar;
    }

    public Integer getNumContribuintes() {
        return numContribuintes;
    }

    public void setNumContribuintes(Integer numContribuintes) {
        this.numContribuintes = numContribuintes;
    }
}