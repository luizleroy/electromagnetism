package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TparametroMedidorMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TparametroMedidor;

public class TparametroMedidorService extends BaseDBPED435DAO implements TparametroMedidorMapper {
	
	@Override
	public int deleteByPrimaryKey(Integer codParametroMedidor) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TparametroMedidorMapper mapper = sqlSession.getMapper(TparametroMedidorMapper.class);
			ret = mapper.deleteByPrimaryKey(codParametroMedidor);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}	
	}

	@Override
	public int insert(TparametroMedidor record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TparametroMedidorMapper mapper = sqlSession.getMapper(TparametroMedidorMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insert(TparametroMedidor record, SqlSession sqlSession) {
		int ret = 0;
		TparametroMedidorMapper mapper = sqlSession.getMapper(TparametroMedidorMapper.class);
		ret = mapper.insert(record);
		return ret;		
	}

	@Override
	public int insertSelective(TparametroMedidor record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TparametroMedidorMapper mapper = sqlSession.getMapper(TparametroMedidorMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}

	@Override
	public TparametroMedidor selectByPrimaryKey(Integer codParametroMedidor) {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TparametroMedidorMapper mapper = sqlSession.getMapper(TparametroMedidorMapper.class);
			TparametroMedidor obj = mapper.selectByPrimaryKey(codParametroMedidor);
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public Integer selectLastPrimaryKey() {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TparametroMedidorMapper mapper = sqlSession.getMapper(TparametroMedidorMapper.class);
			Integer obj = mapper.selectLastPrimaryKey();
			if (obj == null)
				obj = 0;
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public Integer selectLastPrimaryKey(SqlSession sqlSession) {
		TparametroMedidorMapper mapper = sqlSession.getMapper(TparametroMedidorMapper.class);
		Integer obj = mapper.selectLastPrimaryKey();
		if (obj == null)
			obj = 0;
		return obj;		
	}

	@Override
	public int updateByPrimaryKeySelective(TparametroMedidor record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TparametroMedidorMapper mapper = sqlSession.getMapper(TparametroMedidorMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public int updateByPrimaryKey(TparametroMedidor record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TparametroMedidorMapper mapper = sqlSession.getMapper(TparametroMedidorMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}	
}
