package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqEntrevistado {
    private Integer codEntrevistado;

    private String nomEntrevistado;

    private Integer numDdd;

    private String numTelefone;

    private String endEmail;

    public TpesqEntrevistado(Integer codEntrevistado, String nomEntrevistado, Integer numDdd, String numTelefone, String endEmail) {
        this.codEntrevistado = codEntrevistado;
        this.nomEntrevistado = nomEntrevistado;
        this.numDdd = numDdd;
        this.numTelefone = numTelefone;
        this.endEmail = endEmail;
    }

    public TpesqEntrevistado() {
        super();
    }

    public Integer getCodEntrevistado() {
        return codEntrevistado;
    }

    public void setCodEntrevistado(Integer codEntrevistado) {
        this.codEntrevistado = codEntrevistado;
    }

    public String getNomEntrevistado() {
        return nomEntrevistado;
    }

    public void setNomEntrevistado(String nomEntrevistado) {
        this.nomEntrevistado = nomEntrevistado;
    }

    public Integer getNumDdd() {
        return numDdd;
    }

    public void setNumDdd(Integer numDdd) {
        this.numDdd = numDdd;
    }

    public String getNumTelefone() {
        return numTelefone;
    }

    public void setNumTelefone(String numTelefone) {
        this.numTelefone = numTelefone;
    }

    public String getEndEmail() {
        return endEmail;
    }

    public void setEndEmail(String endEmail) {
        this.endEmail = endEmail;
    }
}