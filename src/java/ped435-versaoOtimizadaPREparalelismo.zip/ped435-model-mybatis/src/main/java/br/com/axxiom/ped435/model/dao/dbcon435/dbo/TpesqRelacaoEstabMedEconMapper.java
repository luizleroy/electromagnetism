package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqRelacaoEstabMedEcon;

public interface TpesqRelacaoEstabMedEconMapper {
	
    int deleteByPrimaryKey(@Param("codMedidaEconomica") Integer codMedidaEconomica, @Param("codEstabelecimento") Integer codEstabelecimento);
    
    int deleteByPrimaryKey(@Param("codMedidaEconomica") Integer codMedidaEconomica, @Param("codEstabelecimento") Integer codEstabelecimento, SqlSession sqlSession);

    int insert(TpesqRelacaoEstabMedEcon record);
    
    int insert(TpesqRelacaoEstabMedEcon record, SqlSession sqlSession);

    int insertSelective(TpesqRelacaoEstabMedEcon record);
    
    int insertSelective(TpesqRelacaoEstabMedEcon record, SqlSession sqlSession);
}