package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TclienteMedidorMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TclienteMedidor;

public class TclienteMedidorService extends BaseDBPED435DAO implements TclienteMedidorMapper{

	@Override
	public int deleteByPrimaryKey(Integer codCliente, String codMedidor) {
		
		SqlSession session = sqlSessionFactory.openSession();
		try{
			TclienteMedidorMapper mapper = session.getMapper(TclienteMedidorMapper.class);
			int ret = mapper.deleteByPrimaryKey(codCliente, codMedidor);
			session.commit();
			return ret;
		}finally{
			session.close();			
		}		
	}

	@Override
	public int insert(TclienteMedidor record) {
		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TclienteMedidorMapper mapper = sqlSession.getMapper(TclienteMedidorMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insert(TclienteMedidor record, SqlSession sqlSession) {
		
		int ret = 0;
		TclienteMedidorMapper mapper = sqlSession.getMapper(TclienteMedidorMapper.class);
		ret = mapper.insert(record);
		return ret;		
	}

	@Override
	public int insertSelective(TclienteMedidor record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TclienteMedidorMapper mapper = sqlSession.getMapper(TclienteMedidorMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
}
