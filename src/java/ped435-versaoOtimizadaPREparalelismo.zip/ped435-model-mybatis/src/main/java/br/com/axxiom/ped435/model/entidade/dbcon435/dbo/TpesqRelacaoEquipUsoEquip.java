package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqRelacaoEquipUsoEquip {
    private Integer codUsoEquipamento;

    private Integer codEquipamento;

    public TpesqRelacaoEquipUsoEquip(Integer codUsoEquipamento, Integer codEquipamento) {
        this.codUsoEquipamento = codUsoEquipamento;
        this.codEquipamento = codEquipamento;
    }

    public TpesqRelacaoEquipUsoEquip() {
        super();
    }

    public Integer getCodUsoEquipamento() {
        return codUsoEquipamento;
    }

    public void setCodUsoEquipamento(Integer codUsoEquipamento) {
        this.codUsoEquipamento = codUsoEquipamento;
    }

    public Integer getCodEquipamento() {
        return codEquipamento;
    }

    public void setCodEquipamento(Integer codEquipamento) {
        this.codEquipamento = codEquipamento;
    }
}