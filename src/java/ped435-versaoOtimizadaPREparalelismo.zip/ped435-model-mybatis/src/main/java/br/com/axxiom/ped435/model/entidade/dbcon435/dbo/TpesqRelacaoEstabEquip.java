package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqRelacaoEstabEquip {
    private Integer codEstabelecimento;

    private Integer codEquipamento;

    public TpesqRelacaoEstabEquip(Integer codEstabelecimento, Integer codEquipamento) {
        this.codEstabelecimento = codEstabelecimento;
        this.codEquipamento = codEquipamento;
    }

    public TpesqRelacaoEstabEquip() {
        super();
    }

    public Integer getCodEstabelecimento() {
        return codEstabelecimento;
    }

    public void setCodEstabelecimento(Integer codEstabelecimento) {
        this.codEstabelecimento = codEstabelecimento;
    }

    public Integer getCodEquipamento() {
        return codEquipamento;
    }

    public void setCodEquipamento(Integer codEquipamento) {
        this.codEquipamento = codEquipamento;
    }
}