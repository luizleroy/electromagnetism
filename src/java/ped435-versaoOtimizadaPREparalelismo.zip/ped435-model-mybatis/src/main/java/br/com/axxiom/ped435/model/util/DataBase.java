package br.com.axxiom.ped435.model.util;

import java.util.ResourceBundle;

/**
 * Classe Config - Esta classe é um FACADE para a classe ResourceBundle
 * 
 * @author luizleroy <br/>
 * Axxiom Solucoes Tecnologicas S.A.<br/>
 * www.axxiom.com.br
 */
public class DataBase {

    private static final ResourceBundle bundle = ResourceBundle.getBundle("database");

    public static String getKey(String key) {

        return bundle.getString(key);
    }    
    
    public static boolean containsKey(String key) {
        return bundle.containsKey(key);
    }
}