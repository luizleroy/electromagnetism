package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqEquipamentoMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEquipamento;

public class TpesqEquipamentoService extends BaseDBCON435DAO implements TpesqEquipamentoMapper{

	@Override
	public int deleteByPrimaryKey(Integer codEquipamento) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer codEquipamento, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEquipamento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEquipamento record, SqlSession sqlSession) {
		
		int ret = 0;
		TpesqEquipamentoMapper mapper = sqlSession.getMapper(TpesqEquipamentoMapper.class);
		ret = mapper.insert(record);
		return ret;
	}

	@Override
	public int insertSelective(TpesqEquipamento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqEquipamento record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqEquipamento selectByPrimaryKey(Integer codEquipamento) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqEquipamento selectByPrimaryKey(Integer codEquipamento,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEquipamento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEquipamento record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEquipamento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEquipamento record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
