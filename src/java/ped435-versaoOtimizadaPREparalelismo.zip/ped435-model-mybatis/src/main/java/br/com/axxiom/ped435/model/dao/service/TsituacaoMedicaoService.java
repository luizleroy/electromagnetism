package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TsituacaoMedicaoMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TsituacaoMedicao;

public class TsituacaoMedicaoService extends BaseDBPED435DAO implements TsituacaoMedicaoMapper{

	@Override
	public int deleteByPrimaryKey(Integer codSituacaoMedicao) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
			ret = mapper.deleteByPrimaryKey(codSituacaoMedicao);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}		
	}

	@Override
	public int deleteByPrimaryKey(Integer codSituacaoMedicao, SqlSession sqlSession) {
		int ret = 0;
		TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
		ret = mapper.deleteByPrimaryKey(codSituacaoMedicao);
		return ret;	
	}

	@Override
	public int insert(TsituacaoMedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public int insert(TsituacaoMedicao record, SqlSession sqlSession) {
		int ret = 0;
		TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
		ret = mapper.insert(record);
		return ret;	
	}

	@Override
	public int insertSelective(TsituacaoMedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}

	@Override
	public int insertSelective(TsituacaoMedicao record, SqlSession sqlSession) {
		int ret = 0;
		TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
		ret = mapper.insertSelective(record);
		return ret;	
	}

	@Override
	public TsituacaoMedicao selectByPrimaryKey(Integer codSituacaoMedicao) {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
			TsituacaoMedicao obj = mapper.selectByPrimaryKey(codSituacaoMedicao);
			return obj;
		}finally{
			sqlSession.close();
		}	
	}

	@Override
	public TsituacaoMedicao selectByPrimaryKey(Integer codSituacaoMedicao,
			SqlSession sqlSession) {
		TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
		TsituacaoMedicao obj = mapper.selectByPrimaryKey(codSituacaoMedicao);
		return obj;
	}

	@Override
	public Integer selectLastPrimaryKey() {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
			Integer obj = mapper.selectLastPrimaryKey();
			if (obj == null)
				obj = 0;
			return obj;
		}finally{
			sqlSession.close();
		}		
	}

	@Override
	public Integer selectLastPrimaryKey(SqlSession sqlSession) {
		TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
		Integer obj = mapper.selectLastPrimaryKey();
		if (obj == null)
			obj = 0;
		return obj;	
	}

	@Override
	public int updateByPrimaryKeySelective(TsituacaoMedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}

	@Override
	public int updateByPrimaryKeySelective(TsituacaoMedicao record,
			SqlSession sqlSession) {
		int ret = 0;
		TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
		ret = mapper.updateByPrimaryKeySelective(record);
		return ret;		
	}

	@Override
	public int updateByPrimaryKey(TsituacaoMedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}		
	}

	@Override
	public int updateByPrimaryKey(TsituacaoMedicao record, SqlSession sqlSession) {
		int ret = 0;
		TsituacaoMedicaoMapper mapper = sqlSession.getMapper(TsituacaoMedicaoMapper.class);
		ret = mapper.updateByPrimaryKey(record);
		return ret;
	}

}
