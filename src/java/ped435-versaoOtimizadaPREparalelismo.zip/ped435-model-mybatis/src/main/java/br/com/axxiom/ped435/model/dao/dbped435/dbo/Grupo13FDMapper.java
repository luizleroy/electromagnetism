package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import java.util.List;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidGrupo13FD;

public interface Grupo13FDMapper {
	List<TValidGrupo13FD> select();
}
