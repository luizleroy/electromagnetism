package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class TValidGrupo13 {
	// private Double input:::
	private Double identificadorCliente;
	private Double diaMedicao;
	private Double demandaMedia;
	private Double demandaMaxima;
	private Double potInstalada;
	// private Double output:::
	private Double fatorDeCarga;
	private Double fatorDeDemanda;

	public TValidGrupo13(Double identificadorCliente, Double diaMedicao,
			Double demandaMedia, Double demandaMaxima, Double potInstalada, Double fatorDeCarga, Double fatorDeDemanda) {
		this.identificadorCliente = identificadorCliente;
		this.diaMedicao = diaMedicao;
		this.demandaMedia = demandaMedia;
		this.demandaMaxima = demandaMaxima;
		this.potInstalada = potInstalada;
		this.fatorDeCarga = fatorDeCarga;
		this.fatorDeDemanda = fatorDeDemanda;
	}

	public TValidGrupo13() {
		super();
	}

	public Double getIdentificadorCliente() {
		return identificadorCliente;
	}

	public void setIdentificadorCliente(Double identificadorCliente) {
		this.identificadorCliente = identificadorCliente;
	}

	public Double getDiaMedicao() {
		return diaMedicao;
	}

	public void setDiaMedicao(Double diaMedicao) {
		this.diaMedicao = diaMedicao;
	}

	public Double getDemandaMedia() {
		return demandaMedia;
	}

	public void setDemandaMedia(Double demandaMedia) {
		this.demandaMedia = demandaMedia;
	}

	public Double getDemandaMaxima() {
		return demandaMaxima;
	}

	public void setDemandaMaxima(Double demandaMaxima) {
		this.demandaMaxima = demandaMaxima;
	}

	public Double getPotInstalada() {
		return potInstalada;
	}

	public void setPotInstalada(Double potInstalada) {
		this.potInstalada = potInstalada;
	}

	public Double getFatorDeCarga() {
		return fatorDeCarga;
	}
	
	public Double getFatorDeDemanda() {
		return fatorDeDemanda;
	}

	public void setFatorDeCarga(Double fatorDeCarga) {
		this.fatorDeCarga = fatorDeCarga;
	}
	
	public void setFatorDeDemanda(Double fatorDeDemanda) {
		this.fatorDeDemanda = fatorDeDemanda;
	}
}
