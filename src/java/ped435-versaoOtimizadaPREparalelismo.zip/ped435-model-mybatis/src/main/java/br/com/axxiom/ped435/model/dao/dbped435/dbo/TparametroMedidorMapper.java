package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TparametroMedidor;

public interface TparametroMedidorMapper {
    int deleteByPrimaryKey(Integer codParametroMedidor);

    int insert(TparametroMedidor record);
    
    int insert(TparametroMedidor record, SqlSession sqlSession);

    int insertSelective(TparametroMedidor record);

    TparametroMedidor selectByPrimaryKey(Integer codParametroMedidor);
    
    Integer selectLastPrimaryKey();
    
    Integer selectLastPrimaryKey(SqlSession sqlSession);

    int updateByPrimaryKeySelective(TparametroMedidor record);

    int updateByPrimaryKey(TparametroMedidor record);
}