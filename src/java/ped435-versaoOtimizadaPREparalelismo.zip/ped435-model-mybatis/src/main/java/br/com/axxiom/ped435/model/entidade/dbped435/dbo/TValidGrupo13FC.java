package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class TValidGrupo13FC {
	// private Double input:::
	private Double identificadorCliente;
	private Double diaMedicao;
	private Double demandaMedia;
	private Double demandaMaxima;
	private Double potInstalada;
	// private Double output:::
	private Double fatorDeCarga;

	public TValidGrupo13FC(Double identificadorCliente, Double diaMedicao,
			Double demandaMedia, Double demandaMaxima, Double potInstalada, Double fatorDeCarga) {
		this.identificadorCliente = identificadorCliente;
		this.diaMedicao = diaMedicao;
		this.demandaMedia = demandaMedia;
		this.demandaMaxima = demandaMaxima;
		this.potInstalada = potInstalada;
		this.fatorDeCarga = fatorDeCarga;
	}

	public TValidGrupo13FC() {
		super();
	}

	public Double getIdentificadorCliente() {
		return identificadorCliente;
	}

	public void setIdentificadorCliente(Double identificadorCliente) {
		this.identificadorCliente = identificadorCliente;
	}

	public Double getDiaMedicao() {
		return diaMedicao;
	}

	public void setDiaMedicao(Double diaMedicao) {
		this.diaMedicao = diaMedicao;
	}

	public Double getDemandaMedia() {
		return demandaMedia;
	}

	public void setDemandaMedia(Double demandaMedia) {
		this.demandaMedia = demandaMedia;
	}

	public Double getDemandaMaxima() {
		return demandaMaxima;
	}

	public void setDemandaMaxima(Double demandaMaxima) {
		this.demandaMaxima = demandaMaxima;
	}

	public Double getPotInstalada() {
		return potInstalada;
	}

	public void setPotInstalada(Double potInstalada) {
		this.potInstalada = potInstalada;
	}

	public Double getFatorDeCarga() {
		return fatorDeCarga;
	}

	public void setFatorDeCarga(Double fatorDeCarga) {
		this.fatorDeCarga = fatorDeCarga;
	}
}
