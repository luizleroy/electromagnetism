/**
 * 
 */
package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

import java.lang.reflect.Field;

/**
 * @author lhipolito Luiz Le Roy Dados de entrada da RNA.
 * 
 */
public class Sample {
	// OBS: não modificar o TIPO E A ORDEM de precedência SEM ATUALIZAR
	// toString()!
	public static Perfil perfil = Perfil.ALL;
	private double pInst;
	private double dDmax;
	private double dDmed;
	private double FD;
	private double FC;
	private double temperatura;
	private long calendar;

	public double getpInst() {
		return pInst;
	}

	public void setpInst(double pInst) {
		this.pInst = pInst;
	}

	public double getdDmax() {
		return dDmax;
	}

	public void setdDmax(double dDmax) {
		this.dDmax = dDmax;
	}

	public double getdDmed() {
		return dDmed;
	}

	public void setdDmed(double dDmed) {
		this.dDmed = dDmed;
	}

	public double getFD() {
		return FD;
	}

	public void setFD(double fD) {
		FD = fD;
	}

	public double getFC() {
		return FC;
	}

	public void setFC(double fC) {
		FC = fC;
	}

	public double getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(double temperatura) {
		this.temperatura = temperatura;
	}

	public long getCalendar() {
		return calendar;
	}

	public void setCalendar(long calendar) {
		this.calendar = calendar;
	}

	@Override
	public String toString() {
		Field[] fields = Sample.class.getDeclaredFields();
		StringBuilder field = new StringBuilder("|");
		for (int i = 0; i < fields.length; i++) {
			field.append(fields[i].getName());
			field.append("=%s|");
		}
		// perfil
		// pInst;
		// dDmax;
		// dDmed;
		// FD;
		// FC;
		// temperatura;
		// calendar;
		return String.format(field.toString(), perfil, pInst, dDmax, dDmed, FD,
				FC, temperatura, calendar);
	}
}
