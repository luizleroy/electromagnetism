/**
 * 
 */
package br.com.axxiom.ped435.model.dao.enums;

/**
 * @author luizleroy
 *
 */
public enum ClientDataAccess {
	DES_CLASSE, DES_FAIXA_DEFINITIVA
}
