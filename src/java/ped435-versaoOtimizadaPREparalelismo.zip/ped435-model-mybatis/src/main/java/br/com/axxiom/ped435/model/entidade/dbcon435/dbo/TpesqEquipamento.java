package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqEquipamento {
    private Integer codEquipamento;

    private String desEquipamento;

    public TpesqEquipamento(Integer codEquipamento, String desEquipamento) {
        this.codEquipamento = codEquipamento;
        this.desEquipamento = desEquipamento;
    }

    public TpesqEquipamento() {
        super();
    }

    public Integer getCodEquipamento() {
        return codEquipamento;
    }

    public void setCodEquipamento(Integer codEquipamento) {
        this.codEquipamento = codEquipamento;
    }

    public String getDesEquipamento() {
        return desEquipamento;
    }

    public void setDesEquipamento(String desEquipamento) {
        this.desEquipamento = desEquipamento;
    }
}