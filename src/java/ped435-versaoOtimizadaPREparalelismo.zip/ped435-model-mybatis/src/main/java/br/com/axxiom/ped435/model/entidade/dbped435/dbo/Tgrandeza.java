package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class Tgrandeza {
	
    private Integer codGrandeza;
    private String sigGrandeza;
    private String desGrandeza;
    
    public Tgrandeza(Integer codGrandeza, String sigGrandeza, String desGrandeza) {
        this.codGrandeza = codGrandeza;
        this.setSigGrandeza(sigGrandeza);
        this.setDesGrandeza(desGrandeza);
    }

    public Tgrandeza() {
        super();
    }

    public Integer getCodGrandeza() {
        return codGrandeza;
    }

    public void setCodGrandeza(Integer codGrandeza) {
        this.codGrandeza = codGrandeza;
    }

	public String getSigGrandeza() {
		return sigGrandeza;
	}

	public void setSigGrandeza(String sigGrandeza) {
		this.sigGrandeza = sigGrandeza;
	}

	public String getDesGrandeza() {
		return desGrandeza;
	}

	public void setDesGrandeza(String desGrandeza) {
		this.desGrandeza = desGrandeza;
	}
    
    
}