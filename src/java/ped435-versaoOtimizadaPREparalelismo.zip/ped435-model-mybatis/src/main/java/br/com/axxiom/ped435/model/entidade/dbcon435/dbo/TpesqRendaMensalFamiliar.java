package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqRendaMensalFamiliar {
    private String codRendaMensalFamiliar;

    private String desRendaMensalFamiliar;

    public TpesqRendaMensalFamiliar(String codRendaMensalFamiliar, String desRendaMensalFamiliar) {
        this.codRendaMensalFamiliar = codRendaMensalFamiliar;
        this.desRendaMensalFamiliar = desRendaMensalFamiliar;
    }

    public TpesqRendaMensalFamiliar() {
        super();
    }

    public String getCodRendaMensalFamiliar() {
        return codRendaMensalFamiliar;
    }

    public void setCodRendaMensalFamiliar(String codRendaMensalFamiliar) {
        this.codRendaMensalFamiliar = codRendaMensalFamiliar;
    }

    public String getDesRendaMensalFamiliar() {
        return desRendaMensalFamiliar;
    }

    public void setDesRendaMensalFamiliar(String desRendaMensalFamiliar) {
        this.desRendaMensalFamiliar = desRendaMensalFamiliar;
    }
}