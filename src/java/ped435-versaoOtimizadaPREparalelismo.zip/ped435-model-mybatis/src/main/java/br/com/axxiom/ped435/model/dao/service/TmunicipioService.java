package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TmunicipioMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmunicipio;

public class TmunicipioService extends BaseDBPED435DAO implements TmunicipioMapper{

	@Override
	public int deleteByPrimaryKey(Integer codMunicipio) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
			ret = mapper.deleteByPrimaryKey(codMunicipio);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}
	}
	
	@Override
	public int deleteByPrimaryKey(Integer codMunicipio, SqlSession sqlSession) {
		
		int ret = 0;		
		TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
		ret = mapper.deleteByPrimaryKey(codMunicipio);
		return ret;		
	}

	@Override
	public int insert(Tmunicipio record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public int insert(Tmunicipio record, SqlSession sqlSession) {
		int ret = 0;
		TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
		ret = mapper.insert(record);
		return ret;	
	}

	@Override
	public int insertSelective(Tmunicipio record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insertSelective(Tmunicipio record, SqlSession sqlSession) {
		int ret = 0;
		TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
		ret = mapper.insertSelective(record);
		return ret;	
	}

	@Override
	public Tmunicipio selectByPrimaryKey(Integer codMunicipio) {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
			Tmunicipio obj = mapper.selectByPrimaryKey(codMunicipio);
			return obj;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public Tmunicipio selectByPrimaryKey(Integer codMunicipio,
			SqlSession sqlSession) {
		TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
		Tmunicipio obj = mapper.selectByPrimaryKey(codMunicipio);
		return obj;
	}

	@Override
	public Integer selectLastPrimaryKey() {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
			Integer obj = mapper.selectLastPrimaryKey();
			if (obj == null)
				obj = 0;
			return obj;
		}finally{
			sqlSession.close();
		}		
	}

	@Override
	public Integer selectLastPrimaryKey(SqlSession sqlSession) {
		TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
		Integer obj = mapper.selectLastPrimaryKey();
		if (obj == null)
			obj = 0;
		return obj;	
	}
	
	@Override
	public int updateByPrimaryKeySelective(Tmunicipio record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public int updateByPrimaryKeySelective(Tmunicipio record,
			SqlSession sqlSession) {
		int ret = 0;
		TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
		ret = mapper.updateByPrimaryKeySelective(record);
		return ret;		
	}


	@Override
	public int updateByPrimaryKey(Tmunicipio record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public int updateByPrimaryKey(Tmunicipio record, SqlSession sqlSession) {
		int ret = 0;
		TmunicipioMapper mapper = sqlSession.getMapper(TmunicipioMapper.class);
		ret = mapper.updateByPrimaryKey(record);
		return ret;
	}
}
