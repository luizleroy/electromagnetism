package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class TValidGrupo13FD {
	// private Double input:::
	private Double identificadorCliente;
	private Double diaMedicao;
	private Double demandaMedia;
	private Double demandaMaxima;
	private Double potInstalada;
	// private Double output:::
	private Double fatorDeDemanda;

	public TValidGrupo13FD(Double identificadorCliente, Double diaMedicao,
			Double demandaMedia, Double demandaMaxima, Double potInstalada,
			Double fatorDeDemanda) {
		this.identificadorCliente = identificadorCliente;
		this.diaMedicao = diaMedicao;
		this.demandaMedia = demandaMedia;
		this.demandaMaxima = demandaMaxima;
		this.potInstalada = potInstalada;
		this.fatorDeDemanda = fatorDeDemanda;
	}

	public TValidGrupo13FD() {
		super();
	}

	public Double getIdentificadorCliente() {
		return identificadorCliente;
	}

	public void setIdentificadorCliente(Double identificadorCliente) {
		this.identificadorCliente = identificadorCliente;
	}

	public Double getDiaMedicao() {
		return diaMedicao;
	}

	public void setDiaMedicao(Double diaMedicao) {
		this.diaMedicao = diaMedicao;
	}

	public Double getDemandaMedia() {
		return demandaMedia;
	}

	public void setDemandaMedia(Double demandaMedia) {
		this.demandaMedia = demandaMedia;
	}

	public Double getDemandaMaxima() {
		return demandaMaxima;
	}

	public void setDemandaMaxima(Double demandaMaxima) {
		this.demandaMaxima = demandaMaxima;
	}

	public Double getPotInstalada() {
		return potInstalada;
	}

	public void setPotInstalada(Double potInstalada) {
		this.potInstalada = potInstalada;
	}

	public Double getFatorDeDemanda() {
		return fatorDeDemanda;
	}

	public void setFatorDeCarga(Double fatorDeDemanda) {
		this.fatorDeDemanda = fatorDeDemanda;
	}
}
