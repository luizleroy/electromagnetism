package br.com.axxiom.ped435.model.util;

import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealMatrixImpl;

/**
 * FIXME: como centralizar as matrizes do load flow aqui??? FIXME: vale o custo
 * desta implementação ?????? Design Patner: Necessário para isolar o código da
 * RNA e do PSO: toda biblioteca de terceiros, para manipulação de matrizes e
 * vetores, DEVE SER IMPLEMENTADA AQUI! O objetivo é ter um local central para
 * troca das bibliotecas de manipulação de matrizes se for necessário por
 * questão de desempenho.
 * 
 * @author lhipolito LuizLeRoy
 * 
 */
public class Matrix {

	// private double[][] matrixData = { { -1d } };
	private RealMatrix matrix;// = new Array2DRowRealMatrix(matrixData, false);;

	public int getL() {
		return matrix.getRowDimension();
	}

	public int getC() {
		return matrix.getColumnDimension();
	}

	public Matrix(int l, int c) {
		matrix = new RealMatrixImpl(l, c);
	}

	public Matrix(RealMatrix matrix) {
		this.matrix = matrix;
	}

	public void set() {
		this.matrix.setEntry(0, 0, 0.);
	}
	
	public void set(int row, int column, double value) {
		this.matrix.setEntry(row, column, value);
	}

	/**
	 * Construtor principal: carrega a matriz através de uma estrutura primitiva
	 * de dados
	 * 
	 * @param d
	 */
	public Matrix(double[][] d) {
		matrix = new RealMatrixImpl(d);
	}

	// public void toOnes() {
	// int l = matrix.getRowDimension();
	// int c = matrix.getColumnDimension();
	//
	// RealMatrix ones = new RealMatrixImpl(l, c);
	//
	//
	//
	// for (int i = 0; i < l; i++) {
	// for (int j = 0; j < c; j++) {
	// matrixData[i][j] = 1d;
	// }
	// }
	// }

	public String toString() {
		// apenas os dois conjuntos de chaves aninhados são impressos
		return matrix.getRowDimension() + "x" + matrix.getColumnDimension()
				+ " " + matrix.toString().substring(10);
		// | para retirar o nome da implementação (RealMatrixImpl) TODO
		// deprecado...
	}

	// public static int length(Matrix x) {
	// return Math.max(x.c, x.l);
	// }

	public Matrix preMultiply(Matrix k) {
		RealMatrix kData = k.matrix;
		RealMatrix xData = this.matrix;
		RealMatrix target = xData.preMultiply(kData);
		return new Matrix(target);
	}

	public Matrix expPlus1Inv() {
		RealMatrix xData = this.matrix;
		xData.walkInOptimizedOrder(new RealMatrixExpNegPlus1InvVisitor());
		return new Matrix(xData);
	}

	public Matrix multiply(Matrix k) {
		RealMatrix kData = k.matrix;
		RealMatrix xData = this.matrix;
		RealMatrix target = xData.multiply(kData);
		return new Matrix(target);
	}

	public Matrix add(Matrix k) {
		RealMatrix kData = k.matrix;
		RealMatrix xData = this.matrix;
		RealMatrix target = xData.add(kData);
		return new Matrix(target);
	}

	public Matrix transpose() {
		return new Matrix(this.matrix.transpose());
	}

	// TODO existe um getColumnVector (seria mais performático?)
	// IMPORTANTE: O OBJETIVO DESTA CLASSE é SIMPLIFICAR A VIDA DE UM
	// DESENVOLVEDOR usu´´ario DE MATRIZ.
	// PORTANTO, MESMO após VERIFICAR UMA NECESSIDADE DE UTILIZAR VETORES NO
	// LUGAR DE MATRIZ, DEVO fazê-LO SIM,
	// MAS LEMBRANDO QUE ESTE DEVE SER UTILIZADO (como exemplo o
	// org.apache.commons.math.linear.RealVector) MAS
	// CONTINUAR COMO UM TIPO br.com.axxiom.ped435.util.Matrix.
	public Matrix buildVectorCol(int c) {
		RealMatrix col = this.matrix.getColumnMatrix(c);
		return new Matrix(col);
	}

	public double get(int m, int n) {
		return matrix.getEntry(m, n);
	}
}