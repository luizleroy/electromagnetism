package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TclienteMedidor;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;

public interface TclienteMedidorMapper {
    int deleteByPrimaryKey(@Param("codCliente") Integer codCliente, @Param("codMedidor") String codMedidor);

    int insert(TclienteMedidor record);
    
    int insert(TclienteMedidor record, SqlSession sqlSession);

    int insertSelective(TclienteMedidor record);
}