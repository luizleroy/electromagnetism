package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEntrevista;

public interface TpesqEntrevistaMapper {
    int deleteByPrimaryKey(Integer codEntrevista);
    
    int deleteByPrimaryKey(Integer codEntrevista, SqlSession sqlSession);

    int insert(TpesqEntrevista record);
    
    int insert(TpesqEntrevista record, SqlSession sqlSession);

    int insertSelective(TpesqEntrevista record);
    
    int insertSelective(TpesqEntrevista record, SqlSession sqlSession);

    TpesqEntrevista selectByPrimaryKey(Integer codEntrevista);
    
    TpesqEntrevista selectByPrimaryKey(Integer codEntrevista, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqEntrevista record);
    
    int updateByPrimaryKeySelective(TpesqEntrevista record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqEntrevista record);
    
    int updateByPrimaryKey(TpesqEntrevista record, SqlSession sqlSession);
}