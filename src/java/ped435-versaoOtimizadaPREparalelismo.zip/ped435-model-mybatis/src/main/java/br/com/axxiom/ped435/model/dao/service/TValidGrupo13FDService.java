package br.com.axxiom.ped435.model.dao.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.Grupo13FDMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidGrupo13FD;

public class TValidGrupo13FDService extends BaseDBPED435DAO implements
Grupo13FDMapper {
	@Override
	public List<TValidGrupo13FD> select() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<TValidGrupo13FD> obj = new ArrayList<TValidGrupo13FD>();
		try {
			Grupo13FDMapper mapper = sqlSession
					.getMapper(Grupo13FDMapper.class);
			obj = mapper.select();
			return obj;
		} finally {
			sqlSession.close();
		}
	}
}
