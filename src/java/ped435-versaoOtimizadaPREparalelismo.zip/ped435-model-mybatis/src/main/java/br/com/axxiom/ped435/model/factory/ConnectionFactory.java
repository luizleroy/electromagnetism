package br.com.axxiom.ped435.model.factory;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import br.com.axxiom.ped435.model.util.Config;

public class ConnectionFactory {
	 
    private static Map<String,SqlSessionFactory> mapSqlSessionFactory;
    private static final String resource = "configuration.xml";
    private static List<String> listaEnvironments;    
 
    static {
        try {
        	if (listaEnvironments == null)
        		listaEnvironments = getEnvironmentsName();
        	if (mapSqlSessionFactory == null) {
            	mapSqlSessionFactory = new HashMap<String, SqlSessionFactory>();
            	for (String environment : listaEnvironments) {
            		SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
            		Reader reader = Resources.getResourceAsReader(resource);
            		mapSqlSessionFactory.put(environment, sqlSessionFactoryBuilder.build(reader, environment));
				}            	
            }            
        }
        catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
 
    public static SqlSessionFactory getSqlSessionFactory(String nameEnvironment) {
 
        return mapSqlSessionFactory.get(nameEnvironment);
    }
    
//    private static boolean isDevelopmentEnvironment() {
//	    boolean isEclipse = true;
//	    if (System.getenv("runeclipse") == null) {
//	        isEclipse = false;
//	    }
//	    return isEclipse;
//	}
    
    private static List<String> getEnvironmentsName(){
    	
    	List<String> listaEnv = new ArrayList<String>();   	
    	
    	// 
//    	Url url;
//		File file = new File(url.toString());
        
		SAXBuilder builder = new SAXBuilder();
		     
		Document doc = null;
		
		try {
			//doc = builder.build(ConnectionFactory.class.getClass().getResourceAsStream("/configuration.xml"));
			doc = builder.build(ConnectionFactory.class.getClass().getResourceAsStream(Config.getKey("file.configuration.xml")));
		} catch (JDOMException e){			
			e.printStackTrace();
		}catch (IOException e){
			e.printStackTrace();
		}
			
		Element root = (Element) doc.getRootElement();
		         
		@SuppressWarnings("rawtypes")
		List environments = root.getChild("environments").getChildren();
		             
		@SuppressWarnings("rawtypes")
		Iterator i = environments.iterator();
		             
		while( i.hasNext() ){
	        Element environment = (Element) i.next();
	        listaEnv.add(environment.getAttributeValue("id"));
		}
		return listaEnv;
    }
}
