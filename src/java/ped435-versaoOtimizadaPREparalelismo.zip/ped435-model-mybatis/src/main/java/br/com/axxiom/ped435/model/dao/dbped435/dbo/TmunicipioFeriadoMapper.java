package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TmunicipioFeriado;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;

public interface TmunicipioFeriadoMapper {
	
    int deleteByPrimaryKey(@Param("codMunicipio") Integer codMunicipio, @Param("codFeriado") Integer codFeriado);
    
    int deleteByPrimaryKey(@Param("codMunicipio") Integer codMunicipio, @Param("codFeriado") Integer codFeriado, SqlSession sqlSession);

    int insert(TmunicipioFeriado record);
    
    int insert(TmunicipioFeriado record, SqlSession sqlSession);

    int insertSelective(TmunicipioFeriado record);
    
    int insertSelective(TmunicipioFeriado record, SqlSession sqlSession);
}