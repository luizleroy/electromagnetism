package br.com.axxiom.ped435.model.dao.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TmedicaoMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedicao;

public class TmedicaoService extends BaseDBPED435DAO implements TmedicaoMapper{
	
	@Override
	public int deleteByPrimaryKey(Long codMedicao) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
			ret = mapper.deleteByPrimaryKey(codMedicao);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}	
	}

	@Override
	public int insert(Tmedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insert(Tmedicao record, SqlSession sqlSession) {
		int ret = 0;
		
		TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
		ret = mapper.insert(record);
		return ret;		
	}

	@Override
	public int insertSelective(Tmedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}

	@Override
	public Tmedicao selectByPrimaryKey(Long codMedicao) {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
			Tmedicao obj = mapper.selectByPrimaryKey(codMedicao);
			return obj;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public Long selectLastPrimaryKey() {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
			Long obj = mapper.selectLastPrimaryKey();
			if (obj == null)
				obj = new Long(0);
			return obj;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public Long selectLastPrimaryKey(SqlSession sqlSession) {
		TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
		Long obj = mapper.selectLastPrimaryKey();
		if (obj == null)
			obj = new Long(0);
		return obj;			
	}
	
	@Override
	public List<Tmedicao> selectListByNumInstalacao(String numInstalacao){
		SqlSession sqlSession = sqlSessionFactory.openSession();
		try{
			TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
			List<Tmedicao> medicoes = mapper.selectListByNumInstalacao(numInstalacao);
			return medicoes;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public int updateByPrimaryKeySelective(Tmedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}

	@Override
	public int updateByPrimaryKey(Tmedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int updateByPrimaryKey(Tmedicao record, SqlSession sqlSession) {
		
		int ret = 0;
		TmedicaoMapper mapper = sqlSession.getMapper(TmedicaoMapper.class);
		ret = mapper.updateByPrimaryKey(record);
		return ret;		
	}
}
