package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqUsoEquipamento;

public interface TpesqUsoEquipamentoMapper {
	
    int deleteByPrimaryKey(Integer codUsoEquipamento);
    
    int deleteByPrimaryKey(Integer codUsoEquipamento, SqlSession sqlSession);

    int insert(TpesqUsoEquipamento record);
    
    int insert(TpesqUsoEquipamento record, SqlSession sqlSession);

    int insertSelective(TpesqUsoEquipamento record);
    
    int insertSelective(TpesqUsoEquipamento record, SqlSession sqlSession);

    TpesqUsoEquipamento selectByPrimaryKey(Integer codUsoEquipamento);
    
    TpesqUsoEquipamento selectByPrimaryKey(Integer codUsoEquipamento, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqUsoEquipamento record);
    
    int updateByPrimaryKeySelective(TpesqUsoEquipamento record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqUsoEquipamento record);
    
    int updateByPrimaryKey(TpesqUsoEquipamento record, SqlSession sqlSession);
}