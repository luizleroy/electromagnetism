package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqGrauInstrucaoChefe;

public interface TpesqGrauInstrucaoChefeMapper {
	
    int deleteByPrimaryKey(String codGrauInstrucaoChefe);
    
    int deleteByPrimaryKey(String codGrauInstrucaoChefe, SqlSession sqlSession);

    int insert(TpesqGrauInstrucaoChefe record);
    
    int insert(TpesqGrauInstrucaoChefe record, SqlSession sqlSession);

    int insertSelective(TpesqGrauInstrucaoChefe record);
    
    int insertSelective(TpesqGrauInstrucaoChefe record, SqlSession sqlSession);

    TpesqGrauInstrucaoChefe selectByPrimaryKey(String codGrauInstrucaoChefe);
    
    TpesqGrauInstrucaoChefe selectByPrimaryKey(String codGrauInstrucaoChefe, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqGrauInstrucaoChefe record);
    
    int updateByPrimaryKeySelective(TpesqGrauInstrucaoChefe record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqGrauInstrucaoChefe record);
    
    int updateByPrimaryKey(TpesqGrauInstrucaoChefe record, SqlSession sqlSession);
}