package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqMedidaEconomica {
    private Integer codMedidaEconomica;

    private String codTipoMedidaEconomica;

    private String desMedidaEconomica;

    public TpesqMedidaEconomica(Integer codMedidaEconomica, String codTipoMedidaEconomica, String desMedidaEconomica) {
        this.codMedidaEconomica = codMedidaEconomica;
        this.codTipoMedidaEconomica = codTipoMedidaEconomica;
        this.desMedidaEconomica = desMedidaEconomica;
    }

    public TpesqMedidaEconomica() {
        super();
    }

    public Integer getCodMedidaEconomica() {
        return codMedidaEconomica;
    }

    public void setCodMedidaEconomica(Integer codMedidaEconomica) {
        this.codMedidaEconomica = codMedidaEconomica;
    }

    public String getCodTipoMedidaEconomica() {
        return codTipoMedidaEconomica;
    }

    public void setCodTipoMedidaEconomica(String codTipoMedidaEconomica) {
        this.codTipoMedidaEconomica = codTipoMedidaEconomica;
    }

    public String getDesMedidaEconomica() {
        return desMedidaEconomica;
    }

    public void setDesMedidaEconomica(String desMedidaEconomica) {
        this.desMedidaEconomica = desMedidaEconomica;
    }
}