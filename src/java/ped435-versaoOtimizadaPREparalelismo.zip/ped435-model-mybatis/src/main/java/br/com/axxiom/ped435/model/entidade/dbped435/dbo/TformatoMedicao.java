package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class TformatoMedicao {
    private Integer codFormatoMedicao;

    private String desFormatoMedicao;

    private String tipFormatoMedicao;

    public TformatoMedicao(Integer codFormatoMedicao, Integer codGrandeza, String desFormatoMedicao, String tipFormatoMedicao) {
        this.codFormatoMedicao = codFormatoMedicao;    
        this.desFormatoMedicao = desFormatoMedicao;
        this.tipFormatoMedicao = tipFormatoMedicao;
    }

    public TformatoMedicao() {
        super();
    }

    public Integer getCodFormatoMedicao() {
        return codFormatoMedicao;
    }

    public void setCodFormatoMedicao(Integer codFormatoMedicao) {
        this.codFormatoMedicao = codFormatoMedicao;
    }

    public String getDesFormatoMedicao() {
        return desFormatoMedicao;
    }

    public void setDesFormatoMedicao(String desFormatoMedicao) {
        this.desFormatoMedicao = desFormatoMedicao;
    }

    public String getTipFormatoMedicao() {
        return tipFormatoMedicao;
    }

    public void setTipFormatoMedicao(String tipFormatoMedicao) {
        this.tipFormatoMedicao = tipFormatoMedicao;
    }
}