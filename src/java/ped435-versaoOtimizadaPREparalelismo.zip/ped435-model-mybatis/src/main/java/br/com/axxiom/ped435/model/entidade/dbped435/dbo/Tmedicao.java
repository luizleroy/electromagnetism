package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

import java.util.Date;

public class Tmedicao implements Cloneable{
    private Long codMedicao;

    private String codMedidor;

    private Integer codFormatoMedicao;

    private Date datMedicao;

    private Date datGravacao;

    private String nomOrigemInformacao;
    
    private Integer codSituacaoMedicao;

    private String valMedicao;

    public Tmedicao(Long codMedicao, String codMedidor, Integer codFormatoMedicao, Date datMedicao, Date datGravacao, String nomOrigemInformacao, Integer codSituacaoMedicao, String valMedicao) {
        this.codMedicao = codMedicao;
        this.codMedidor = codMedidor;
        this.codFormatoMedicao = codFormatoMedicao;
        this.datMedicao = datMedicao;
        this.datGravacao = datGravacao;
        this.nomOrigemInformacao = nomOrigemInformacao;
        this.setCodSituacaoMedicao(codSituacaoMedicao);
        this.valMedicao = valMedicao;
    }

    public Tmedicao() {
        super();
    }

    public Long getCodMedicao() {
        return codMedicao;
    }

    public void setCodMedicao(Long codMedicao) {
        this.codMedicao = codMedicao;
    }

    public String getCodMedidor() {
        return codMedidor;
    }

    public void setCodMedidor(String codMedidor) {
        this.codMedidor = codMedidor;
    }

    public Integer getCodFormatoMedicao() {
        return codFormatoMedicao;
    }

    public void setCodFormatoMedicao(Integer codFormatoMedicao) {
        this.codFormatoMedicao = codFormatoMedicao;
    }

    public Date getDatMedicao() {
        return datMedicao;
    }

    public void setDatMedicao(Date datMedicao) {
        this.datMedicao = datMedicao;
    }

    public Date getDatGravacao() {
        return datGravacao;
    }

    public void setDatGravacao(Date datGravacao) {
        this.datGravacao = datGravacao;
    }

    public String getNomOrigemInformacao() {
        return nomOrigemInformacao;
    }

    public void setNomOrigemInformacao(String nomOrigemInformacao) {
        this.nomOrigemInformacao = nomOrigemInformacao;
    }

    public Integer getCodSituacaoMedicao() {
		return codSituacaoMedicao;
	}

	public void setCodSituacaoMedicao(Integer codSituacaoMedicao) {
		this.codSituacaoMedicao = codSituacaoMedicao;
	}

	public String getValMedicao() {
        return valMedicao;
    }

    public void setValMedicao(String valMedicao) {
        this.valMedicao = valMedicao;
    }
    
    public Object clone() throws CloneNotSupportedException {		
		return super.clone();
    }
}