package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqTipoMedidaEconomica;

public interface TpesqTipoMedidaEconomicaMapper {
	
    int deleteByPrimaryKey(String codTipoMedidaEconomica);
    
    int deleteByPrimaryKey(String codTipoMedidaEconomica, SqlSession sqlSession);

    int insert(TpesqTipoMedidaEconomica record);
    
    int insert(TpesqTipoMedidaEconomica record, SqlSession sqlSession);

    int insertSelective(TpesqTipoMedidaEconomica record);
    
    int insertSelective(TpesqTipoMedidaEconomica record, SqlSession sqlSession);

    TpesqTipoMedidaEconomica selectByPrimaryKey(String codTipoMedidaEconomica);
    
    TpesqTipoMedidaEconomica selectByPrimaryKey(String codTipoMedidaEconomica, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqTipoMedidaEconomica record);
    
    int updateByPrimaryKeySelective(TpesqTipoMedidaEconomica record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqTipoMedidaEconomica record);
    
    int updateByPrimaryKey(TpesqTipoMedidaEconomica record, SqlSession sqlSession);
}