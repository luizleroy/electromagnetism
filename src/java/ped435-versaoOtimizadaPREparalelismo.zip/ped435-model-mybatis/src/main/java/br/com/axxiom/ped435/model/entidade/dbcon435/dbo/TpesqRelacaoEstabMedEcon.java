package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqRelacaoEstabMedEcon {
    private Integer codMedidaEconomica;

    private Integer codEstabelecimento;

    public TpesqRelacaoEstabMedEcon(Integer codMedidaEconomica, Integer codEstabelecimento) {
        this.codMedidaEconomica = codMedidaEconomica;
        this.codEstabelecimento = codEstabelecimento;
    }

    public TpesqRelacaoEstabMedEcon() {
        super();
    }

    public Integer getCodMedidaEconomica() {
        return codMedidaEconomica;
    }

    public void setCodMedidaEconomica(Integer codMedidaEconomica) {
        this.codMedidaEconomica = codMedidaEconomica;
    }

    public Integer getCodEstabelecimento() {
        return codEstabelecimento;
    }

    public void setCodEstabelecimento(Integer codEstabelecimento) {
        this.codEstabelecimento = codEstabelecimento;
    }
}