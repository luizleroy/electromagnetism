package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEntrevistado;

public interface TpesqEntrevistadoMapper {
    int deleteByPrimaryKey(Integer codEntrevistado);
    
    int deleteByPrimaryKey(Integer codEntrevistado, SqlSession sqlSession);

    int insert(TpesqEntrevistado record);
    
    int insert(TpesqEntrevistado record, SqlSession sqlSession);

    int insertSelective(TpesqEntrevistado record);
    
    int insertSelective(TpesqEntrevistado record, SqlSession sqlSession);

    TpesqEntrevistado selectByPrimaryKey(Integer codEntrevistado);
    
    TpesqEntrevistado selectByPrimaryKey(Integer codEntrevistado, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqEntrevistado record);
    
    int updateByPrimaryKeySelective(TpesqEntrevistado record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqEntrevistado record);
    
    int updateByPrimaryKey(TpesqEntrevistado record, SqlSession sqlSession);
}