package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tgrandeza;

public interface TgrandezaMapper {
    int deleteByPrimaryKey(Integer codGrandeza);

    int insert(Tgrandeza record);
    
    int insert(Tgrandeza record, SqlSession sqlSession);

    int insertSelective(Tgrandeza record);

    Tgrandeza selectByPrimaryKey(Integer codGrandeza);
    
    Integer selectLastPrimaryKey();
    
    Integer selectLastPrimaryKey(SqlSession sqlSession);

    int updateByPrimaryKeySelective(Tgrandeza record);

    int updateByPrimaryKey(Tgrandeza record);
}