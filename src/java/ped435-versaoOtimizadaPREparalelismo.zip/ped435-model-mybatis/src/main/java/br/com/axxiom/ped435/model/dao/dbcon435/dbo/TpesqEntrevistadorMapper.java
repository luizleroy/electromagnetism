package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEntrevistador;

public interface TpesqEntrevistadorMapper {
    int deleteByPrimaryKey(Integer codEntrevistador);
    
    int deleteByPrimaryKey(Integer codEntrevistador, SqlSession sqlSession);

    int insert(TpesqEntrevistador record);
    
    int insert(TpesqEntrevistador record, SqlSession sqlSession);

    int insertSelective(TpesqEntrevistador record);
    
    int insertSelective(TpesqEntrevistador record, SqlSession sqlSession);

    TpesqEntrevistador selectByPrimaryKey(Integer codEntrevistador);
    
    TpesqEntrevistador selectByPrimaryKey(Integer codEntrevistador, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqEntrevistador record);
    
    int updateByPrimaryKeySelective(TpesqEntrevistador record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqEntrevistador record);
    
    int updateByPrimaryKey(TpesqEntrevistador record, SqlSession sqlSession);
}