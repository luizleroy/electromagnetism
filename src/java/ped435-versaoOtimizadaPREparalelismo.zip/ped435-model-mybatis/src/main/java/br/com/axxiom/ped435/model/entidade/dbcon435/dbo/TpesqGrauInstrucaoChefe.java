package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqGrauInstrucaoChefe {
    private String codGrauInstrucaoChefe;

    private String desGrauInstrucaoChefe;

    public TpesqGrauInstrucaoChefe(String codGrauInstrucaoChefe, String desGrauInstrucaoChefe) {
        this.codGrauInstrucaoChefe = codGrauInstrucaoChefe;
        this.desGrauInstrucaoChefe = desGrauInstrucaoChefe;
    }

    public TpesqGrauInstrucaoChefe() {
        super();
    }

    public String getCodGrauInstrucaoChefe() {
        return codGrauInstrucaoChefe;
    }

    public void setCodGrauInstrucaoChefe(String codGrauInstrucaoChefe) {
        this.codGrauInstrucaoChefe = codGrauInstrucaoChefe;
    }

    public String getDesGrauInstrucaoChefe() {
        return desGrauInstrucaoChefe;
    }

    public void setDesGrauInstrucaoChefe(String desGrauInstrucaoChefe) {
        this.desGrauInstrucaoChefe = desGrauInstrucaoChefe;
    }
}