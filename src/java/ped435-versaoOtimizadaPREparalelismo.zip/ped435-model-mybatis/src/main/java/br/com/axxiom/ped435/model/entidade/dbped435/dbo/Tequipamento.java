package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class Tequipamento {
    private Integer codEquipamento;

    private String codMedidor;

    private String nomSistemaOrigem;

    public Tequipamento(Integer codEquipamento, String codMedidor, String nomSistemaOrigem) {
        this.codEquipamento = codEquipamento;
        this.codMedidor = codMedidor;
        this.nomSistemaOrigem = nomSistemaOrigem;
    }

    public Tequipamento() {
        super();
    }

    public Integer getCodEquipamento() {
        return codEquipamento;
    }

    public void setCodEquipamento(Integer codEquipamento) {
        this.codEquipamento = codEquipamento;
    }

    public String getCodMedidor() {
        return codMedidor;
    }

    public void setCodMedidor(String codMedidor) {
        this.codMedidor = codMedidor;
    }

    public String getNomSistemaOrigem() {
        return nomSistemaOrigem;
    }

    public void setNomSistemaOrigem(String nomSistemaOrigem) {
        this.nomSistemaOrigem = nomSistemaOrigem;
    }
}