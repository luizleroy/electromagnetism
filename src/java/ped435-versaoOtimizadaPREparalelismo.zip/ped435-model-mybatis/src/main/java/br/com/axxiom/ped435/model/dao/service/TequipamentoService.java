package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TequipamentoMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tequipamento;

public class TequipamentoService extends BaseDBPED435DAO implements TequipamentoMapper {

	@Override
	public int deleteByPrimaryKey(Integer codEquipamento) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
			ret = mapper.deleteByPrimaryKey(codEquipamento);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}	
	}
	
	@Override
	public int deleteByPrimaryKey(Integer codEquipamento, SqlSession sqlSession) {
		int ret = 0;		
		TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
		ret = mapper.deleteByPrimaryKey(codEquipamento);
		sqlSession.commit();
		return ret;
		
	}

	@Override
	public int insert(Tequipamento record) {
		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		int ret = 0;
		try{
			TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insert(Tequipamento record, SqlSession sqlSession) {
				
		int ret = 0;
		TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
		ret = mapper.insert(record);
		return ret;		
	}

	@Override
	public int insertSelective(Tequipamento record) {
		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insertSelective(Tequipamento record, SqlSession sqlSession) {
		
		int ret = 0;
		TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
		ret = mapper.insertSelective(record);
		sqlSession.commit();
		return ret;		
	}

	@Override
	public Tequipamento selectByPrimaryKey(Integer codEquipamento) {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
			Tequipamento obj = mapper.selectByPrimaryKey(codEquipamento);
			return obj;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public Tequipamento selectByPrimaryKey(Integer codEquipamento, SqlSession sqlSession) {
		
		TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
		Tequipamento obj = mapper.selectByPrimaryKey(codEquipamento);
		return obj;
			
	}
	
	@Override
	public Integer selectLastPrimaryKey() {
		SqlSession sqlSession = sqlSessionFactory.openSession();		
		try{
			TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
			Integer obj = mapper.selectLastPrimaryKey();
			if (obj == null){
				obj = 0;
			}
			return obj;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public Integer selectLastPrimaryKey(SqlSession sqlSession) {
				
		TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
		Integer obj = mapper.selectLastPrimaryKey();
		if (obj == null){
			obj = 0;
		}
		return obj;		
	}

	@Override
	public int updateByPrimaryKeySelective(Tequipamento record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int updateByPrimaryKeySelective(Tequipamento record, SqlSession sqlSession) {		
		int ret = 0;		
		TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
		ret = mapper.updateByPrimaryKeySelective(record);
		sqlSession.commit();
		return ret;		
	}

	@Override
	public int updateByPrimaryKey(Tequipamento record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int updateByPrimaryKey(Tequipamento record, SqlSession sqlSession) {
		int ret = 0;		
		TequipamentoMapper mapper = sqlSession.getMapper(TequipamentoMapper.class);
		ret = mapper.updateByPrimaryKey(record);
		sqlSession.commit();
		return ret;		
	}	
}
