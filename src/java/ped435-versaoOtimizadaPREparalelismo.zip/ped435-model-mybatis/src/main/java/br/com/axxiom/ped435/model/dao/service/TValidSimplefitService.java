package br.com.axxiom.ped435.model.dao.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TValidSimplefitMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidSimplefit;

public class TValidSimplefitService extends BaseDBPED435DAO implements TValidSimplefitMapper{

	@Override
	public List<TValidSimplefit> select() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<TValidSimplefit> obj = new ArrayList<TValidSimplefit>();
		try{
			TValidSimplefitMapper mapper = sqlSession.getMapper(TValidSimplefitMapper.class);
			obj = mapper.select();
			return obj;
		}finally{
			sqlSession.close();
		}
	}
}
