package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Ttemperatura;

public interface TtemperaturaMapper {
    
	int deleteByPrimaryKey(Integer codTemperatura);
	
	int deleteByPrimaryKey(Integer codTemperatura, SqlSession sqlSession);

    int insert(Ttemperatura record);
    
    int insert(Ttemperatura record, SqlSession sqlSession);

    int insertSelective(Ttemperatura record);
    
    int insertSelective(Ttemperatura record, SqlSession sqlSession);

    Ttemperatura selectByPrimaryKey(Integer codTemperatura);
    
    Ttemperatura selectByPrimaryKey(Integer codTemperatura, SqlSession sqlSession);
    
    Integer selectLastPrimaryKey();
    
    Integer selectLastPrimaryKey(SqlSession sqlSession); 

    int updateByPrimaryKeySelective(Ttemperatura record);
    
    int updateByPrimaryKeySelective(Ttemperatura record, SqlSession sqlSession);

    int updateByPrimaryKey(Ttemperatura record);
    
    int updateByPrimaryKey(Ttemperatura record, SqlSession sqlSession);
}