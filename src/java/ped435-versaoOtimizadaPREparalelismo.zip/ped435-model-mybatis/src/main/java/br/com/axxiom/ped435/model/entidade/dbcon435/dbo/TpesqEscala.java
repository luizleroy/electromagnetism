package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqEscala {
    private String codEscala;

    private String desEscala;

    public TpesqEscala(String codEscala, String desEscala) {
        this.codEscala = codEscala;
        this.desEscala = desEscala;
    }

    public TpesqEscala() {
        super();
    }

    public String getCodEscala() {
        return codEscala;
    }

    public void setCodEscala(String codEscala) {
        this.codEscala = codEscala;
    }

    public String getDesEscala() {
        return desEscala;
    }

    public void setDesEscala(String desEscala) {
        this.desEscala = desEscala;
    }
}