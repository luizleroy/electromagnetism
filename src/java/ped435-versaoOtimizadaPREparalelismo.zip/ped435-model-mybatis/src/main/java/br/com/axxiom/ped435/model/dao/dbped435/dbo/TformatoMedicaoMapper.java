package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TformatoMedicao;

public interface TformatoMedicaoMapper {
    int deleteByPrimaryKey(Integer codFormatoMedicao);

    int insert(TformatoMedicao record);
    
    int insert(TformatoMedicao record, SqlSession sqlSession);

    int insertSelective(TformatoMedicao record);

    TformatoMedicao selectByPrimaryKey(Integer codFormatoMedicao);
    
    Integer selectLastPrimaryKey();
    
    Integer selectLastPrimaryKey(SqlSession sqlSession);

    int updateByPrimaryKeySelective(TformatoMedicao record);

    int updateByPrimaryKey(TformatoMedicao record);
}