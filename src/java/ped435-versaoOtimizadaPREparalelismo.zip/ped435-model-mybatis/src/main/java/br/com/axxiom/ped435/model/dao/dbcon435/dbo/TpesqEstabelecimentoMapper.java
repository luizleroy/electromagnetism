package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEstabelecimento;

public interface TpesqEstabelecimentoMapper {
	
    int deleteByPrimaryKey(Integer codEstabelecimento);
    
    int deleteByPrimaryKey(Integer codEstabelecimento, SqlSession sqlSession);

    int insert(TpesqEstabelecimento record);
    
    int insert(TpesqEstabelecimento record, SqlSession sqlSession);

    int insertSelective(TpesqEstabelecimento record);
    
    int insertSelective(TpesqEstabelecimento record, SqlSession sqlSession);

    TpesqEstabelecimento selectByPrimaryKey(Integer codEstabelecimento);
    
    TpesqEstabelecimento selectByPrimaryKey(Integer codEstabelecimento, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqEstabelecimento record);
    
    int updateByPrimaryKeySelective(TpesqEstabelecimento record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqEstabelecimento record);
    
    int updateByPrimaryKey(TpesqEstabelecimento record, SqlSession sqlSession);
}