package br.com.axxiom.ped435.model.dao.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.VPesqMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Sample;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.VPesq;

public class VPesqService extends BaseDBPED435DAO implements VPesqMapper {
	
	/* Equivalente:
	 * select 
rel.COD_ESTABELECIMENTO
,sum(rel.QTD_EQUIPAMENTOS*eqp.POT_WATT) as POT_INST from TPESQ_RELACAO_ESTAB_EQUIP rel
inner join TPESQ_EQUIPAMENTO eqp on eqp.COD_EQUIPAMENTO = rel.COD_EQUIPAMENTO
group by rel.COD_ESTABELECIMENTO
order by rel.COD_ESTABELECIMENTO
	 */
	static public Map<Integer,Sample> generateListSamples(List<VPesq> listVPesq) {
		Map<Integer, Sample> target = new HashMap<Integer, Sample>();
		for (VPesq vPesq : listVPesq) {
			int key = vPesq.getCodEntrevistado();
			Set<Integer> set = target.keySet();
			if (set.contains(key)) {
				Sample data = target.get(key);
				double pot = data.getpInst();
				pot+=vPesq.getPotWatt()*vPesq.getQtdEquipamentos(); // acumulando a potência instalada: soma do produto entre a qtd de equipamentos e a potência do equipamento
				data.setpInst(pot);
			} else {
				Sample data = new Sample();
				data.setpInst(vPesq.getPotWatt()*vPesq.getQtdEquipamentos());
				target.put(key, data);
			}
		}
		return target;
	}
	
	@Override
	public List<VPesq> selectListViewPesquisa(){
		SqlSession sqlSession = sqlSessionFactory.openSession();
		try{
			VPesqMapper mapper = sqlSession.getMapper(VPesqMapper.class);
			List<VPesq> medicoes = mapper.selectListViewPesquisa();
			return medicoes;
		}finally{
			sqlSession.close();
		}
	}
}
