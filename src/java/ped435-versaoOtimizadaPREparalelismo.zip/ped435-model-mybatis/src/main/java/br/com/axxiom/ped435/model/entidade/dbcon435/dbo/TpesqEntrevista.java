package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

import java.util.Date;

public class TpesqEntrevista {
    private Integer codEntrevista;

    private Integer codEntrevistador;

    private Integer codEntrevistado;

    private Integer codEstabelecimento;

    private Date datInicioEntrevista;

    private Date datTerminoEntrevista;

    private Date datEntrevista;

    private String codDispositivoEntrevista;

    public TpesqEntrevista(Integer codEntrevista, Integer codEntrevistador, Integer codEntrevistado, Integer codEstabelecimento, Date datInicioEntrevista, Date datTerminoEntrevista, Date datEntrevista, String codDispositivoEntrevista) {
        this.codEntrevista = codEntrevista;
        this.codEntrevistador = codEntrevistador;
        this.codEntrevistado = codEntrevistado;
        this.codEstabelecimento = codEstabelecimento;
        this.datInicioEntrevista = datInicioEntrevista;
        this.datTerminoEntrevista = datTerminoEntrevista;
        this.datEntrevista = datEntrevista;
        this.codDispositivoEntrevista = codDispositivoEntrevista;
    }

    public TpesqEntrevista() {
        super();
    }

    public Integer getCodEntrevista() {
        return codEntrevista;
    }

    public void setCodEntrevista(Integer codEntrevista) {
        this.codEntrevista = codEntrevista;
    }

    public Integer getCodEntrevistador() {
        return codEntrevistador;
    }

    public void setCodEntrevistador(Integer codEntrevistador) {
        this.codEntrevistador = codEntrevistador;
    }

    public Integer getCodEntrevistado() {
        return codEntrevistado;
    }

    public void setCodEntrevistado(Integer codEntrevistado) {
        this.codEntrevistado = codEntrevistado;
    }

    public Integer getCodEstabelecimento() {
        return codEstabelecimento;
    }

    public void setCodEstabelecimento(Integer codEstabelecimento) {
        this.codEstabelecimento = codEstabelecimento;
    }

    public Date getDatInicioEntrevista() {
        return datInicioEntrevista;
    }

    public void setDatInicioEntrevista(Date datInicioEntrevista) {
        this.datInicioEntrevista = datInicioEntrevista;
    }

    public Date getDatTerminoEntrevista() {
        return datTerminoEntrevista;
    }

    public void setDatTerminoEntrevista(Date datTerminoEntrevista) {
        this.datTerminoEntrevista = datTerminoEntrevista;
    }

    public Date getDatEntrevista() {
        return datEntrevista;
    }

    public void setDatEntrevista(Date datEntrevista) {
        this.datEntrevista = datEntrevista;
    }

    public String getCodDispositivoEntrevista() {
        return codDispositivoEntrevista;
    }

    public void setCodDispositivoEntrevista(String codDispositivoEntrevista) {
        this.codDispositivoEntrevista = codDispositivoEntrevista;
    }
}