package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqRelacaoEstabEquipMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqRelacaoEstabEquip;

public class TpesqRelacaoEstabEquipService extends BaseDBCON435DAO implements TpesqRelacaoEstabEquipMapper{

	@Override
	public int deleteByPrimaryKey(Integer codEstabelecimento,
			Integer codEquipamento) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer codEstabelecimento,
			Integer codEquipamento, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqRelacaoEstabEquip record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqRelacaoEstabEquip record, SqlSession sqlSession) {
		int ret = 0;
		TpesqRelacaoEstabEquipMapper mapper = sqlSession.getMapper(TpesqRelacaoEstabEquipMapper.class);
		ret = mapper.insert(record);
		return ret;		
	}

	@Override
	public int insertSelective(TpesqRelacaoEstabEquip record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqRelacaoEstabEquip record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
