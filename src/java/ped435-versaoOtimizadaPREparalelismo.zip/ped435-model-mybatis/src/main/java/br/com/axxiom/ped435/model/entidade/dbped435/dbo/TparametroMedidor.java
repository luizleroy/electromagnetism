package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class TparametroMedidor {
    private Integer codParametroMedidor;

    private Double valRtp;

    private Double valRtc;

    private Double valNumerador;

    private Double valDenominador;

    public TparametroMedidor(Integer codParametroMedidor, Double valRtp, Double valRtc, Double valNumerador, Double valDenominador) {
        this.codParametroMedidor = codParametroMedidor;
        this.valRtp = valRtp;
        this.valRtc = valRtc;
        this.valNumerador = valNumerador;
        this.valDenominador = valDenominador;
    }

    public TparametroMedidor() {
        super();
    }

    public Integer getCodParametroMedidor() {
        return codParametroMedidor;
    }

    public void setCodParametroMedidor(Integer codParametroMedidor) {
        this.codParametroMedidor = codParametroMedidor;
    }

    public Double getValRtp() {
        return valRtp;
    }

    public void setValRtp(Double valRtp) {
        this.valRtp = valRtp;
    }

    public Double getValRtc() {
        return valRtc;
    }

    public void setValRtc(Double valRtc) {
        this.valRtc = valRtc;
    }

    public Double getValNumerador() {
        return valNumerador;
    }

    public void setValNumerador(Double valNumerador) {
        this.valNumerador = valNumerador;
    }

    public Double getValDenominador() {
        return valDenominador;
    }

    public void setValDenominador(Double valDenominador) {
        this.valDenominador = valDenominador;
    }
}