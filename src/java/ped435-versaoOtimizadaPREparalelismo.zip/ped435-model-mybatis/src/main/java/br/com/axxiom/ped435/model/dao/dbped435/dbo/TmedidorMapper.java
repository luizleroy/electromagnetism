package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedidor;

public interface TmedidorMapper {
    
	int deleteByPrimaryKey(String codMedidor);
	
	int deleteByPrimaryKey(String codMedidor, SqlSession sqlSession);

    int insert(Tmedidor record);
    
    int insert(Tmedidor record, SqlSession sqlSession);

    int insertSelective(Tmedidor record);
    
    int insertSelective(Tmedidor record, SqlSession sqlSession);

    Tmedidor selectByPrimaryKey(String codMedidor);
    
    Tmedidor selectByPrimaryKey(String codMedidor, SqlSession sqlSession);
    
    Integer selectLastPrimaryKey();
    
    Integer selectLastPrimaryKey(SqlSession sqlSession);

    int updateByPrimaryKeySelective(Tmedidor record);
    
    int updateByPrimaryKeySelective(Tmedidor record, SqlSession sqlSession);

    int updateByPrimaryKey(Tmedidor record);
    
    int updateByPrimaryKey(Tmedidor record, SqlSession sqlSession);
}