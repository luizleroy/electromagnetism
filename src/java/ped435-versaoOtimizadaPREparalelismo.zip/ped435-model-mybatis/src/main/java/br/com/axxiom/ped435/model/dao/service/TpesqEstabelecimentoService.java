package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqEstabelecimentoMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEstabelecimento;

public class TpesqEstabelecimentoService extends BaseDBCON435DAO implements TpesqEstabelecimentoMapper{

	@Override
	public int deleteByPrimaryKey(Integer codEstabelecimento) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer codEstabelecimento,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEstabelecimento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEstabelecimento record, SqlSession sqlSession) {
		int ret = 0;
		TpesqEstabelecimentoMapper mapper = sqlSession.getMapper(TpesqEstabelecimentoMapper.class);
		ret = mapper.insert(record);
		return ret;
	}

	@Override
	public int insertSelective(TpesqEstabelecimento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqEstabelecimento record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqEstabelecimento selectByPrimaryKey(Integer codEstabelecimento) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqEstabelecimento selectByPrimaryKey(Integer codEstabelecimento,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEstabelecimento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEstabelecimento record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEstabelecimento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEstabelecimento record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
