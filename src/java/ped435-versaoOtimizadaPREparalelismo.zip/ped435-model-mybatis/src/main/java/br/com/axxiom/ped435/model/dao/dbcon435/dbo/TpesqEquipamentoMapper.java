package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEquipamento;

public interface TpesqEquipamentoMapper {
    int deleteByPrimaryKey(Integer codEquipamento);
    
    int deleteByPrimaryKey(Integer codEquipamento, SqlSession sqlSession);

    int insert(TpesqEquipamento record);
    
    int insert(TpesqEquipamento record, SqlSession sqlSession);

    int insertSelective(TpesqEquipamento record);
    
    int insertSelective(TpesqEquipamento record, SqlSession sqlSession);

    TpesqEquipamento selectByPrimaryKey(Integer codEquipamento);
    
    TpesqEquipamento selectByPrimaryKey(Integer codEquipamento, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqEquipamento record);
    
    int updateByPrimaryKeySelective(TpesqEquipamento record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqEquipamento record);
    
    int updateByPrimaryKey(TpesqEquipamento record, SqlSession sqlSession);
}