package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import java.util.List;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidSimplefit;

public interface TValidSimplefitMapper {
	List<TValidSimplefit> select();
}
