package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqRendaMensalFamiliar;

public interface TpesqRendaMensalFamiliarMapper {
	
    int deleteByPrimaryKey(String codRendaMensalFamiliar);
    
    int deleteByPrimaryKey(String codRendaMensalFamiliar, SqlSession sqlSession);

    int insert(TpesqRendaMensalFamiliar record);
    
    int insert(TpesqRendaMensalFamiliar record, SqlSession sqlSession);

    int insertSelective(TpesqRendaMensalFamiliar record);
    
    int insertSelective(TpesqRendaMensalFamiliar record, SqlSession sqlSession);

    TpesqRendaMensalFamiliar selectByPrimaryKey(String codRendaMensalFamiliar);
    
    TpesqRendaMensalFamiliar selectByPrimaryKey(String codRendaMensalFamiliar, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqRendaMensalFamiliar record);
    
    int updateByPrimaryKeySelective(TpesqRendaMensalFamiliar record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqRendaMensalFamiliar record);
    
    int updateByPrimaryKey(TpesqRendaMensalFamiliar record, SqlSession sqlSession);
}