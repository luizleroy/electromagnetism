package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqMedidaEconomicaMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqMedidaEconomica;

public class TpesqMedidaEconomicaService extends BaseDBCON435DAO implements TpesqMedidaEconomicaMapper {

	@Override
	public int deleteByPrimaryKey(Integer codMedidaEconomica) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer codMedidaEconomica,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqMedidaEconomica record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqMedidaEconomica record, SqlSession sqlSession) {
		int ret = 0;
		TpesqMedidaEconomicaMapper mapper = sqlSession.getMapper(TpesqMedidaEconomicaMapper.class);
		ret = mapper.insert(record);
		return ret;	
	}

	@Override
	public int insertSelective(TpesqMedidaEconomica record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqMedidaEconomica record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqMedidaEconomica selectByPrimaryKey(Integer codMedidaEconomica) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqMedidaEconomica selectByPrimaryKey(Integer codMedidaEconomica,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqMedidaEconomica record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqMedidaEconomica record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqMedidaEconomica record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqMedidaEconomica record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
