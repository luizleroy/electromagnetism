package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class TValidSimplefit {
	 private Double input;
	 private Double output;
	 public TValidSimplefit(Double input, Double output) {
	        this.input = input;
	        this.output = output;
	    }

	    public TValidSimplefit() {
	        super();
	    }

		public Double getInput() {
			return input;
		}

		public void setInput(Double input) {
			this.input = input;
		}

		public Double getOutput() {
			return output;
		}

		public void setOutput(Double output) {
			this.output = output;
		}
}
