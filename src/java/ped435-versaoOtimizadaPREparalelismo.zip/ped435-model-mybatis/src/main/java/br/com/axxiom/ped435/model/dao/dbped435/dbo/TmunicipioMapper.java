package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmunicipio;

public interface TmunicipioMapper {
    
	int deleteByPrimaryKey(Integer codMunicipio);
	
	int deleteByPrimaryKey(Integer codMunicipio, SqlSession sqlSession);

    int insert(Tmunicipio record);
    
    int insert(Tmunicipio record, SqlSession sqlSession);

    int insertSelective(Tmunicipio record);
    
    int insertSelective(Tmunicipio record, SqlSession sqlSession);

    Tmunicipio selectByPrimaryKey(Integer codMunicipio);
    
    Tmunicipio selectByPrimaryKey(Integer codMunicipio, SqlSession sqlSession);
    
    Integer selectLastPrimaryKey();
    
    Integer selectLastPrimaryKey(SqlSession sqlSession);

    int updateByPrimaryKeySelective(Tmunicipio record);
    
    int updateByPrimaryKeySelective(Tmunicipio record, SqlSession sqlSession);

    int updateByPrimaryKey(Tmunicipio record);
    
    int updateByPrimaryKey(Tmunicipio record, SqlSession sqlSession);
}