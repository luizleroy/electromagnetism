package br.com.axxiom.ped435.model.dao.enums;

/**
 * Enum SituacaoMedicaoEnum - Contempla todos os registros que podem ser utilizados na tabela
 * TSITUACAO_MEDICAO
 * 
 * @author ssoares - Sólon Soares - solon.soares@axxiom.com.br
 * Axxiom Solucoes Tecnologicas S.A. - www.axxiom.com.br
 */
public enum SituacaoMedicaoEnum {

	VALIDO(1, "VALIDO", "REGISTRO NAO TEM PROBLEMAS"),
	INVALIDO_CANAL_FALTANTE(2, "INVALIDO", "REGISTRO NAO POSSUI OS 3 CANAIS DE MEDICAO"),
	INVALIDO_CANAIS_INCOERENTES(3, "INVALIDO", "REGISTRO NAO POSSUI OS 3 CANAIS COM A MESMA QUANTIDADE DE MEDICOES"),
	INVALIDO_MEDICAO_DUPLICADA(4, "INVALIDO", "REGISTRO DUPLICADO");
	
	private final int codSituacaoMedicao;
	private final String tipSituacaoMedicao;
	private final String desSituacaoMedicao;
	
	SituacaoMedicaoEnum(int codSituacaoMedicao, String tipSituacaoMedicao, String desSituacaoMedicao){
		this.codSituacaoMedicao = codSituacaoMedicao;
		this.tipSituacaoMedicao = tipSituacaoMedicao;
		this.desSituacaoMedicao = desSituacaoMedicao;
	}

	public int getCodSituacaoMedicao() {
		return codSituacaoMedicao;
	}

	public String getTipSituacaoMedicao() {
		return tipSituacaoMedicao;
	}

	public String getDesSituacaoMedicao() {
		return desSituacaoMedicao;
	}	
}
