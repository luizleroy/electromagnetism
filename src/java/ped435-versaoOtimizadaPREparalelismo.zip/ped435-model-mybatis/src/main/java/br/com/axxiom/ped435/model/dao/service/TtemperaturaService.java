package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TtemperaturaMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Ttemperatura;

public class TtemperaturaService extends BaseDBPED435DAO implements TtemperaturaMapper{
	
	@Override
	public int deleteByPrimaryKey(Integer codTemperatura) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
			ret = mapper.deleteByPrimaryKey(codTemperatura);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}	
	}
	
	@Override
	public int deleteByPrimaryKey(Integer codTemperatura, SqlSession sqlSession) {
		int ret = 0;		
		TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
		ret = mapper.deleteByPrimaryKey(codTemperatura);
		sqlSession.commit();
		return ret;
		
	}

	@Override
	public int insert(Ttemperatura record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insert(Ttemperatura record, SqlSession sqlSession) {		
		int ret = 0;		
		TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
		ret = mapper.insert(record);
		sqlSession.commit();
		return ret;		
	}

	@Override
	public int insertSelective(Ttemperatura record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public int insertSelective(Ttemperatura record, SqlSession sqlSession) {		
		int ret = 0;		
		TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
		ret = mapper.insertSelective(record);
		sqlSession.commit();
		return ret;
	}

	@Override
	public Ttemperatura selectByPrimaryKey(Integer codTemperatura) {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
			Ttemperatura obj = mapper.selectByPrimaryKey(codTemperatura);
			return obj;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public Ttemperatura selectByPrimaryKey(Integer codTemperatura, SqlSession sqlSession) {	
	
		TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
		Ttemperatura obj = mapper.selectByPrimaryKey(codTemperatura);
		return obj;			
	}
	
	@Override
	public Integer selectLastPrimaryKey() {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
			Integer obj = mapper.selectLastPrimaryKey();
			if (obj == null)
				obj = 0;
			return obj;
		}finally{
			sqlSession.close();
		}		
	}

	@Override
	public Integer selectLastPrimaryKey(SqlSession sqlSession) {
		TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
		Integer obj = mapper.selectLastPrimaryKey();
		if (obj == null)
			obj = 0;
		return obj;	
	}

	@Override
	public int updateByPrimaryKeySelective(Ttemperatura record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public int updateByPrimaryKeySelective(Ttemperatura record, SqlSession sqlSession) {		
		int ret = 0;		
		TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
		ret = mapper.updateByPrimaryKeySelective(record);
		sqlSession.commit();
		return ret;		
	}

	@Override
	public int updateByPrimaryKey(Ttemperatura record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public int updateByPrimaryKey(Ttemperatura record, SqlSession sqlSession) {
		int ret = 0;
		TtemperaturaMapper mapper = sqlSession.getMapper(TtemperaturaMapper.class);
		ret = mapper.updateByPrimaryKey(record);
		sqlSession.commit();
		return ret;			
	}
}