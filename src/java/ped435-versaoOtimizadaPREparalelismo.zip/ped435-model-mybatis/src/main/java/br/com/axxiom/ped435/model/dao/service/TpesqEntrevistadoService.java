package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqEntrevistadoMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEntrevistado;

public class TpesqEntrevistadoService extends BaseDBCON435DAO implements TpesqEntrevistadoMapper{

	@Override
	public int deleteByPrimaryKey(Integer codEntrevistado) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer codEntrevistado, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEntrevistado record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEntrevistado record, SqlSession sqlSession) {
		
		int ret = 0;
		TpesqEntrevistadoMapper mapper = sqlSession.getMapper(TpesqEntrevistadoMapper.class);
		ret = mapper.insert(record);
		return ret;		
	}

	@Override
	public int insertSelective(TpesqEntrevistado record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqEntrevistado record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqEntrevistado selectByPrimaryKey(Integer codEntrevistado) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqEntrevistado selectByPrimaryKey(Integer codEntrevistado,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEntrevistado record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEntrevistado record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEntrevistado record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEntrevistado record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
