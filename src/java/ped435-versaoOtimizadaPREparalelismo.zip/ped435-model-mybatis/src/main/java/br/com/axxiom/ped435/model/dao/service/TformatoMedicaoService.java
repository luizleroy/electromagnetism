package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TformatoMedicaoMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TformatoMedicao;

public class TformatoMedicaoService extends BaseDBPED435DAO implements TformatoMedicaoMapper{

	@Override
	public int deleteByPrimaryKey(Integer codFormatoMedicao) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TformatoMedicaoMapper mapper = sqlSession.getMapper(TformatoMedicaoMapper.class);
			ret = mapper.deleteByPrimaryKey(codFormatoMedicao);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}	
	}

	@Override
	public int insert(TformatoMedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TformatoMedicaoMapper mapper = sqlSession.getMapper(TformatoMedicaoMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public int insert(TformatoMedicao record, SqlSession sqlSession) {
		int ret = 0;
		TformatoMedicaoMapper mapper = sqlSession.getMapper(TformatoMedicaoMapper.class);
		ret = mapper.insert(record);
		return ret;			
	}

	@Override
	public int insertSelective(TformatoMedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TformatoMedicaoMapper mapper = sqlSession.getMapper(TformatoMedicaoMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public TformatoMedicao selectByPrimaryKey(Integer codFormatoMedicao) {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TformatoMedicaoMapper mapper = sqlSession.getMapper(TformatoMedicaoMapper.class);
			TformatoMedicao obj = mapper.selectByPrimaryKey(codFormatoMedicao);
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public Integer selectLastPrimaryKey() {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TformatoMedicaoMapper mapper = sqlSession.getMapper(TformatoMedicaoMapper.class);
			Integer obj = mapper.selectLastPrimaryKey();
			if (obj == null)
				obj = 0;
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public Integer selectLastPrimaryKey(SqlSession sqlSession) {
		TformatoMedicaoMapper mapper = sqlSession.getMapper(TformatoMedicaoMapper.class);
		Integer obj = mapper.selectLastPrimaryKey();
		if (obj == null)
			obj = 0;
		return obj;		
	}

	@Override
	public int updateByPrimaryKeySelective(TformatoMedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TformatoMedicaoMapper mapper = sqlSession.getMapper(TformatoMedicaoMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}

	@Override
	public int updateByPrimaryKey(TformatoMedicao record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TformatoMedicaoMapper mapper = sqlSession.getMapper(TformatoMedicaoMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}	
}
