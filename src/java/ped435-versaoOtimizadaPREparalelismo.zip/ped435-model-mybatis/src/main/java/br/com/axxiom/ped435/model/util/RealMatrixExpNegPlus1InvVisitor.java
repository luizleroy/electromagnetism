/**
 * 
 */
package br.com.axxiom.ped435.model.util;

import org.apache.commons.math.linear.MatrixVisitorException;
import org.apache.commons.math.linear.RealMatrixChangingVisitor;

/**
 * @author Luiz Le Roy / lhipolito
 *
 */
public class RealMatrixExpNegPlus1InvVisitor implements RealMatrixChangingVisitor {

	/* (non-Javadoc)
	 * @see org.apache.commons.math.linear.RealMatrixChangingVisitor#start(int, int, int, int, int, int)
	 */
	@Override
	public void start(int rows, int columns, int startRow, int endRow,
			int startColumn, int endColumn) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.apache.commons.math.linear.RealMatrixChangingVisitor#visit(int, int, double)
	 */
	@Override
	public double visit(int row, int column, double value)
			throws MatrixVisitorException {
		// TODO Auto-generated method stub
		return 1./(Math.exp(-value) + 1);
	}

	/* (non-Javadoc)
	 * @see org.apache.commons.math.linear.RealMatrixChangingVisitor#end()
	 */
	@Override
	public double end() {
		// TODO Auto-generated method stub
		return 0;
	}

}
