package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqEscalaMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEscala;

public class TpesqEscalaService extends BaseDBCON435DAO implements TpesqEscalaMapper{

	@Override
	public int deleteByPrimaryKey(String codEscala) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(String codEscala, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEscala record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEscala record, SqlSession sqlSession) {
		int ret = 0;
		TpesqEscalaMapper mapper = sqlSession.getMapper(TpesqEscalaMapper.class);
		ret = mapper.insert(record);
		return ret;
	}

	@Override
	public int insertSelective(TpesqEscala record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqEscala record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqEscala selectByPrimaryKey(String codEscala) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqEscala selectByPrimaryKey(String codEscala,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEscala record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEscala record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEscala record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEscala record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
