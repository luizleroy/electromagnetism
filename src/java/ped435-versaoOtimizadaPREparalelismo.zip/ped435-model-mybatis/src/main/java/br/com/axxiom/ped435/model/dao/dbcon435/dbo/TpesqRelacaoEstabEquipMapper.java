package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqRelacaoEstabEquip;

public interface TpesqRelacaoEstabEquipMapper {
    int deleteByPrimaryKey(@Param("codEstabelecimento") Integer codEstabelecimento, @Param("codEquipamento") Integer codEquipamento);
    
    int deleteByPrimaryKey(@Param("codEstabelecimento") Integer codEstabelecimento, @Param("codEquipamento") Integer codEquipamento, SqlSession sqlSession);

    int insert(TpesqRelacaoEstabEquip record);
    
    int insert(TpesqRelacaoEstabEquip record, SqlSession sqlSession);

    int insertSelective(TpesqRelacaoEstabEquip record);
    
    int insertSelective(TpesqRelacaoEstabEquip record, SqlSession sqlSession);
}