package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqLocalUtilizadoComInd {
    private String codLocalUtilizadoComInd;

    private String desLocalUtilizadoComInd;

    public TpesqLocalUtilizadoComInd(String codLocalUtilizadoComInd, String desLocalUtilizadoComInd) {
        this.codLocalUtilizadoComInd = codLocalUtilizadoComInd;
        this.desLocalUtilizadoComInd = desLocalUtilizadoComInd;
    }

    public TpesqLocalUtilizadoComInd() {
        super();
    }

    public String getCodLocalUtilizadoComInd() {
        return codLocalUtilizadoComInd;
    }

    public void setCodLocalUtilizadoComInd(String codLocalUtilizadoComInd) {
        this.codLocalUtilizadoComInd = codLocalUtilizadoComInd;
    }

    public String getDesLocalUtilizadoComInd() {
        return desLocalUtilizadoComInd;
    }

    public void setDesLocalUtilizadoComInd(String desLocalUtilizadoComInd) {
        this.desLocalUtilizadoComInd = desLocalUtilizadoComInd;
    }
}