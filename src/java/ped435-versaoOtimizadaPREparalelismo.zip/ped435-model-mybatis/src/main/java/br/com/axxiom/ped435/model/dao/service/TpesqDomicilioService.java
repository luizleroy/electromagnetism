package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqDomicilioMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqDomicilio;

public class TpesqDomicilioService extends BaseDBCON435DAO implements TpesqDomicilioMapper{

	@Override
	public int deleteByPrimaryKey(String codTipoDomicilio) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(String codTipoDomicilio, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqDomicilio record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqDomicilio record, SqlSession sqlSession) {
		
		int ret = 0;
		TpesqDomicilioMapper mapper = sqlSession.getMapper(TpesqDomicilioMapper.class);
		ret = mapper.insert(record);
		return ret;
	}

	@Override
	public int insertSelective(TpesqDomicilio record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqDomicilio record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqDomicilio selectByPrimaryKey(String codTipoDomicilio) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqDomicilio selectByPrimaryKey(String codTipoDomicilio,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqDomicilio record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqDomicilio record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqDomicilio record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqDomicilio record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
