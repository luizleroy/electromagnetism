package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class Tmedidor {
    private String codMedidor;

    private Integer codParametroMedidor;

    private String tipProprietario;

    public Tmedidor(String codMedidor, Integer codParametroMedidor, String tipProprietario) {
        this.codMedidor = codMedidor;
        this.codParametroMedidor = codParametroMedidor;
        this.tipProprietario = tipProprietario;
    }

    public Tmedidor() {
        super();
    }

    public String getCodMedidor() {
        return codMedidor;
    }

    public void setCodMedidor(String codMedidor) {
        this.codMedidor = codMedidor;
    }

    public Integer getCodParametroMedidor() {
        return codParametroMedidor;
    }

    public void setCodParametroMedidor(Integer codParametroMedidor) {
        this.codParametroMedidor = codParametroMedidor;
    }

    public String getTipProprietario() {
        return tipProprietario;
    }

    public void setTipProprietario(String tipProprietario) {
        this.tipProprietario = tipProprietario;
    }
}