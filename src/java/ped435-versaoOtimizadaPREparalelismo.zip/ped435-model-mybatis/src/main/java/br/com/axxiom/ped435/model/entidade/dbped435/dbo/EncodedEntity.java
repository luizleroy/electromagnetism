package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class EncodedEntity {
	private double bestBest;
	private int[] nNeur;
//	TODO private double wNorma;
//	TODO private double wBNorma;
	private double[] bestBestArray;

	public int[] getnNeur() {
		return nNeur;
	}

	public void setnNeur(int[] nNeur) {
		this.nNeur = nNeur;
	}

	public double getBestBest() {
		return bestBest;
	}

	public void setBestBest(double bestBest) {
		this.bestBest = bestBest;
	}

	// TODO criar representações para os vetores de peso...
	// private Matrix[] matrizW; // contém os pesos
	// private Matrix[] matrizWb; // contém os bias
	public double[] getBestBestArray() {
		return bestBestArray;
	}

	public void setBestBestArray(double[] bestBestArray) {
		this.bestBestArray = bestBestArray;
	}
}
