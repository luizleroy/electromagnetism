package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TsituacaoMedicao;

public interface TsituacaoMedicaoMapper {
	
    int deleteByPrimaryKey(Integer codSituacaoMedicao);
    
    int deleteByPrimaryKey(Integer codSituacaoMedicao, SqlSession sqlSession);
    
    int insert(TsituacaoMedicao record);
    
    int insert(TsituacaoMedicao record, SqlSession sqlSession);

    int insertSelective(TsituacaoMedicao record);
    
    int insertSelective(TsituacaoMedicao record, SqlSession sqlSession);

    TsituacaoMedicao selectByPrimaryKey(Integer codSituacaoMedicao);
    
    TsituacaoMedicao selectByPrimaryKey(Integer codSituacaoMedicao, SqlSession sqlSession);
    
    Integer selectLastPrimaryKey();
    
    Integer selectLastPrimaryKey(SqlSession sqlSession);

    int updateByPrimaryKeySelective(TsituacaoMedicao record);
    
    int updateByPrimaryKeySelective(TsituacaoMedicao record, SqlSession sqlSession);

    int updateByPrimaryKey(TsituacaoMedicao record);
    
    int updateByPrimaryKey(TsituacaoMedicao record, SqlSession sqlSession);
}