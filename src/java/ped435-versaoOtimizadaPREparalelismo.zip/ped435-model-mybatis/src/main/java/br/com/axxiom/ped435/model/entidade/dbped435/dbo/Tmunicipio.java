package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class Tmunicipio {
    private Integer codMunicipio;

    private Integer codMunicipioGdis;

    private String nomMunicipio;

    public Tmunicipio(Integer codMunicipio, Integer codMunicipioGdis, String nomMunicipio) {
        this.codMunicipio = codMunicipio;
        this.codMunicipioGdis = codMunicipioGdis;
        this.nomMunicipio = nomMunicipio;
    }

    public Tmunicipio() {
        super();
    }

    public Integer getCodMunicipio() {
        return codMunicipio;
    }

    public void setCodMunicipio(Integer codMunicipio) {
        this.codMunicipio = codMunicipio;
    }

    public Integer getCodMunicipioGdis() {
        return codMunicipioGdis;
    }

    public void setCodMunicipioGdis(Integer codMunicipioGdis) {
        this.codMunicipioGdis = codMunicipioGdis;
    }

    public String getNomMunicipio() {
        return nomMunicipio;
    }

    public void setNomMunicipio(String nomMunicipio) {
        this.nomMunicipio = nomMunicipio;
    }
}