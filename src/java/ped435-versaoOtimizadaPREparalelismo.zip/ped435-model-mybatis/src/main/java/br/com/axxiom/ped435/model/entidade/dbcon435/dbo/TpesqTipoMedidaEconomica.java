package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqTipoMedidaEconomica {
    private String codTipoMedidaEconomica;

    private String desTipoMedidaEconomica;

    public TpesqTipoMedidaEconomica(String codTipoMedidaEconomica, String desTipoMedidaEconomica) {
        this.codTipoMedidaEconomica = codTipoMedidaEconomica;
        this.desTipoMedidaEconomica = desTipoMedidaEconomica;
    }

    public TpesqTipoMedidaEconomica() {
        super();
    }

    public String getCodTipoMedidaEconomica() {
        return codTipoMedidaEconomica;
    }

    public void setCodTipoMedidaEconomica(String codTipoMedidaEconomica) {
        this.codTipoMedidaEconomica = codTipoMedidaEconomica;
    }

    public String getDesTipoMedidaEconomica() {
        return desTipoMedidaEconomica;
    }

    public void setDesTipoMedidaEconomica(String desTipoMedidaEconomica) {
        this.desTipoMedidaEconomica = desTipoMedidaEconomica;
    }
}