package br.com.axxiom.ped435.model.entidade.dbped435.dbo;


public class VPesq implements Cloneable{
	private Long row;
	private Integer codEntrevistado;
	private Integer qtdEquipamentos;
	private Double potWatt;
	
	public Long getRow() {
		return row;
	}

	public Integer getCodEntrevistado() {
		return codEntrevistado;
	}

	public Integer getQtdEquipamentos() {
		return qtdEquipamentos;
	}

	public Double getPotWatt() {
		return potWatt;
	}

	public VPesq(Long row, Integer codEntrevistado, Integer qtdEquipamentos,
			Double potWatt) {
		super();
		this.row = row;
		this.codEntrevistado = codEntrevistado;
		this.qtdEquipamentos = qtdEquipamentos;
		this.potWatt = potWatt;
	}
	
	@Override
	public String toString() {
//		Field[] fields = VPesq.class.getDeclaredFields();
		StringBuilder target = new StringBuilder("\n|");
//		for (int i = 0; i < fields.length; i++) {
//			target.append(fields[i].getName());
//			target.append("|");
//		}
//		target.append("\n|");
		target.append(row);
		target.append("|");
		target.append(codEntrevistado);
		target.append("|");
		target.append(qtdEquipamentos);
		target.append("|");
		target.append(potWatt);
		target.append("|");
		return target.toString();
	}
}
