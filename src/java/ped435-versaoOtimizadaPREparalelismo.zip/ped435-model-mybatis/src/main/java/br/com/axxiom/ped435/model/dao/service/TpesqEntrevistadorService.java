package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqEntrevistadorMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEntrevistador;

public class TpesqEntrevistadorService extends BaseDBCON435DAO implements TpesqEntrevistadorMapper{

	@Override
	public int deleteByPrimaryKey(Integer codEntrevistador) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer codEntrevistador,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEntrevistador record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEntrevistador record, SqlSession sqlSession) {
		
		int ret = 0;
		TpesqEntrevistadorMapper mapper = sqlSession.getMapper(TpesqEntrevistadorMapper.class);
		ret = mapper.insert(record);
		return ret;
	}

	@Override
	public int insertSelective(TpesqEntrevistador record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqEntrevistador record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqEntrevistador selectByPrimaryKey(Integer codEntrevistador) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqEntrevistador selectByPrimaryKey(Integer codEntrevistador,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEntrevistador record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEntrevistador record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEntrevistador record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEntrevistador record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
