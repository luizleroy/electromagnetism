package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqTipoMedidaEconomicaMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqTipoMedidaEconomica;

public class TpesqTipoMedidaEconomicaService extends BaseDBCON435DAO implements TpesqTipoMedidaEconomicaMapper{

	@Override
	public int deleteByPrimaryKey(String codTipoMedidaEconomica) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(String codTipoMedidaEconomica,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqTipoMedidaEconomica record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqTipoMedidaEconomica record, SqlSession sqlSession) {
		int ret = 0;
		TpesqTipoMedidaEconomicaMapper mapper = sqlSession.getMapper(TpesqTipoMedidaEconomicaMapper.class);
		ret = mapper.insert(record);
		return ret;		
	}

	@Override
	public int insertSelective(TpesqTipoMedidaEconomica record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqTipoMedidaEconomica record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqTipoMedidaEconomica selectByPrimaryKey(
			String codTipoMedidaEconomica) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqTipoMedidaEconomica selectByPrimaryKey(
			String codTipoMedidaEconomica, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqTipoMedidaEconomica record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqTipoMedidaEconomica record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqTipoMedidaEconomica record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqTipoMedidaEconomica record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
