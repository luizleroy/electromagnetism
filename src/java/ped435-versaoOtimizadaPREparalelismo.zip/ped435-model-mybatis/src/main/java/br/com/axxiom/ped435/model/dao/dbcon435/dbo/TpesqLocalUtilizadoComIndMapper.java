package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqLocalUtilizadoComInd;

public interface TpesqLocalUtilizadoComIndMapper {

	int deleteByPrimaryKey(String codLocalUtilizadoComInd);
	
	int deleteByPrimaryKey(String codLocalUtilizadoComInd, SqlSession sqlSession);

    int insert(TpesqLocalUtilizadoComInd record);
    
    int insert(TpesqLocalUtilizadoComInd record, SqlSession sqlSession);

    int insertSelective(TpesqLocalUtilizadoComInd record);
    
    int insertSelective(TpesqLocalUtilizadoComInd record, SqlSession sqlSession);

    TpesqLocalUtilizadoComInd selectByPrimaryKey(String codLocalUtilizadoComInd);
    
    TpesqLocalUtilizadoComInd selectByPrimaryKey(String codLocalUtilizadoComInd, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqLocalUtilizadoComInd record);
    
    int updateByPrimaryKeySelective(TpesqLocalUtilizadoComInd record, SqlSession sqlSession);
    
    int updateByPrimaryKey(TpesqLocalUtilizadoComInd record);

    int updateByPrimaryKey(TpesqLocalUtilizadoComInd record, SqlSession sqlSession);
}