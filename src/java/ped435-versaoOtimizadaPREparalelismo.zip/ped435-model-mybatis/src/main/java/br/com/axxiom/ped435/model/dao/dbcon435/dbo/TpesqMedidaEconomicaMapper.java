package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqMedidaEconomica;

public interface TpesqMedidaEconomicaMapper {
	
    int deleteByPrimaryKey(Integer codMedidaEconomica);
    
    int deleteByPrimaryKey(Integer codMedidaEconomica, SqlSession sqlSession);

    int insert(TpesqMedidaEconomica record);
    
    int insert(TpesqMedidaEconomica record, SqlSession sqlSession);

    int insertSelective(TpesqMedidaEconomica record);
    
    int insertSelective(TpesqMedidaEconomica record, SqlSession sqlSession);

    TpesqMedidaEconomica selectByPrimaryKey(Integer codMedidaEconomica);
    
    TpesqMedidaEconomica selectByPrimaryKey(Integer codMedidaEconomica, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqMedidaEconomica record);
    
    int updateByPrimaryKeySelective(TpesqMedidaEconomica record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqMedidaEconomica record);
    
    int updateByPrimaryKey(TpesqMedidaEconomica record, SqlSession sqlSession);
}