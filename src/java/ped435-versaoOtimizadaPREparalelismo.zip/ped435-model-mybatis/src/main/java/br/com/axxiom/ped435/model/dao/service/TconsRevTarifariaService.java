package br.com.axxiom.ped435.model.dao.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TconsRevTarifariaMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TconsRevTarifaria;

public class TconsRevTarifariaService extends BaseDBCON435DAO implements TconsRevTarifariaMapper{
	
	@Override
	public int deleteByPrimaryKey(String numInstalacao) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(String numInstalacao, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TconsRevTarifaria record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TconsRevTarifaria record, SqlSession sqlSession) {
		
		int ret = 0;
		TconsRevTarifariaMapper mapper = sqlSession.getMapper(TconsRevTarifariaMapper.class);
		ret = mapper.insert(record);
		return ret;
	}

	@Override
	public int insertSelective(TconsRevTarifaria record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TconsRevTarifaria record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TconsRevTarifaria selectByPrimaryKey(String numInstalacao) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		TconsRevTarifaria obj = new TconsRevTarifaria();
		try{
			TconsRevTarifariaMapper mapper = sqlSession.getMapper(TconsRevTarifariaMapper.class);
			obj = mapper.selectByPrimaryKey(numInstalacao);
			return obj;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public TconsRevTarifaria selectByPrimaryKey(String numInstalacao,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TconsRevTarifaria record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TconsRevTarifaria record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TconsRevTarifaria record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TconsRevTarifaria record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public List<String> selectClientsByNumInstalacao() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<String> obj = new ArrayList<String>();
		try{
			TconsRevTarifariaMapper mapper = sqlSession.getMapper(TconsRevTarifariaMapper.class);
			obj = mapper.selectClientsByNumInstalacao();
			return obj;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public List<String> selectComboClasse(){
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<String> obj = new ArrayList<String>();
		try{
			TconsRevTarifariaMapper mapper = sqlSession.getMapper(TconsRevTarifariaMapper.class);
			obj = mapper.selectComboClasse();
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public List<String> selectComboFaixa() { // not in use!
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<String> obj = new ArrayList<String>();
		try{
			TconsRevTarifariaMapper mapper = sqlSession.getMapper(TconsRevTarifariaMapper.class);
			obj = mapper.selectComboFaixa();
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public List<String> selectComboTensao() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<String> obj = new ArrayList<String>();
		try{
			TconsRevTarifariaMapper mapper = sqlSession.getMapper(TconsRevTarifariaMapper.class);
			obj = mapper.selectComboTensao();
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public List<TconsRevTarifaria> selectAll() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<TconsRevTarifaria> obj = new ArrayList<TconsRevTarifaria>();
		try{
			TconsRevTarifariaMapper mapper = sqlSession.getMapper(TconsRevTarifariaMapper.class);
			obj = mapper.selectAll();
			return obj;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public List<String> selectComboDesRamoAtivSor() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<String> obj = new ArrayList<String>();
		try{
			TconsRevTarifariaMapper mapper = sqlSession.getMapper(TconsRevTarifariaMapper.class);
			obj = mapper.selectComboDesRamoAtivSor();
			return obj;
		}finally{
			sqlSession.close();
		}
	}
}
