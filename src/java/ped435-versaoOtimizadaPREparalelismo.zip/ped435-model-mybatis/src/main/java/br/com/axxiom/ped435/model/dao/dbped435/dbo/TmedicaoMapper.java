package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedicao;

public interface TmedicaoMapper {
    
	int deleteByPrimaryKey(Long codMedicao);

    int insert(Tmedicao record);
    
    int insert(Tmedicao record, SqlSession sqlSession);

    int insertSelective(Tmedicao record);

    Tmedicao selectByPrimaryKey(Long codMedicao);
    
    List<Tmedicao> selectListByNumInstalacao(String numInstalacao);
    
    Long selectLastPrimaryKey();
    
    Long selectLastPrimaryKey(SqlSession sqlSession);

    int updateByPrimaryKeySelective(Tmedicao record);

    int updateByPrimaryKey(Tmedicao record);
    
    int updateByPrimaryKey(Tmedicao record, SqlSession sqlSession);
}