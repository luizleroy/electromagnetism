package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEscala;

public interface TpesqEscalaMapper {
	
    int deleteByPrimaryKey(String codEscala);
    
    int deleteByPrimaryKey(String codEscala, SqlSession sqlSession);

    int insert(TpesqEscala record);
    
    int insert(TpesqEscala record, SqlSession sqlSession);

    int insertSelective(TpesqEscala record);
    
    int insertSelective(TpesqEscala record, SqlSession sqlSession);

    TpesqEscala selectByPrimaryKey(String codEscala);
    
    TpesqEscala selectByPrimaryKey(String codEscala, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqEscala record);
    
    int updateByPrimaryKeySelective(TpesqEscala record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqEscala record);
    
    int updateByPrimaryKey(TpesqEscala record, SqlSession sqlSession);
}