package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqUsoEquipamentoMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqUsoEquipamento;

public class TpesqUsoEquipamentoService extends BaseDBCON435DAO implements TpesqUsoEquipamentoMapper{

	@Override
	public int deleteByPrimaryKey(Integer codUsoEquipamento) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer codUsoEquipamento,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqUsoEquipamento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqUsoEquipamento record, SqlSession sqlSession) {
		int ret = 0;
		TpesqUsoEquipamentoMapper mapper = sqlSession.getMapper(TpesqUsoEquipamentoMapper.class);
		ret = mapper.insert(record);
		return ret;
	}

	@Override
	public int insertSelective(TpesqUsoEquipamento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqUsoEquipamento record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqUsoEquipamento selectByPrimaryKey(Integer codUsoEquipamento) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqUsoEquipamento selectByPrimaryKey(Integer codUsoEquipamento,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqUsoEquipamento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqUsoEquipamento record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqUsoEquipamento record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqUsoEquipamento record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
