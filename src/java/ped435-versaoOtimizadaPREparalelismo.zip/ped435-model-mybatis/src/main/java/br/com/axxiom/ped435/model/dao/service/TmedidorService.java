package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TmedidorMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedidor;

public class TmedidorService extends BaseDBPED435DAO implements TmedidorMapper{
	
	@Override
	public int deleteByPrimaryKey(String codMedidor) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
			ret = mapper.deleteByPrimaryKey(codMedidor);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}
	}
	
	@Override
	public int deleteByPrimaryKey(String codMedidor, SqlSession sqlSession) {
		int ret = 0;		
		TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
		ret = mapper.deleteByPrimaryKey(codMedidor);
		sqlSession.commit();
		return ret;
	}

	@Override
	public int insert(Tmedidor record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public int insert(Tmedidor record, SqlSession sqlSession) {
		int ret = 0;
		TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
		ret = mapper.insert(record);
		return ret;			
	}

	@Override
	public int insertSelective(Tmedidor record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public int insertSelective(Tmedidor record, SqlSession sqlSession) {
		int ret = 0;
		TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
		ret = mapper.insertSelective(record);
		sqlSession.commit();
		return ret;
	}

	@Override
	public Tmedidor selectByPrimaryKey(String codMedidor) {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
			Tmedidor obj = mapper.selectByPrimaryKey(codMedidor);
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public Tmedidor selectByPrimaryKey(String codMedidor, SqlSession sqlSession) {
		
		TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
		Tmedidor obj = mapper.selectByPrimaryKey(codMedidor);
		return obj;
	}
	
	@Override
	public Integer selectLastPrimaryKey() {
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
			Integer obj = mapper.selectLastPrimaryKey();
			if (obj == null)
				obj = 0;
			return obj;
		}finally{
			sqlSession.close();
		}
	}
	
	@Override
	public Integer selectLastPrimaryKey(SqlSession sqlSession) {
				 
		TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
		Integer obj = mapper.selectLastPrimaryKey();
		if (obj == null)
			obj = 0;
		return obj;		
	}

	@Override
	public int updateByPrimaryKeySelective(Tmedidor record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
	
	@Override
	public int updateByPrimaryKeySelective(Tmedidor record, SqlSession sqlSession) {
		int ret = 0;		
		TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
		ret = mapper.updateByPrimaryKeySelective(record);
		sqlSession.commit();
		return ret;		
	}

	@Override
	public int updateByPrimaryKey(Tmedidor record) {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}	
	}
		
	@Override
	public int updateByPrimaryKey(Tmedidor record, SqlSession sqlSession) {
		
		int ret = 0;
		TmedidorMapper mapper = sqlSession.getMapper(TmedidorMapper.class);
		ret = mapper.updateByPrimaryKey(record);
		return ret;		
	}
}