package br.com.axxiom.ped435.model.dao.enums;

/**
 * Enum FormatoMedicaoEnum - Contempla todos os registros que podem ser utilizados na tabela
 * TformatoMedicao
 * 
 * @author ssoares - Sólon Soares - solon.soares@axxiom.com.br
 * Axxiom Solucoes Tecnologicas S.A. - www.axxiom.com.br
 */
public enum FormatoMedicaoEnum {

	FORMATO_MEDICAO_3_CANAIS(1, "string", "intervalo|hora-inicial|canal1|grandeza|medicoes|canal2|grandeza|medicoes|canal3|grandeza|medicoes"),
	FORMATO_MEDICAO_6_CANAIS(2, "string", "intervalo|hora-inicial|canal1|grandeza|medicoes|canal2|grandeza|medicoes|canal3|grandeza|medicoes|canal4|grandeza|medicoes|canal5|grandeza|medicoes|canal6|grandeza|medicoes");
	
	private final int codFormatoMedicao;
	private final String tipFormatoMedicao;
	private final String desFormatoMedicao;
	
	FormatoMedicaoEnum(int codFormatoMedicao, String tipFormatoMedicao, String desFormatoMedicao){
		this.codFormatoMedicao = codFormatoMedicao;
		this.tipFormatoMedicao = tipFormatoMedicao;
		this.desFormatoMedicao = desFormatoMedicao;
	}
	
	public int getCodFormatoMedicao(){
		return this.codFormatoMedicao;
	}
	
	public String getTipFormatoMedicao(){
		return this.tipFormatoMedicao;
	}
	
	public String getDesFormatoMedicao(){
		return this.desFormatoMedicao;
	}
}
