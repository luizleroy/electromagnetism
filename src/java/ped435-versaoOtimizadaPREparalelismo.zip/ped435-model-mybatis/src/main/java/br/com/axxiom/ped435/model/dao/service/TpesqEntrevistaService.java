package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqEntrevistaMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqEntrevista;

public class TpesqEntrevistaService extends BaseDBCON435DAO implements TpesqEntrevistaMapper{

	@Override
	public int deleteByPrimaryKey(Integer codEntrevista) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer codEntrevista, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEntrevista record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqEntrevista record, SqlSession sqlSession) {
		
		int ret = 0;
		TpesqEntrevistaMapper mapper = sqlSession.getMapper(TpesqEntrevistaMapper.class);
		ret = mapper.insert(record);
		return ret;
	}

	@Override
	public int insertSelective(TpesqEntrevista record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqEntrevista record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqEntrevista selectByPrimaryKey(Integer codEntrevista) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqEntrevista selectByPrimaryKey(Integer codEntrevista,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEntrevista record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqEntrevista record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEntrevista record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqEntrevista record, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
