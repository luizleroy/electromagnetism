package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

import java.util.Date;

public class Tferiado {
    private Integer codFeriado;

    private Date datFeriado;

    private String desFeriado;

    private String tipFeriado;

    public Tferiado(Integer codFeriado, Date datFeriado, String desFeriado, String tipFeriado) {
        this.codFeriado = codFeriado;
        this.datFeriado = datFeriado;
        this.desFeriado = desFeriado;
        this.tipFeriado = tipFeriado;
    }

    public Tferiado() {
        super();
    }

    public Integer getCodFeriado() {
        return codFeriado;
    }

    public void setCodFeriado(Integer codFeriado) {
        this.codFeriado = codFeriado;
    }

    public Date getDatFeriado() {
        return datFeriado;
    }

    public void setDatFeriado(Date datFeriado) {
        this.datFeriado = datFeriado;
    }

    public String getDesFeriado() {
        return desFeriado;
    }

    public void setDesFeriado(String desFeriado) {
        this.desFeriado = desFeriado;
    }

    public String getTipFeriado() {
        return tipFeriado;
    }

    public void setTipFeriado(String tipFeriado) {
        this.tipFeriado = tipFeriado;
    }
}