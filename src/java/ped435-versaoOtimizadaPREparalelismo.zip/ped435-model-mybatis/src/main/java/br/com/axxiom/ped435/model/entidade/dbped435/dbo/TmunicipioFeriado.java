package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public class TmunicipioFeriado {
    private Integer codMunicipio;

    private Integer codFeriado;

    public TmunicipioFeriado(Integer codMunicipio, Integer codFeriado) {
        this.codMunicipio = codMunicipio;
        this.codFeriado = codFeriado;
    }

    public TmunicipioFeriado() {
        super();
    }

    public Integer getCodMunicipio() {
        return codMunicipio;
    }

    public void setCodMunicipio(Integer codMunicipio) {
        this.codMunicipio = codMunicipio;
    }

    public Integer getCodFeriado() {
        return codFeriado;
    }

    public void setCodFeriado(Integer codFeriado) {
        this.codFeriado = codFeriado;
    }
}