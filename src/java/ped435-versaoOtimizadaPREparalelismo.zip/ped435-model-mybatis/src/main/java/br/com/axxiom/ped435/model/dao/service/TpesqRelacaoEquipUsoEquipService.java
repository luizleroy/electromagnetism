package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqRelacaoEquipUsoEquipMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqRelacaoEquipUsoEquip;

public class TpesqRelacaoEquipUsoEquipService extends BaseDBCON435DAO implements TpesqRelacaoEquipUsoEquipMapper{

	@Override
	public int deleteByPrimaryKey(Integer codUsoEquipamento,
			Integer codEquipamento) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(Integer codUsoEquipamento,
			Integer codEquipamento, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqRelacaoEquipUsoEquip record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqRelacaoEquipUsoEquip record, SqlSession sqlSession) {
		int ret = 0;
		TpesqRelacaoEquipUsoEquipMapper mapper = sqlSession.getMapper(TpesqRelacaoEquipUsoEquipMapper.class);
		ret = mapper.insert(record);
		return ret;
	}

	@Override
	public int insertSelective(TpesqRelacaoEquipUsoEquip record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqRelacaoEquipUsoEquip record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
