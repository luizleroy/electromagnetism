package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

import java.util.Date;

public class TconsRevTarifaria {
    private String numInstalacao;

    private String desClasse;

    private String desFaixaSorteio;

    private String desRamoAtivCad;

    private String desRamoAtivSor;

    private String nomConsumidor;

    private String desNivelTensao;

    private String desTarifa;

    private String nomArquivoMedicao;

    private Date datInicial;

    private Date datFinal;

    private Integer qtdDias;

    private String desSituacao;

    private String desFaixaDefinitiva;

    private String desGrandCanal1;

    private String desGrandCanal2;

    private String desGrandCanal3;

    private String desRegiao;

    private Integer valFuso;

    private Integer valAbs;

    private Integer valOrd;

    public TconsRevTarifaria(String numInstalacao, String desClasse, String desFaixaSorteio, String desRamoAtivCad, String desRamoAtivSor, String nomConsumidor, String desNivelTensao, String desTarifa, String nomArquivoMedicao, Date datInicial, Date datFinal, Integer qtdDias, String desSituacao, String desFaixaDefinitiva, String desGrandCanal1, String desGrandCanal2, String desGrandCanal3, String desRegiao, Integer valFuso, Integer valAbs, Integer valOrd) {
        this.numInstalacao = numInstalacao;
        this.desClasse = desClasse;
        this.desFaixaSorteio = desFaixaSorteio;
        this.desRamoAtivCad = desRamoAtivCad;
        this.desRamoAtivSor = desRamoAtivSor;
        this.nomConsumidor = nomConsumidor;
        this.desNivelTensao = desNivelTensao;
        this.desTarifa = desTarifa;
        this.nomArquivoMedicao = nomArquivoMedicao;
        this.datInicial = datInicial;
        this.datFinal = datFinal;
        this.qtdDias = qtdDias;
        this.desSituacao = desSituacao;
        this.desFaixaDefinitiva = desFaixaDefinitiva;
        this.desGrandCanal1 = desGrandCanal1;
        this.desGrandCanal2 = desGrandCanal2;
        this.desGrandCanal3 = desGrandCanal3;
        this.desRegiao = desRegiao;
        this.valFuso = valFuso;
        this.valAbs = valAbs;
        this.valOrd = valOrd;
    }

    public TconsRevTarifaria() {
        super();
    }

    public String getNumInstalacao() {
        return numInstalacao;
    }

    public void setNumInstalacao(String numInstalacao) {
        this.numInstalacao = numInstalacao;
    }

    public String getDesClasse() {
        return desClasse;
    }

    public void setDesClasse(String desClasse) {
        this.desClasse = desClasse;
    }

    public String getDesFaixaSorteio() {
        return desFaixaSorteio;
    }

    public void setDesFaixaSorteio(String desFaixaSorteio) {
        this.desFaixaSorteio = desFaixaSorteio;
    }

    public String getDesRamoAtivCad() {
        return desRamoAtivCad;
    }

    public void setDesRamoAtivCad(String desRamoAtivCad) {
        this.desRamoAtivCad = desRamoAtivCad;
    }

    public String getDesRamoAtivSor() {
        return desRamoAtivSor;
    }

    public void setDesRamoAtivSor(String desRamoAtivSor) {
        this.desRamoAtivSor = desRamoAtivSor;
    }

    public String getNomConsumidor() {
        return nomConsumidor;
    }

    public void setNomConsumidor(String nomConsumidor) {
        this.nomConsumidor = nomConsumidor;
    }

    public String getDesNivelTensao() {
        return desNivelTensao;
    }

    public void setDesNivelTensao(String desNivelTensao) {
        this.desNivelTensao = desNivelTensao;
    }

    public String getDesTarifa() {
        return desTarifa;
    }

    public void setDesTarifa(String desTarifa) {
        this.desTarifa = desTarifa;
    }

    public String getNomArquivoMedicao() {
        return nomArquivoMedicao;
    }

    public void setNomArquivoMedicao(String nomArquivoMedicao) {
        this.nomArquivoMedicao = nomArquivoMedicao;
    }

    public Date getDatInicial() {
        return datInicial;
    }

    public void setDatInicial(Date datInicial) {
        this.datInicial = datInicial;
    }

    public Date getDatFinal() {
        return datFinal;
    }

    public void setDatFinal(Date datFinal) {
        this.datFinal = datFinal;
    }

    public Integer getQtdDias() {
        return qtdDias;
    }

    public void setQtdDias(Integer qtdDias) {
        this.qtdDias = qtdDias;
    }

    public String getDesSituacao() {
        return desSituacao;
    }

    public void setDesSituacao(String desSituacao) {
        this.desSituacao = desSituacao;
    }

    public String getDesFaixaDefinitiva() {
        return desFaixaDefinitiva;
    }

    public void setDesFaixaDefinitiva(String desFaixaDefinitiva) {
        this.desFaixaDefinitiva = desFaixaDefinitiva;
    }

    public String getDesGrandCanal1() {
        return desGrandCanal1;
    }

    public void setDesGrandCanal1(String desGrandCanal1) {
        this.desGrandCanal1 = desGrandCanal1;
    }

    public String getDesGrandCanal2() {
        return desGrandCanal2;
    }

    public void setDesGrandCanal2(String desGrandCanal2) {
        this.desGrandCanal2 = desGrandCanal2;
    }

    public String getDesGrandCanal3() {
        return desGrandCanal3;
    }

    public void setDesGrandCanal3(String desGrandCanal3) {
        this.desGrandCanal3 = desGrandCanal3;
    }

    public String getDesRegiao() {
        return desRegiao;
    }

    public void setDesRegiao(String desRegiao) {
        this.desRegiao = desRegiao;
    }

    public Integer getValFuso() {
        return valFuso;
    }

    public void setValFuso(Integer valFuso) {
        this.valFuso = valFuso;
    }

    public Integer getValAbs() {
        return valAbs;
    }

    public void setValAbs(Integer valAbs) {
        this.valAbs = valAbs;
    }

    public Integer getValOrd() {
        return valOrd;
    }

    public void setValOrd(Integer valOrd) {
        this.valOrd = valOrd;
    }
}