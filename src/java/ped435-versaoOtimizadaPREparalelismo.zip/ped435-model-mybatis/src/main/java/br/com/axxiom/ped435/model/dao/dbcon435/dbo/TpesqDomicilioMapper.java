package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqDomicilio;

public interface TpesqDomicilioMapper {
    int deleteByPrimaryKey(String codDomicilio);
    
    int deleteByPrimaryKey(String codDomicilio, SqlSession sqlSession);

    int insert(TpesqDomicilio record);
    
    int insert(TpesqDomicilio record, SqlSession sqlSession);

    int insertSelective(TpesqDomicilio record);
    
    int insertSelective(TpesqDomicilio record, SqlSession sqlSession);

    TpesqDomicilio selectByPrimaryKey(String codDomicilio);
    
    TpesqDomicilio selectByPrimaryKey(String codDomicilio, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TpesqDomicilio record);
    
    int updateByPrimaryKeySelective(TpesqDomicilio record, SqlSession sqlSession);

    int updateByPrimaryKey(TpesqDomicilio record);
    
    int updateByPrimaryKey(TpesqDomicilio record, SqlSession sqlSession);
}