package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TconsRevTarifaria;

public interface TconsRevTarifariaMapper {
	
    int deleteByPrimaryKey(String numInstalacao);
    
    int deleteByPrimaryKey(String numInstalacao, SqlSession sqlSession);

    int insert(TconsRevTarifaria record);
    
    int insert(TconsRevTarifaria record, SqlSession sqlSession);

    int insertSelective(TconsRevTarifaria record);
    
    int insertSelective(TconsRevTarifaria record, SqlSession sqlSession);

    TconsRevTarifaria selectByPrimaryKey(String numInstalacao);
    
    TconsRevTarifaria selectByPrimaryKey(String numInstalacao, SqlSession sqlSession);

    int updateByPrimaryKeySelective(TconsRevTarifaria record);
    
    int updateByPrimaryKeySelective(TconsRevTarifaria record, SqlSession sqlSession);

    int updateByPrimaryKey(TconsRevTarifaria record);
    
    int updateByPrimaryKey(TconsRevTarifaria record, SqlSession sqlSession);

    List<String> selectClientsByNumInstalacao();

    List<String> selectComboClasse();
	List<String> selectComboFaixa();
	
	List<String> selectComboTensao();

	List<TconsRevTarifaria> selectAll();

	List<String> selectComboDesRamoAtivSor();

}