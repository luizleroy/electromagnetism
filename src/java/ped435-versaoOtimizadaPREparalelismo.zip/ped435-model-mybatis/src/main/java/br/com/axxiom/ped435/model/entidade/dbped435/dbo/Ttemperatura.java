package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

import java.util.Date;

public class Ttemperatura {
    private Integer codTemperatura;

    private Integer codMunicipio;

    private Date datTemperatura;

    private Double valTemperaturaMax;

    private Double valTemperaturaMin;

    public Ttemperatura(Integer codTemperatura, Integer codMunicipio, Date datTemperatura, Double valTemperaturaMax, Double valTemperaturaMin) {
        this.codTemperatura = codTemperatura;
        this.codMunicipio = codMunicipio;
        this.datTemperatura = datTemperatura;
        this.valTemperaturaMax = valTemperaturaMax;
        this.valTemperaturaMin = valTemperaturaMin;
    }

    public Ttemperatura() {
        super();
    }

    public Integer getCodTemperatura() {
        return codTemperatura;
    }

    public void setCodTemperatura(Integer codTemperatura) {
        this.codTemperatura = codTemperatura;
    }

    public Integer getCodMunicipio() {
        return codMunicipio;
    }

    public void setCodMunicipio(Integer codMunicipio) {
        this.codMunicipio = codMunicipio;
    }

    public Date getDatTemperatura() {
        return datTemperatura;
    }

    public void setDatTemperatura(Date datTemperatura) {
        this.datTemperatura = datTemperatura;
    }

    public Double getValTemperaturaMax() {
        return valTemperaturaMax;
    }

    public void setValTemperaturaMax(Double valTemperaturaMax) {
        this.valTemperaturaMax = valTemperaturaMax;
    }

    public Double getValTemperaturaMin() {
        return valTemperaturaMin;
    }

    public void setValTemperaturaMin(Double valTemperaturaMin) {
        this.valTemperaturaMin = valTemperaturaMin;
    }
}