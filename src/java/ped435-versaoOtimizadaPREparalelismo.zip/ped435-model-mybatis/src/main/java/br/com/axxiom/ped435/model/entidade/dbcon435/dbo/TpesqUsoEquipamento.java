package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqUsoEquipamento {
    private Integer codUsoEquipamento;

    private String desUsoEquipamento;

    public TpesqUsoEquipamento(Integer codUsoEquipamento, String desUsoEquipamento) {
        this.codUsoEquipamento = codUsoEquipamento;
        this.desUsoEquipamento = desUsoEquipamento;
    }

    public TpesqUsoEquipamento() {
        super();
    }

    public Integer getCodUsoEquipamento() {
        return codUsoEquipamento;
    }

    public void setCodUsoEquipamento(Integer codUsoEquipamento) {
        this.codUsoEquipamento = codUsoEquipamento;
    }

    public String getDesUsoEquipamento() {
        return desUsoEquipamento;
    }

    public void setDesUsoEquipamento(String desUsoEquipamento) {
        this.desUsoEquipamento = desUsoEquipamento;
    }
}