package br.com.axxiom.ped435.model.dao.dbped435.dbo;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tequipamento;

public interface TequipamentoMapper {
    
	int deleteByPrimaryKey(Integer codEquipamento);
	
	int deleteByPrimaryKey(Integer codEquipamento, SqlSession sqlSession);

    int insert(Tequipamento record);
    
    int insert(Tequipamento record, SqlSession sqlSession);

    int insertSelective(Tequipamento record);
    
    int insertSelective(Tequipamento record, SqlSession sqlSession);

    Tequipamento selectByPrimaryKey(Integer codEquipamento);
    
    Tequipamento selectByPrimaryKey(Integer codEquipamento, SqlSession sqlSession);
    
    Integer selectLastPrimaryKey();
    
    Integer selectLastPrimaryKey(SqlSession sqlSession);

    int updateByPrimaryKeySelective(Tequipamento record);
    
    int updateByPrimaryKeySelective(Tequipamento record, SqlSession sqlSession);

    int updateByPrimaryKey(Tequipamento record);
    
    int updateByPrimaryKey(Tequipamento record, SqlSession sqlSession);
}