package br.com.axxiom.ped435.model.dao.service;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbcon435.dbo.TpesqRendaMensalFamiliarMapper;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqRendaMensalFamiliar;

public class TpesqRendaMensalFamiliarService extends BaseDBCON435DAO implements TpesqRendaMensalFamiliarMapper{

	@Override
	public int deleteByPrimaryKey(String codRendaMensalFamiliar) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByPrimaryKey(String codRendaMensalFamiliar,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqRendaMensalFamiliar record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insert(TpesqRendaMensalFamiliar record, SqlSession sqlSession) {
		int ret = 0;
		TpesqRendaMensalFamiliarMapper mapper = sqlSession.getMapper(TpesqRendaMensalFamiliarMapper.class);
		ret = mapper.insert(record);
		return ret;	
	}

	@Override
	public int insertSelective(TpesqRendaMensalFamiliar record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertSelective(TpesqRendaMensalFamiliar record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public TpesqRendaMensalFamiliar selectByPrimaryKey(
			String codRendaMensalFamiliar) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TpesqRendaMensalFamiliar selectByPrimaryKey(
			String codRendaMensalFamiliar, SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqRendaMensalFamiliar record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKeySelective(TpesqRendaMensalFamiliar record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqRendaMensalFamiliar record) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateByPrimaryKey(TpesqRendaMensalFamiliar record,
			SqlSession sqlSession) {
		// TODO Auto-generated method stub
		return 0;
	}

}
