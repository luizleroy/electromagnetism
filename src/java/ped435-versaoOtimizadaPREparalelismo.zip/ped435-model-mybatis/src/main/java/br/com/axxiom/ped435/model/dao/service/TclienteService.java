package br.com.axxiom.ped435.model.dao.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.TclienteMapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tcliente;

public class TclienteService extends BaseDBPED435DAO implements TclienteMapper {

	@Override
	public int deleteByPrimaryKey(Integer codCliente) {
		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
			ret = mapper.deleteByPrimaryKey(codCliente);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();			
		}		
	}
	
	@Override
	public int deleteByPrimaryKey(Integer codCliente, SqlSession sqlSession) {
		
		int ret = 0;
		TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
		ret = mapper.deleteByPrimaryKey(codCliente);
		return ret;				
	}
	
	@Override
	public int insert(Tcliente record) {
		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
			ret = mapper.insert(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}		
	}
	
	@Override
	public int insert(Tcliente record, SqlSession sqlSession) {
		
		int ret = 0;
		TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
		ret = mapper.insert(record);
		return ret;				
	}

	@Override
	public int insertSelective(Tcliente record) {
		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
			ret = mapper.insertSelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}		
	}
	
	@Override
	public int insertSelective(Tcliente record, SqlSession sqlSession) {
		
		int ret = 0;
		TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
		ret = mapper.insertSelective(record);
		return ret;			
	}

	@Override
	public Tcliente selectByPrimaryKey(Integer codCliente) {
		
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
			Tcliente obj = mapper.selectByPrimaryKey(codCliente);
			return obj;
		}finally{
			sqlSession.close();
		}		
	}
	
	@Override
	public Tcliente selectByPrimaryKey(Integer codCliente, SqlSession sqlSession) {
		
		TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
		Tcliente obj = mapper.selectByPrimaryKey(codCliente);
		return obj;		
	}
	
	@Override
	public Integer selectLastPrimaryKey() {
		
		SqlSession sqlSession = sqlSessionFactory.openSession();		 
		try{
			TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
			Integer obj = mapper.selectLastPrimaryKey();
			if (obj == null)
				obj = 0;
			return obj;
		}finally{
			sqlSession.close();
		}		
	}
	
	@Override
	public Integer selectLastPrimaryKey(SqlSession sqlSession) {
		
		TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
		Integer obj = mapper.selectLastPrimaryKey();
		if (obj == null)
			obj = 0;
		return obj;				
	}
	
	@Override
	public List<String> selectListClientesAprovadosRevisaoTarifaria(){
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<String> obj = new ArrayList<String>();
		try{
			TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
			obj = mapper.selectListClientesAprovadosRevisaoTarifaria();
			return obj;
		}finally{
			sqlSession.close();
		}
	}

	@Override
	public int updateByPrimaryKeySelective(Tcliente record) {
		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
			ret = mapper.updateByPrimaryKeySelective(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}		
	}
	
	@Override
	public int updateByPrimaryKeySelective(Tcliente record, SqlSession sqlSession) {
		
		int ret = 0;
		TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
		ret = mapper.updateByPrimaryKeySelective(record);
		return ret;		
	}

	@Override
	public int updateByPrimaryKey(Tcliente record) {
		
		SqlSession sqlSession = sqlSessionFactory.openSession();
		int ret = 0;
		try{
			TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
			ret = mapper.updateByPrimaryKey(record);
			sqlSession.commit();
			return ret;
		}finally{
			sqlSession.close();
		}		
	}

	@Override
	public int updateByPrimaryKey(Tcliente record, SqlSession sqlSession) {
		int ret = 0;
		TclienteMapper mapper = sqlSession.getMapper(TclienteMapper.class);
		ret = mapper.updateByPrimaryKey(record);
		return ret;
	}
}
