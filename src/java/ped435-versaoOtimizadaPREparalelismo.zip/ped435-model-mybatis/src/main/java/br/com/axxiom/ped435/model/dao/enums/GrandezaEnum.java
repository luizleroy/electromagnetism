package br.com.axxiom.ped435.model.dao.enums;

/**
 * Enum GrandezaEnum - Este Enum contem todos os valores que serão utilizados pela tabela tgradeza
 * @author ssoares - Sólon Soares - solon.soares@axxiom.com.br<br />
 * Axxiom Soluções Tecnológicas S.A. - www.axxiom.com.br<br /> 
 */
public enum GrandezaEnum {
	
	KWH_DIRETO(1, "KWH_DIRETO", "KILO WATT HORA DIRETO."),
	KWH_REVERSO(2, "KWH_REVERSO", "KILO WATT HORA REVERSO."),
	KVARH_INDUTIVO_DIRETO(3, "KVARH_INDUTIVO_DIRETO", "KILO VOLT ALMPERE REATIVO INDUTIVO DIRETO."),
	KVARH_INDUTIVO_REVERSO(4, "KVARH_INDUTIVO_REVERSO", "KILO VOLT ALMPERE REATIVO INDUTIVO REVERSO."),
	KVARH_CAPACITIVO_DIRETO(5, "KVARH_CAPACITIVO_DIRETO", "KILO VOLT ALMPERE REATIVO CAPACITIVO DIRETO."),
	KVARH_CAPACITIVO_REVERSO(6, "KVARH_CAPACITIVO_REVERSO", "KILO VOLT ALMPERE REATIVO CAPACITIVO REVERSO."),
	KVAR_INSTANTANEO(7, "KVAR_INSTANTANEO", "KILO VOLT AMPERE REATIVO INSTANTANEO"),
	KW_INSTANTANEO(8, "KW_INSTANTANEO", "KILO WATT INSTANTANEO"),
	KV_INSTANTANEO(9, "KV_INSTANTANEO", "KILO VOLT INSTANTANEO");
	
	
	private final int codGrandeza;
	private final String sigGrandeza;
	private final String desGrandeza;
	
	GrandezaEnum(int codGrandeza, String sigGrandeza, String desGrandeza){
		this.codGrandeza = codGrandeza;
		this.sigGrandeza = sigGrandeza;
		this.desGrandeza = desGrandeza;
	}
	
	/**
	 * Metodo getCodGrandeza - Este metodo retorna o valor do campo codGrandeza da tabela tgrandeza.
	 * @return - Retorna um inteiro contendo o codigo da grandeza.
	 */
	public int getCodGrandeza(){
		return this.codGrandeza;
	}

	/**
	 * Metodo getSigGrandeza - Este metodo retorna o valor do campo sigGrandeza da tabela tgrandeza. 
	 * @return - Retorna uma string contendo a sigla da grandeza.
	 */
	public String getSigGrandeza() {
		return sigGrandeza;
	}

	/**
	 * Metodo getDesGrandeza - Este metodo retorna o valor do campo desGrandeza da tabela tgrandeza.
	 * @return
	 */
	public String getDesGrandeza() {
		return desGrandeza;
	}
}
