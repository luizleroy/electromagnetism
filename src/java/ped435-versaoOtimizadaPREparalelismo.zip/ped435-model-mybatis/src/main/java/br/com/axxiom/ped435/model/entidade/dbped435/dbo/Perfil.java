package br.com.axxiom.ped435.model.entidade.dbped435.dbo;

public enum Perfil {
ALL,BOI,METAL
}
