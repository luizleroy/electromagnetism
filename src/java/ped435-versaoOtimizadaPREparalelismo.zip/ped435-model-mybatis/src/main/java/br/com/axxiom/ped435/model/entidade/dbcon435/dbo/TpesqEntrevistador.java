package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqEntrevistador {
    private Integer codEntrevistador;

    private String nomEntrevistador;

    public TpesqEntrevistador(Integer codEntrevistador, String nomEntrevistador) {
        this.codEntrevistador = codEntrevistador;
        this.nomEntrevistador = nomEntrevistador;
    }

    public TpesqEntrevistador() {
        super();
    }

    public Integer getCodEntrevistador() {
        return codEntrevistador;
    }

    public void setCodEntrevistador(Integer codEntrevistador) {
        this.codEntrevistador = codEntrevistador;
    }

    public String getNomEntrevistador() {
        return nomEntrevistador;
    }

    public void setNomEntrevistador(String nomEntrevistador) {
        this.nomEntrevistador = nomEntrevistador;
    }
}