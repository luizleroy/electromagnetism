package br.com.axxiom.ped435.model.entidade.dbcon435.dbo;

public class TpesqDomicilio {
    private String codDomicilio;

    private String desDomicilio;

    public TpesqDomicilio(String codDomicilio, String desDomicilio) {
        this.codDomicilio = codDomicilio;
        this.desDomicilio = desDomicilio;
    }

    public TpesqDomicilio() {
        super();
    }

    public String getCodDomicilio() {
        return codDomicilio;
    }

    public void setCodDomicilio(String codDomicilio) {
        this.codDomicilio = codDomicilio;
    }

    public String getDesDomicilio() {
        return desDomicilio;
    }

    public void setDesDomicilio(String desDomicilio) {
        this.desDomicilio = desDomicilio;
    }
}