package br.com.axxiom.ped435.model.dao.dbcon435.dbo;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TpesqRelacaoEquipUsoEquip;

public interface TpesqRelacaoEquipUsoEquipMapper {
    int deleteByPrimaryKey(@Param("codUsoEquipamento") Integer codUsoEquipamento, @Param("codEquipamento") Integer codEquipamento);
    
    int deleteByPrimaryKey(@Param("codUsoEquipamento") Integer codUsoEquipamento, @Param("codEquipamento") Integer codEquipamento, SqlSession sqlSession);

    int insert(TpesqRelacaoEquipUsoEquip record);
    
    int insert(TpesqRelacaoEquipUsoEquip record, SqlSession sqlSession);

    int insertSelective(TpesqRelacaoEquipUsoEquip record);
    
    int insertSelective(TpesqRelacaoEquipUsoEquip record, SqlSession sqlSession);
}