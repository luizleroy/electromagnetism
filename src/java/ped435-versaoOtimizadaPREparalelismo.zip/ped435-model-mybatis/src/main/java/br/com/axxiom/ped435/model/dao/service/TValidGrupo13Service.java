package br.com.axxiom.ped435.model.dao.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.model.dao.dbped435.dbo.Grupo13FCMapper;
import br.com.axxiom.ped435.model.dao.dbped435.dbo.Grupo13Mapper;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidGrupo13;

public class TValidGrupo13Service extends BaseDBPED435DAO implements
		Grupo13Mapper {
	@Override
	public List<TValidGrupo13> select() {
		SqlSession sqlSession = sqlSessionFactory.openSession();
		List<TValidGrupo13> obj = new ArrayList<TValidGrupo13>();
		try {
			Grupo13Mapper mapper = sqlSession
					.getMapper(Grupo13Mapper.class);
			obj = mapper.select();
			return obj;
		} finally {
			sqlSession.close();
		}
	}
}