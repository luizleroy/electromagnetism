package br.com.axxiom.ped435.view.ui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.util.Const;

/**
 * original: http://zetcode.com/gfx/java2d/basicdrawing/
 * 
 * @param <V>
 * 
 */
class Surface<V> extends JPanel {
	/**
	 * 
	 */
	private static Logger log = Logger.getLogger(Surface.class);
	private static final long serialVersionUID = 1L;
	private Color[] colors = { Color.blue, Color.blue, Color.red };
	private int colorsCount = colors.length;
	private Graphics2D g2d;
	Random random = new Random();
	private static final int cap = 10000;

	private Color getColor() {
		if (colorsCount < 1) {
			colorsCount = this.colors.length - 1;
		} else {
			colorsCount--;
		}
		return colors[colorsCount];
	}

	private void doDrawing(Graphics g) {
		g2d = (Graphics2D) g;
		Dimension size = getSize();
		Insets insets = getInsets();

		int width = size.width - insets.left - insets.right;
		int height = size.height - insets.top - insets.bottom;
		log.info(String.format("Dim: %d x %d", width, height));
		
		g2d.setColor(getColor());
		graphParable(width, height);
		g2d.setColor(getColor());
		graphParable(width, height);
	}
	
	private void graphParable(int width, int height) {

	}

	private void graphIdentity2(int width, int height) {
		for (int i = 0; i < cap; i++) {
			double dotXY = random.nextDouble();
			int x = Math.round(Math.round((-dotXY+1)*width)); // (-dot + 1) para plotar left-rigth
			int y = Math.round(Math.round(dotXY*height));
			g2d.drawLine(x, y, x, y);
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		log.info("FIXME -> two renderization!");
		super.paintComponent(g);
		doDrawing(g);
	}
}

public class Points extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Points() {
		initUI();
	}

	private void initUI() {
		setTitle("Points");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		add(new Surface<Object>());
		setSize(350, 250);
		setLocationRelativeTo(null);
	}

	public static void main(String[] args) {
		Const.setLog();
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Points ps = new Points();
				ps.setVisible(true);
			}
		});
	}
}