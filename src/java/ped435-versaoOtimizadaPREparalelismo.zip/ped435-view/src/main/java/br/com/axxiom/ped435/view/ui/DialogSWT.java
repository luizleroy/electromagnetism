/**
 * 
 */
package br.com.axxiom.ped435.view.ui;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import br.com.axxiom.ped435.controller.util.Config;
import br.com.axxiom.ped435.view.Query;

/**
 * @author luizleroy
 * 
 */

public class DialogSWT extends Dialog {
	// para manter a janela com um tamanho fixo (150 colunas)
	private static final int MaxEmptyCombo = 145; // 145 + (as strings de
													// "TODOS") = 150 colunas
	private static final boolean IS_VISIBLE_COMBO = true;
	private Query query = null;
	private String message;
	private List<List<String>> allDataCombo = new ArrayList<List<String>>();
	private List<Combo> allCombo = new ArrayList<Combo>();
	private String dataComboBuffer[];
	public String dataCombo[];

	public List<Combo> getAllCombo() {
		return allCombo;
	}

	// stile: SWT.DIALOG_TRIM | SWT.APPLICATION_MODAL (?)
	public DialogSWT(Shell parent) {
		super(parent, SWT.DIALOG_TRIM);
		setText(Config.getKey("text"));
		setMessage(Config.getKey("message"));
	}

	public DialogSWT(Shell parent, List<List<String>> dataCombo) {
		this(parent);
		this.allDataCombo = dataCombo;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void open() {
		Shell shell = new Shell(getParent(), getStyle());
		shell.setText(getText());
		// se não for definido via argumento os combos, criar janela modo debug (consulta livre!)
		if (allDataCombo.isEmpty()) {
			createDebugComponents(shell);
		} else {
			createReleaseComponents(shell);
		}
		shell.pack();
		shell.open();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	public Query getQuery() {
		return query;
	}

	/**
	 * @param allCombo
	 *            the allCombo to set
	 */
	public void setAllCombo(List<Combo> allCombo) {
		this.allCombo = allCombo;
	}

	private void createReleaseComponents(final Shell shell) {
		dataComboBuffer = new String[allDataCombo.size()];
		for (int j = 0; j < allDataCombo.size(); j++) {
			final Combo combo;
			combo = new Combo(shell, SWT.DROP_DOWN);
			List<String> c = allDataCombo.get(j);
			for (String string : c) {
				combo.add(string);
			}
			String configString = StringUtils.leftPad("", MaxEmptyCombo, ' ');
			// Para configurar o tamanho da janela:
			combo.add(Config.getKey("all.classes") + configString);
			combo.setSelection(combo.getSelection());
			// combo.select(combo.getItems().length - 1);
			// TODO -> quantidade confusa de dados de combo (dataCombo,
			// dataAllCombo...)
			// eh possível enviar o combo à camada de controle? (ele não fica
			// "travado")
			combo.select(0);
			dataComboBuffer[j] = c.get(0);
			combo.setVisible(IS_VISIBLE_COMBO);
			allCombo.add(combo);
		}
		for (final Combo combo : allCombo) {
			combo.addSelectionListener(new SelectionAdapter() {
				@Override
				public void widgetSelected(SelectionEvent e) {
					String data = combo.getText();
					dataComboBuffer[allCombo.indexOf(combo)] = data;
				};
			});
		}

		shell.setLayout(new GridLayout());
		GridData gridData = new GridData(GridData.HORIZONTAL_ALIGN_END);
		Button ok = new Button(shell, SWT.PUSH);
		ok.setText(Config.getKey("ok"));
		ok.setLayoutData(gridData);
		ok.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				dataCombo = dataComboBuffer;
				shell.close();
			}
		});
		shell.setDefaultButton(ok);
	}

	private void createDebugComponents(final Shell shell) {
		shell.setLayout(new GridLayout());
		GridData gridData = new GridData();
		Label label = new Label(shell, SWT.NONE);
		label.setLayoutData(gridData);
		label.setText(message);
		gridData = new GridData();
		final Text text = new Text(shell, SWT.BORDER);
		text.setLayoutData(gridData);
		text.setText(Config.getKey("default.query"));
		gridData = new GridData(GridData.HORIZONTAL_ALIGN_END);
		Button ok = new Button(shell, SWT.PUSH);
		ok.setText(Config.getKey("ok"));
		ok.setLayoutData(gridData);
		ok.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent event) {
				query = new Query(new StringBuffer(text.getText()));
				shell.close();
			}
		});
		shell.setDefaultButton(ok);
	}
}
