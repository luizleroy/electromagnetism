/**
 * 
 */
package br.com.axxiom.ped435.view;


/**
 * @author luizleroy
 * 
 */
public class Query extends AbstractQuery {

	public Query(StringBuffer string) {
		this.buffer = string;
	}

	public Query(String string) {
		this.buffer = new StringBuffer(string);
	}

	/**
	 * @param args
	 */

	public boolean isQuery() {
		return buffer != null;
	}

}
