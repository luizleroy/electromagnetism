/**
 * 
 */
package br.com.axxiom.ped435.view;

/**
 * @author luizleroy
 *
 */
public interface InterfaceQuery {
}
