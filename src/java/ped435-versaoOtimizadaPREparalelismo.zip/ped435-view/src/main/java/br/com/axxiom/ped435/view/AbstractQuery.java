/**
 * 
 */
package br.com.axxiom.ped435.view;

/**
 * @author luizleroy
 *
 */
public abstract class AbstractQuery implements InterfaceQuery {

	protected StringBuffer buffer;

	public String toString() {
		//return getClass().getName() + "@" + Integer.toHexString(hashCode());
//		SELECT '' AS DUAL
//		FROM [master].[dbo].[spt_fallback_db]
		return buffer.toString();
	    }

}
