package br.com.axxiom.ped435.view.ui;

public class FactoryPrototype {
	public interface Window {
		Window cloan();

		Object getDialog();

		void setDialog(Object dialog);
	}

	static class WindowDesktop implements Window {
		private DialogSWT dialog;

		public DialogSWT getDialog() {
			return dialog;
		}

		public Window cloan() {
			return new WindowDesktop();
		}

		public String toString() {
			return "Window @ Desktop";
		}

		public void setDialog(Object dialog) {
			this.dialog = (DialogSWT) dialog;
		}
	}

	static class WindowWeb implements Window {
		// FIXME: setar throws new NotImplement() ?
		private Object dialog = null;

		public Window cloan() {
			return new WindowWeb();
		}

		public String toString() {
			return "Window @ Web";
		}

		public Object getDialog() {
			return dialog;
		}

		public void setDialog(Object dialog) {
			// TODO Auto-generated method stub
		}
	}

	public static class FactoryCollection {
		private static java.util.Map<String, Window> prototypes = new java.util.HashMap<String, Window>();
		static {
			prototypes.put("Desktop", new WindowDesktop());
			prototypes.put("Web", new WindowWeb());
		}

		public static Window makeObject(String s) {
			return prototypes.get(s).cloan();
		}
	}

	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			//print(FactoryCollection.makeObject(args[i]) + "  ");
		}
	}
}