package br.com.axxiom.ped435.view;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import au.com.bytecode.opencsv.CSVWriter;
import br.com.axxiom.ped435.model.dao.enums.FormatoMedicaoEnum;
import br.com.axxiom.ped435.model.util.DataBase;
import br.com.axxiom.ped435.view.Query;

/**
 * @author luizleroy
 * 
 */
public class ForDirectConnection {
	private static final char separator = ';';
	private static String path = "misc/data.csv";
	private static Logger log = Logger.getLogger(ForDirectConnection.class);

	public static void gerarArquivo(Query query) {
		String dbUrl = DataBase.getKey("database.dbped435.url") + ";user=" + DataBase.getKey("database.dbped435.username") + ";password=" 
				+ DataBase.getKey("database.dbped435.password") + ";";
		String dbClass = DataBase.getKey("database.dbped435.driver");
		int sep = path.lastIndexOf('/');
		File theDir = new File(path.substring(0, sep));
		if (!theDir.exists()) {
			theDir.mkdir();
		}
		try {
			CSVWriter writer = new CSVWriter(new FileWriter(path), separator);
			String[] entries = {FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS.toString(), FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS.getDesFormatoMedicao()};
			writer.writeNext(entries);
			Class.forName(dbClass);
			Connection con = DriverManager.getConnection(dbUrl);
			if (!(query != null && query.isQuery())) {
				String[] e1 = {"Pesquisa SEM resultados!"};
				writer.writeNext(e1);
				writer.close();
				log.info("Pesquisa SEM resultados!");
				return;
			}
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query.toString());
			writer.writeAll(rs, true);
			writer.close();
			con.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			throw new RuntimeException("Close \"" + path + "\" file!");
		} 
	}
}