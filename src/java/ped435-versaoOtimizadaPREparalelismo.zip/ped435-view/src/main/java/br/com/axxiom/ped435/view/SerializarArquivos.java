package br.com.axxiom.ped435.view;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.com.axxiom.ped435.model.util.DataBase;

public class SerializarArquivos {

	List<List<String>> combos = new ArrayList<List<String>>();
	List<String> numInst = new ArrayList<String>();
	
	public SerializarArquivos() {
		String dbUrl = DataBase.getKey("database.dbped435.url") + ";user="
				+ DataBase.getKey("database.dbped435.username") + ";password="
				+ DataBase.getKey("database.dbped435.password") + ";";
		String dbClass = DataBase.getKey("database.dbcon435.driver");
		try {
			Class.forName(dbClass);
			Connection con = DriverManager.getConnection(dbUrl);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(DataBase.getKey("in.query"));
			while(rs.next()) {
				
			}
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<List<String>> getListListCombo() {
		return null;
	}

	public List<String> getListClientsByNumInstalacao(String[] dataCombo) {
		// TODO Auto-generated method stub
		return null;
	}

}
