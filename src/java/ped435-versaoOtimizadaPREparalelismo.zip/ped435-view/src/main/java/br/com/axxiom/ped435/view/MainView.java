/**
 * 
 */
package br.com.axxiom.ped435.view;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

import au.com.bytecode.opencsv.CSVWriter;
import br.com.axxiom.ped435.controller.util.Config;
import br.com.axxiom.ped435.model.util.DataBase;
import br.com.axxiom.ped435.util.Const;
import br.com.axxiom.ped435.view.ui.DialogSWT;

/**
 * [D435(2012-2014)]
 * [Aneel 2010*] Cálculo e validação de Pinst. *Verificar versão mais nova - Verificar Definição FC / FD via material previamente levantado...
 * [Kohonen 2000] Tipologia: como agrupar clientes de acordo com a razão social?
 * [VUOLO 1996] Filtro Estatístico das Amostras
 * [Pierre] Base de Dados / Estrutura Relacional
 * [P&D435(2012-2014)] Rede Neural Parametrizável
 * [Google 2014] Análise de desempenho no tratamento matricial
 * Acesso Paralelo ao Banco de Dados
 * Definição de linguagem (Java8&(c|JavaCompile))
 * SID: Webservice Cemig
 * Aplicação de paralelismo
 */

/**
 * @author luizleroy
 * 
 */
public class MainView {
	private static boolean IS_DEBUG = false;
	private static Logger log = Logger.getLogger(MainView.class);

	public static void main(String[] args) throws IOException {
		IS_DEBUG = false; // java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments().toString()
		// .indexOf("-agentlib:jdwp") > 0;
		log.info("Data inicial: " + new Date());

		Const.setLog();
		
		execute(args);

		// deprected
		// executar();

		log.info("Fim: " + new Date());
		log.info("Enter para sair.");
		System.in.read();
	}

	private static void execute(String args[]) {
		Display display = new Display();
		Shell shell = new Shell(display);
		DialogSWT dialogSWT;
		// create dynamic combos (input line commands)
		ArrayList<List<String>> dataCombos = directCombos(args);
		dialogSWT = new DialogSWT(shell, dataCombos);
		dialogSWT.open();
		log.info("Pesquisa: " + new Date());
		if (dialogSWT.dataCombo != null) {
			String finalQuery = "";
			for (int i = 0; i < args.length; i++) {
				if (!dialogSWT.dataCombo[i].trim().equals(
						Config.getKey("all.classes"))) {
					finalQuery += args[i] + " = '" + dialogSWT.dataCombo[i]
							+ "' and ";
				}
			}

			String query = Config.getKey("in.query");
			if (!finalQuery.isEmpty()) {
				query += "where "
						+ finalQuery.substring(0, finalQuery.length() - 4)
						+ ")";
			} else {
				query += ")";
			}

			gerarArquivo(query);
		}
		display.dispose();

	}

	private static ArrayList<List<String>> directCombos(String args[]) {
		ArrayList<List<String>> target = new ArrayList<List<String>>();
		for (int i = 0; i < args.length; i++) {
			ArrayList<String> combo = directCombos(args[i]);
			target.add(combo);

		}
		return target;
	}

	private static ArrayList<String> directCombos(String field) {
		ArrayList<String> combo = new ArrayList<String>();
		String dbUrl = DataBase.getKey("database.dbped435.url") + ";user="
				+ DataBase.getKey("database.dbped435.username") + ";password="
				+ DataBase.getKey("database.dbped435.password") + ";";
		String dbClass = DataBase.getKey("database.dbped435.driver");
		try {
			Class.forName(dbClass);
			Connection con = DriverManager.getConnection(dbUrl);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT DISTINCT #FIELD# FROM TCONS_REV_TARIFARIA WHERE #FIELD# IS NOT NULL"
							.replaceAll("#FIELD#", field));
			while (rs.next()) {
				combo.add(rs.getString(field));
			}
			con.close();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return combo;
	}

	// private static void executar() {
	// Display display = new Display();
	// Shell shell = new Shell(display);
	// DialogSWT dialogSWT;
	// Query query = null;
	// if (IS_DEBUG) {
	// dialogSWT = new DialogSWT(shell);
	// dialogSWT.open();
	// query = dialogSWT.getQuery();
	// } else {
	// SerializarArquivos serializarArquivos = new SerializarArquivos();
	// List<List<String>> dataCombo = serializarArquivos.getListListCombo();
	// dialogSWT = new DialogSWT(shell, dataCombo);
	// dialogSWT.open();
	// log.info("Pesquisa: " + new Date());
	// if (dialogSWT.dataCombo != null) {
	// List<String> clients =
	// serializarArquivos.getListClientsByNumInstalacao(dialogSWT.dataCombo);
	// if (clients.size() > 0) {
	// String clientsArray[] = new String[clients.size()];
	// clients.toArray(clientsArray);
	// String in = java.util.Arrays.toString(clientsArray);
	// in = in.replace('[', '(').replace(']', ')');
	// query = new Query(Config.getKey("in.query").concat(in));
	// }
	// }
	// }
	// ForDirectConnection.gerarArquivo(query);
	// display.dispose();
	// }

	private static void gerarArquivo(String query) {
		final char separator = ';';
		String path = "misc/data.csv";
		String dbUrl = DataBase.getKey("database.dbped435.url") + ";user="
				+ DataBase.getKey("database.dbped435.username") + ";password="
				+ DataBase.getKey("database.dbped435.password") + ";";
		String dbClass = DataBase.getKey("database.dbped435.driver");
		int sep = path.lastIndexOf('/');
		File theDir = new File(path.substring(0, sep));
		if (!theDir.exists()) {
			theDir.mkdir();
		}
		try {
			CSVWriter writer = new CSVWriter(new FileWriter(path), separator);
			// String[] entries = {
			// FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS.toString(),
			// FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS.getDesFormatoMedicao()
			// };
			// writer.writeNext(entries);
			Class.forName(dbClass);
			Connection con = DriverManager.getConnection(dbUrl);
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			String[] header = new String[rsmd.getColumnCount() + 1];
			for (int i = 1; i < rsmd.getColumnCount() + 1; i++) {
				header[i - 1] = rsmd.getColumnName(i);
			}
			writer.writeNext(header);
			while (rs.next()) {
				String[] line = new String[rsmd.getColumnCount()];
				for (int i = 1; i < rsmd.getColumnCount(); i++) {
					line[i - 1] = rs.getString(i);
				}
				String[] measure = rs.getString(rsmd.getColumnCount()).split(
						"\\|");
				int aLen = line.length;
				int bLen = measure.length;
				String[] entries = new String[aLen + bLen];
				System.arraycopy(line, 0, entries, 0, aLen);
				System.arraycopy(measure, 0, entries, aLen, bLen);
				writer.writeNext(entries);
			}
			writer.close();
			con.close();
			// String[] e1 = { "Pesquisa SEM resultados!" };
			// writer.writeNext(e1);
			// writer.close();
			// log.info("Pesquisa SEM resultados!");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			throw new RuntimeException("Close \"" + path + "\" file!");
		}
	}
}
