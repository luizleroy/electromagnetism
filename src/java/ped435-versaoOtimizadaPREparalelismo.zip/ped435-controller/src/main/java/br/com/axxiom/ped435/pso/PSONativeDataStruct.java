package br.com.axxiom.ped435.pso;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.util.ArrayUtils;
//import br.com.axxiom.ped435.Tests;
import br.com.axxiom.ped435.util.Const;

// FIXME: para alternar o uso desta classe, entre a parte de testes (funções no artigo de Molga) e a RNA é preciso, manualmente realizar trocas:
// QUATRO TROCAS: entre RNA.func <-> Tests.func / (1) função ff(double[][]) e (2,3,4) no início da função pso().
public class PSONativeDataStruct {

	private static final double ERROR_STOP = 5e-2;
	private static final int PER_CENT = 100;
	private static final int stopNow = Const.loop*50/PER_CENT; // Aqui devo aumentar (o stopNow) para iterar mais!!! TODO -> como chegar neste valor percentual???
	private static int contadorStopCondition = 0;
	private static Logger log = Logger.getLogger(PSONativeDataStruct.class);
	
	private static double[] ff(double[][] shifts) {
		double[] target = new double[shifts.length];
		for (int i = 0; i < shifts.length; i++) {
			target[i] = Const.func.get(shifts[i]);
		}
		return target;
	}

	public static double[] pso() {
		contadorStopCondition = 0;
		// initialization
		double shifts[][] = new double[Const.dots][Const.dims];
		double velocities[][] = new double[Const.dots][Const.dims];
		for (int i = 0; i < Const.dims; i++) {
			for (int j = 0; j < Const.dots; j++) {
				double r1 = Const.random.nextDouble();
				shifts[j][i] = Const.func.getUpValue()[i]
						- (Const.func.getUpValue()[i] - Const.func.getDnValue()[i])
						* r1;
				double r2 = Const.random.nextDouble();
				// FIXME como adaptar estes números mágicos?
				velocities[j][i] = 1. - (1. - (-1.)) * r2;
			}
		}

		double gBest[] = new double[Const.loop + 1]; // OneMoreValue
		double s_gBest[][] = new double[Const.loop + 1][Const.dims]; // OneMoreValue
		double ff[] = new double[Const.dots];
		double s_pBest[][] = shifts.clone();
		double pBest[] = PSONativeDataStruct.ff(shifts);

		int indice = ArrayUtils.findMinIndex(pBest);
		gBest[0] = pBest[indice];
		s_gBest[0] = shifts[indice].clone();
		// end initialization

		// algorithm
		int toGBest = Const.loop; // se não ocorrer a condição de parada, vai apontar para Const.loop + 1 ...
		double w = 1.;
		for (int j = 0; j < Const.loop; j++) {
			w = Const.W1 - ((Const.W1 - Const.W2) * (j + 1)) / Const.loop;
			for (int t = 0; t < Const.dots; t++) {
				for (int i = 0; i < Const.dims; i++) {
					velocities[t][i] = w * velocities[t][i];
					velocities[t][i] += Const.c1 * Const.random.nextDouble()
							* (s_pBest[t][i] - shifts[t][i]);
					velocities[t][i] += Const.c2 * Const.random.nextDouble()
							* (s_gBest[j][i] - shifts[t][i]);
					shifts[t][i] = shifts[t][i] + velocities[t][i];
				}
			}

			// mutation
			for (int i = 0; i < Const.nMut; i++) {
				int s_dots = Const.random.nextInt(Const.dots);
				int s_dim = Const.random.nextInt(Const.dims);
				shifts[s_dots][s_dim] = shifts[s_dots][s_dim]
						+ shifts[s_dots][s_dim]
						* (2 * Const.random.nextDouble() - 1);
			}

			ff = PSONativeDataStruct.ff(shifts);

			for (int i = 0; i < Const.dots; i++) {
				if (pBest[i] > ff[i]) {
					pBest[i] = ff[i];
					for (int d = 0; d < Const.dims; d++) {
						s_pBest[i][d] = shifts[i][d];
					}
				}
			}

			int index = ArrayUtils.findMinIndex(pBest);
			Double min = pBest[index];

			if (gBest[j] > min) {
				gBest[j + 1] = min;
				s_gBest[j + 1] = shifts[index].clone();
			} else {
				gBest[j + 1] = gBest[j];
				s_gBest[j + 1] = s_gBest[j].clone();
			}
			
			// IMPORTANTE: FINALMENTE EXPLORANDO CONDIÇÃO DE PARADA!
			if(stopCondition(gBest,j) > stopNow) {
				toGBest = j;
				toGBest++;
				log.debug(String.format("Convergência na iteração: %,d | loop: %,d",toGBest, Const.loop));
				break;
			}
		}
		double[] target = s_gBest[toGBest];
		// end alghoritm
		// log.info(gBest[Tests.loop]);
		return target ; // o ++ à ESQUERDA do toGBest indica o real lugar do BEST
	}

	private static int stopCondition(double[] gBest, int j) {
		if ( Math.abs((gBest[j] - gBest[j + 1]) / (gBest[j] + Double.MIN_VALUE)) < ERROR_STOP) {
			contadorStopCondition++;
		} else {
			contadorStopCondition = 0;
		}
		return contadorStopCondition;
	}
}