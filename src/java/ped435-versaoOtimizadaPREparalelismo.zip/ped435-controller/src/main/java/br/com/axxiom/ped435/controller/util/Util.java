/**
 * 
 */
package br.com.axxiom.ped435.controller.util;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Date;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.model.util.Matrix;

/**
 * @author lhipolito
 * 
 */
public class Util {
	public static Logger log = Logger.getLogger(Util.class);
	private static final String PATH_JSON = "src/test/resources/json/";
	private static final String JSON = ".json";
	private static SimpleDateFormat formatador = new SimpleDateFormat("_YYYY_MM_dd HH-mm-ss-SSS");
	public static String formatNameFileEncoding(Class<?> clazz) {
		String name = clazz.getCanonicalName();
		String pack[] = name.toString().split("\\.");
		return pack[pack.length - 1];
	}

	/**
	 * Retorna um nome de arquivo específico para uma determinada data.
	 * 
	 * @param obj
	 * @return
	 */
	public static String createURIJson(Object obj, Date date) {
		return PATH_JSON.concat(formatNameFileEncoding(obj.getClass())).concat(formatador.format(date)).concat(JSON);
	}

	public static String createURIJson(Object obj) {
		return PATH_JSON.concat(formatNameFileEncoding(obj.getClass())).concat(JSON);
	}

	public static void main(String[] args) {
		Util util = new Util();
		System.out.println(createURIJson(util));
	}

	/**
	 * @param x
	 *            é o expoente, que indica o tamanho da tabela verdade: se x =
	 *            2, temos quatro linhas na tabela, para x = 4 temos 16 linhas.
	 * @return
	 */
	public static Matrix[] createXorDataByXSquare(int x) {
		Double len = Math.pow(2, x);
		int lenn = len.intValue();
	
		// TODO make Test: Se quiser fazer na mão, fixo para o padrão de 4 entradas:
		// double[][] targetx = new double[x][len.intValue()];
		// double[][] targety = new double[1][len.intValue()];
		// targetx[0][0] = 0.; targetx[1][0] = 0.; targety[0][0] = 0.;
		// targetx[0][1] = 0.; targetx[1][1] = 1.; targety[0][1] = 1.;
		// targetx[0][2] = 1.; targetx[1][2] = 0.; targety[0][2] = 1.;
		// targetx[0][3] = 1.; targetx[1][3] = 1.; targety[0][3] = 0.;
	
		// Matrix xx = new Matrix(targetx);
		// Matrix yy = new Matrix(targety);
	
		Matrix xx = new Matrix(x, lenn);
		Matrix yy = new Matrix(1, lenn);
	
		StringBuilder logg = new StringBuilder("\n");
		for (Integer m = 0; m < lenn; m++) {
			long l[] = { m };
			BitSet bitSet = BitSet.valueOf(l);
			boolean xor = false;
			for (int n = 0; n < x; n++) {
				boolean bool = bitSet.get(n);
				if (bool) {
					xx.set(n, m, 1.);
					logg.append(1);
				} else {
					xx.set(n, m, 0.);
					logg.append(0);
				}
				xor = ((!(xor & bool)) & (xor | bool));
			}
			if (xor) {
				yy.set(0, m, 1.);
				logg.append(" " + 1);
			} else {
				yy.set(0, m, 0.);
				logg.append(" " + 0);
			}
			logg.append("\n");
		}
		log.trace(logg);
		Matrix target[] = { xx, yy };
		log.trace(Arrays.toString(target));
		return target;
	}
}
