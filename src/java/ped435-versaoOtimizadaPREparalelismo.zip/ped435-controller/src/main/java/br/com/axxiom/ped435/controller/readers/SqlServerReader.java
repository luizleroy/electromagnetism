/**
 * 
 */
package br.com.axxiom.ped435.controller.readers;

import java.io.IOException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;

import au.com.bytecode.opencsv.CSVReader;
import br.com.axxiom.ped435.controller.iface.InterfaceReaders;
import br.com.axxiom.ped435.model.dao.service.TclienteService;
import br.com.axxiom.ped435.model.dao.service.TmedidorService;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tcliente;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedidor;
import br.com.axxiom.ped435.util.Const;

/**
 * @author luizleroy
 *
 */

/**
 * Classe SqlServerReader
 * 
 * @author LuizLeRoy - @axxiom.com.br<br/>
 *         Axxiom Solucoes Tecnologicas S.A.<br/>
 *         www.axxiom.com.br
 * 
 */
public class SqlServerReader implements InterfaceReaders {

	/**
	 * Construído para recuperar informações da base e serializá-la (Em arquivos
	 * .csv, por exemplo)
	 * 
	 */
	private static Logger log = Logger.getLogger(SqlServerReader.class);

	@Override
	public List<String[]> read(String path) {
		return null;
	}

	@Override
	public CSVReader read(String path, char separator) {
		return null;
	}

	public static void main(String args[]) throws IOException {
		Const.setLog();
		// by luizleroy
		TclienteService service = new TclienteService();
		SqlSessionFactory factory = service.getSqlSessionFactory();
		SqlSession sqlSession = factory.openSession();
		Tcliente cliente = service.selectByPrimaryKey(1, sqlSession);
		log.info("Num. Instalacao: " + cliente.getNumInstalacao());

		TmedidorService medService = new TmedidorService();
		Tmedidor medidor = medService.selectByPrimaryKey("1", sqlSession);
		log.info(medidor.getTipProprietario());
		
//		TmedicaoService tmedicaoService = new TmedicaoService();
//		Tmedicao medicao = tmedicaoService.selectByPrimaryKey("1",sqlSession);
		
		
		sqlSession.close();
	}
}
