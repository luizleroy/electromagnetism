package br.com.axxiom.ped435.controller.entidade;

import java.util.List;
import java.util.Map;

import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tcliente;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TclienteMedidor;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TformatoMedicao;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tgrandeza;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedicao;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedidor;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TparametroMedidor;

/**
 * Classe MedidorMedicoes - Esta classe é um entidade para o modelo de cliente/medicoes.
 * deverá possuir todas as medicoes de um cliente/medidor. 
 * @author ssoares - Sólon Soares - solon.soares@axxiom.com.br<br />
 * Axxiom Soluções Tecnológicas S.A. - www.axxiom.com.br<br />
 */
public class MedidorMedicoes implements Cloneable{

	private Tmedidor medidor;
	private Tcliente cliente;
	private TparametroMedidor parametroMedidor;
	private List<Tmedicao> medicoes;
	private TclienteMedidor clienteMedidor;
	private TformatoMedicao formatoMedicao;
	private Map<Integer, Tgrandeza> mapCanalGrandeza;
		
	
	public MedidorMedicoes(){
		super();
	}
	public Tmedidor getMedidor() {
		return medidor;
	}
	public void setMedidor(Tmedidor medidor) {
		this.medidor = medidor;
	}
	public Tcliente getCliente() {
		return cliente;
	}
	public void setCliente(Tcliente cliente) {
		this.cliente = cliente;
	}
	public TparametroMedidor getParametroMedidor() {
		return parametroMedidor;
	}
	public void setParametroMedidor(TparametroMedidor parametroMedidor) {
		this.parametroMedidor = parametroMedidor;
	}
	public List<Tmedicao> getMedicoes() {
		return medicoes;
	}
	public void setMedicoes(List<Tmedicao> medicoes) {
		this.medicoes = medicoes;
	}
	public TclienteMedidor getClienteMedidor() {
		return clienteMedidor;
	}
	public void setClienteMedidor(TclienteMedidor clienteMedidor) {
		this.clienteMedidor = clienteMedidor;
	}
	public TformatoMedicao getFormatoMedicao() {
		return formatoMedicao;
	}
	public void setFormatoMedicao(TformatoMedicao formatoMedicao) {
		this.formatoMedicao = formatoMedicao;
	}
	
	public Map<Integer, Tgrandeza> getMapCanalGrandeza() {
		return mapCanalGrandeza;
	}
	public void setMapCanalGrandeza(Map<Integer, Tgrandeza> mapCanalGrandeza) {
		this.mapCanalGrandeza = mapCanalGrandeza;
	}
	public Object clone() throws CloneNotSupportedException {		
		return super.clone();
    }
}
