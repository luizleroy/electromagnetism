package br.com.axxiom.ped435.controller.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;

import org.apache.log4j.Logger;

/**
 * Classe FileUtil - Classe para auxilio na manipulacao de arquivos
 * 
 * @author Sólon Soares - solon.soares@axxiom.com.br<br/>
 * Axxiom Solucoes Tecnologicas S.A.<br/>
 * www.axxiom.com.br
 */
public class FileUtil {

	private static Logger log = Logger.getLogger(FileUtil.class);
	
	/**
	 * Metodo checkDiretorio - Este metodo verifica se existe o diretorio passado como parametro.
	 * @param dir - Caminho do diretorio.
	 * @return - Retorna verdadeiro se o diretorio existir.
	 */
	public static boolean checkDiretorio(String dir) {
        return new File(dir).exists();
    }
	
	public static boolean checkArquivo(String arq) {
        return new File(arq).exists();
    }
    
    public static boolean createNewDir(String dir) {
        boolean ret = true;        
      
        if (!FileUtil.checkDiretorio(dir)) {
            File newDir = new File(dir);
            ret = newDir.mkdir();
        }
        return ret;
    }    
    
    public static void apagarArquivosDiretorio(File dir, final String extensao){
    	
    	File diretorioRaiz = new File(dir.getAbsolutePath());
    	
        if (diretorioRaiz.isDirectory()){
        	
        	File[] files = diretorioRaiz.listFiles(new FileFilter() {
				
			    public boolean accept(File pathname) {  
                    return pathname.getName().toLowerCase().endsWith("."+extensao);  
                }   
            }); 
        	
        	for (File file : files) {
				file.delete();
			}
        }else if (dir.isFile()){
        	dir.delete();
        }
    }
    
    public static File[] lerArquivosDiretorio(File dir, final String extensao){
    	
    	File diretorioRaiz = new File(dir.getAbsolutePath());
    	File[] files = null;
    	
        if (diretorioRaiz.isDirectory()){
        	
        	files = diretorioRaiz.listFiles(new FileFilter() {
				
			    public boolean accept(File pathname) {  
                    return pathname.getName().toLowerCase().endsWith("."+extensao);  
                }   
            });        	
        }
        return files;
    }
    
    public static ArrayList<String> lerArquivo(File diretorioRaiz, String arquivo){
    	
    	String linha = null;
    	ArrayList<String> registros = new ArrayList<String>();
    	
    	log.info("Lendo arquivo: "+arquivo);    	
    	BufferedReader leitor = null;
    	try{
    		// instancia do arquivo que vou ler			                    
    		FileReader reader = new FileReader(diretorioRaiz);  
            leitor = new BufferedReader(reader);
            while ((linha = leitor.readLine()) != null) {
            	registros.add(linha);
            }
        log.info("Lendo arquivo: "+arquivo+"..OK");
		}catch(Exception e){
			log.error(e.getMessage());
		} finally {
			try {
				leitor.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
    	
    	return registros;
    }
    
    public static String truncate(double value) {  
        DecimalFormat df = new DecimalFormat("#");  
        return df.format(value);  
    }
}
