package br.com.axxiom.ped435.controller.writers;

import org.apache.ibatis.session.SqlSession;

import br.com.axxiom.ped435.controller.iface.InterfaceWriters;
import br.com.axxiom.ped435.model.dao.service.TclienteMedidorService;
import br.com.axxiom.ped435.model.dao.service.TclienteService;
import br.com.axxiom.ped435.model.dao.service.TequipamentoService;
import br.com.axxiom.ped435.model.dao.service.TferiadoService;
import br.com.axxiom.ped435.model.dao.service.TformatoMedicaoService;
import br.com.axxiom.ped435.model.dao.service.TgrandezaService;
import br.com.axxiom.ped435.model.dao.service.TmedicaoService;
import br.com.axxiom.ped435.model.dao.service.TmedidorService;
import br.com.axxiom.ped435.model.dao.service.TmunicipioFeriadoService;
import br.com.axxiom.ped435.model.dao.service.TmunicipioService;
import br.com.axxiom.ped435.model.dao.service.TparametroMedidorService;
import br.com.axxiom.ped435.model.dao.service.TsituacaoMedicaoService;
import br.com.axxiom.ped435.model.dao.service.TtemperaturaService;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tcliente;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TclienteMedidor;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tequipamento;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tferiado;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TformatoMedicao;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tgrandeza;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedicao;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedidor;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmunicipio;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TmunicipioFeriado;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TparametroMedidor;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TsituacaoMedicao;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Ttemperatura;

/**
 * Classe SQLServerWriter - Front Controller para a escrita no banco SQLServer do P&D435.
 * 
 * @author Sólon Soares - solon.soares@axxiom.com.br<br/>
 * Axxiom Solucoes Tecnologicas S.A.<br/>
 * www.axxiom.com.br
 *
 */
public class SQLServerWriter implements InterfaceWriters{

	/**
	 * Metodo write - Este metodo escreve o objeto no banco de dados, o objeto que será inserido,
	 * detem o controle da transacao. Portanto ele abre, comita e fecha a conexão. Se o objeto possuir
	 * identitificador primario(ID) o metodo utiliza ele, senão faz o autoincrement automatico.
	 * 
	 * @param object - Objeto que será inserido no banco.
	 * @return boolean - retorna verdadeiro se conseguir atualizar o registro.
	 */
	public boolean write(Object object) {
		
		int ret = 0;
		
		if (object instanceof Tcliente){
			TclienteService service = new TclienteService();
			if (((Tcliente) object).getCodCliente() == null)
				((Tcliente) object).setCodCliente(service.selectLastPrimaryKey()+1);
			ret = service.insert((Tcliente)object);
			return (ret > 0);
		}
		
		if (object instanceof Tmedidor){
			TmedidorService service = new TmedidorService();
			if (((Tmedidor) object).getCodMedidor() == null){
				Integer id = service.selectLastPrimaryKey() + 1;
				((Tmedidor) object).setCodMedidor(id.toString());	
			}			
			ret = service.insert((Tmedidor)object);
			return (ret > 0);
		}
		
		if (object instanceof TclienteMedidor){
			TclienteMedidorService service = new TclienteMedidorService();			
			ret = service.insert((TclienteMedidor) object);
			return (ret > 0);
		}
		
		if (object instanceof TformatoMedicao){
			TformatoMedicaoService service = new TformatoMedicaoService();
			if (((TformatoMedicao) object).getCodFormatoMedicao() == null)
				((TformatoMedicao) object).setCodFormatoMedicao(service.selectLastPrimaryKey() + 1);
			ret = service.insert((TformatoMedicao)object);
			return (ret > 0);
		}
		
		if (object instanceof TparametroMedidor){
			TparametroMedidorService service = new TparametroMedidorService();
			if (((TparametroMedidor) object).getCodParametroMedidor() == null)
				((TparametroMedidor) object).setCodParametroMedidor(service.selectLastPrimaryKey() + 1);
			ret = service.insert((TparametroMedidor)object);
			return (ret > 0);
		}		
		
		if (object instanceof Tequipamento){
			TequipamentoService service = new TequipamentoService();
			if (((Tequipamento) object).getCodEquipamento() == null)
				((Tequipamento) object).setCodEquipamento(service.selectLastPrimaryKey() + 1);
			ret = service.insert((Tequipamento) object);
			return (ret > 0);
		}
		
		if (object instanceof Tgrandeza){
			TgrandezaService service = new TgrandezaService();
			if (((Tgrandeza) object).getCodGrandeza() == null)
				((Tgrandeza) object).setCodGrandeza(service.selectLastPrimaryKey() + 1);
			ret = service.insert((Tgrandeza) object);
			return (ret > 0);
		}
		
		if (object instanceof Tmedicao){
			TmedicaoService service = new TmedicaoService();
			if (((Tmedicao) object).getCodMedicao() == null)
				((Tmedicao) object).setCodMedicao(service.selectLastPrimaryKey() + 1);
			ret = service.insert((Tmedicao) object);
			return (ret > 0);
		}
		
		if (object instanceof TsituacaoMedicao){
			TsituacaoMedicaoService service = new TsituacaoMedicaoService();
			if (((TsituacaoMedicao) object).getCodSituacaoMedicao() == null)
				((TsituacaoMedicao) object).setCodSituacaoMedicao(service.selectLastPrimaryKey() + 1);
			ret = service.insert((TsituacaoMedicao) object);
			return (ret > 0);
		}
		
		if (object instanceof Tferiado){
			TferiadoService service = new TferiadoService();
			if (((Tferiado) object).getCodFeriado() == null)
				((Tferiado) object).setCodFeriado(service.selectLastPrimaryKey() + 1);
			ret = service.insert((Tferiado) object);
			return (ret > 0);
		}
		
		if (object instanceof Tmunicipio){
			TmunicipioService service = new TmunicipioService();
			if (((Tmunicipio) object).getCodMunicipio() == null)
				((Tmunicipio) object).setCodMunicipio(service.selectLastPrimaryKey() + 1);
			ret = service.insert((Tmunicipio) object);
			return (ret > 0);
		}
		
		if (object instanceof TmunicipioFeriado){
			TmunicipioFeriadoService service = new TmunicipioFeriadoService();
			ret = service.insert((TmunicipioFeriado) object);
			return (ret > 0);
		}
		
		if (object instanceof Ttemperatura){
			TtemperaturaService service = new TtemperaturaService();
			if (((Ttemperatura) object).getCodTemperatura() == null)
				((Ttemperatura) object).setCodTemperatura(service.selectLastPrimaryKey() + 1);
			ret = service.insert((Ttemperatura) object);
			return (ret > 0);
		}
		
		return (ret > 0);
	}
	
	/**
	 * Metodo write - Este metodo escreve o objeto no banco de dados, o objeto que será inserido, não
	 * não detem o controle da transacao. Portanto ele nao abre, nao comita e nao fecha a conexão.
	 * Se o objeto possuir identitificador primario(ID) o metodo utiliza ele, senão faz o
	 * autoincrement automatico.
	 *  
	 * @param object - Objeto que será inserido no banco.
	 * @param sqlSession - Sessao que controla a transacao.
	 * @return boolean - retorna verdadeiro se conseguir atualizar o registro.
	 */
	public boolean write(Object object, SqlSession sqlSession) {
		
		int ret = 0;
		
		if (object instanceof Tcliente){
			TclienteService service = new TclienteService();
			if (((Tcliente) object).getCodCliente() == null)
				((Tcliente) object).setCodCliente(service.selectLastPrimaryKey(sqlSession)+1);
			ret = service.insert((Tcliente)object, sqlSession);
			return (ret > 0);
		}
		
		if (object instanceof Tmedidor){
			TmedidorService service = new TmedidorService();
			if (((Tmedidor) object).getCodMedidor() == null){
				Integer id = service.selectLastPrimaryKey(sqlSession) + 1;
				((Tmedidor) object).setCodMedidor(id.toString());
			}
			ret = service.insert((Tmedidor)object, sqlSession);
			return (ret > 0);
		}
		
		if (object instanceof TclienteMedidor){
			TclienteMedidorService service = new TclienteMedidorService();
			ret = service.insert((TclienteMedidor) object, sqlSession);
			return (ret > 0);
		}
		
		if (object instanceof TformatoMedicao){
			TformatoMedicaoService service = new TformatoMedicaoService();
			if (((TformatoMedicao) object).getCodFormatoMedicao() == null)
				((TformatoMedicao) object).setCodFormatoMedicao(service.selectLastPrimaryKey(sqlSession) + 1);
			ret = service.insert((TformatoMedicao)object, sqlSession);
			return (ret > 0);
		}
		
		if (object instanceof TparametroMedidor){
			TparametroMedidorService service = new TparametroMedidorService();
			if (((TparametroMedidor) object).getCodParametroMedidor() == null)
				((TparametroMedidor) object).setCodParametroMedidor(service.selectLastPrimaryKey(sqlSession) + 1);
			ret = service.insert((TparametroMedidor)object, sqlSession);
			return (ret > 0);
		}		
		
		if (object instanceof Tequipamento){
			TequipamentoService service = new TequipamentoService();
			if (((Tequipamento) object).getCodEquipamento() == null)
				((Tequipamento) object).setCodEquipamento(service.selectLastPrimaryKey(sqlSession) + 1);
			ret = service.insert((Tequipamento) object, sqlSession);
			return (ret > 0);
		}
		
		if (object instanceof Tgrandeza){
			TgrandezaService service = new TgrandezaService();
			if (((Tgrandeza) object).getCodGrandeza() == null)
				((Tgrandeza) object).setCodGrandeza(service.selectLastPrimaryKey(sqlSession) + 1);
			ret = service.insert((Tgrandeza) object, sqlSession);
			return (ret > 0);
		}
		
		if (object instanceof Tmedicao){
			TmedicaoService service = new TmedicaoService();
			if (((Tmedicao) object).getCodMedicao() == null)
				((Tmedicao) object).setCodMedicao(service.selectLastPrimaryKey(sqlSession) + 1);
			ret = service.insert((Tmedicao) object, sqlSession);
			return (ret > 0);
		}
		
		if (object instanceof TsituacaoMedicao){
			TsituacaoMedicaoService service = new TsituacaoMedicaoService();
			if (((TsituacaoMedicao)object).getCodSituacaoMedicao() == null)
				((TsituacaoMedicao)object).setCodSituacaoMedicao(service.selectLastPrimaryKey(sqlSession) + 1);
			ret = service.insert((TsituacaoMedicao)object, sqlSession);
		}
		
		if (object instanceof Tferiado){
			TferiadoService service = new TferiadoService();
			if (((Tferiado) object).getCodFeriado() == null)
				((Tferiado) object).setCodFeriado(service.selectLastPrimaryKey(sqlSession) + 1);
			ret = service.insert((Tferiado) object, sqlSession);
			return (ret > 0);
		}
		
		if (object instanceof Tmunicipio){
			TmunicipioService service = new TmunicipioService();
			if (((Tmunicipio) object).getCodMunicipio() == null)
				((Tmunicipio) object).setCodMunicipio(service.selectLastPrimaryKey(sqlSession) + 1);
			ret = service.insert((Tmunicipio) object, sqlSession);
			return (ret > 0);
		}
		
		if (object instanceof TmunicipioFeriado){
			TmunicipioFeriadoService service = new TmunicipioFeriadoService();
			ret = service.insert((TmunicipioFeriado) object, sqlSession);
			return (ret > 0);
		}
		
		if (object instanceof Ttemperatura){
			TtemperaturaService service = new TtemperaturaService();
			if (((Ttemperatura) object).getCodTemperatura() == null)
				((Ttemperatura) object).setCodTemperatura(service.selectLastPrimaryKey(sqlSession) + 1);
			ret = service.insert((Ttemperatura) object, sqlSession);
			return (ret > 0);
		}
		
		return (ret > 0);
	}
	
	/**
	 * Metodo update - Este metodo atualiza o objeto no banco de dados, o objeto que será atualizado,
	 * detem o controle da transacao. Portanto ele abre, comita e fecha a conexão.
	 * 
	 * @param object - Objeto que será atualizado no banco.
	 * @return - Retorna verdadeiro se conseguir atualizar o registro.
	 */
	public boolean update(Object object){
		
		int ret = 0;
		
		if (object instanceof Tcliente){
			TclienteService service = new TclienteService();
			ret = service.updateByPrimaryKey((Tcliente)object);
			return (ret > 0);
		}
		
		if (object instanceof Tmedidor){
			TmedidorService service = new TmedidorService();
			ret = service.updateByPrimaryKey((Tmedidor)object);
			return (ret > 0);
		}
		
		if (object instanceof TformatoMedicao){
			TformatoMedicaoService service = new TformatoMedicaoService();
			ret = service.updateByPrimaryKey((TformatoMedicao)object);
			return (ret > 0);
		}
		
		if (object instanceof TparametroMedidor){
			TparametroMedidorService service = new TparametroMedidorService();
			ret = service.updateByPrimaryKey((TparametroMedidor)object);
			return (ret > 0);
		}		
		
		if (object instanceof Tequipamento){
			TequipamentoService service = new TequipamentoService();
			ret = service.updateByPrimaryKey((Tequipamento) object);
			return (ret > 0);
		}
		
		if (object instanceof Tgrandeza){
			TgrandezaService service = new TgrandezaService();
			ret = service.updateByPrimaryKey((Tgrandeza) object);
			return (ret > 0);
		}
		
		if (object instanceof Tmedicao){
			TmedicaoService service = new TmedicaoService();
			ret = service.updateByPrimaryKey((Tmedicao) object);
			return (ret > 0);
		}
		
		if (object instanceof TsituacaoMedicao){
			TsituacaoMedicaoService service = new TsituacaoMedicaoService();
			ret = service.updateByPrimaryKey((TsituacaoMedicao) object);
			return (ret > 0);
		}
		
		if (object instanceof Tferiado){
			TferiadoService service = new TferiadoService();
			ret = service.updateByPrimaryKey((Tferiado) object);
			return (ret > 0);
		}
		
		if (object instanceof Tmunicipio){
			TmunicipioService service = new TmunicipioService();
			ret = service.updateByPrimaryKey((Tmunicipio) object);
			return (ret > 0);
		}
		
		if (object instanceof Ttemperatura){
			TtemperaturaService service = new TtemperaturaService();
			ret = service.updateByPrimaryKey((Ttemperatura) object);
			return (ret > 0);
		}
		
		return (ret > 0);
	}
}
