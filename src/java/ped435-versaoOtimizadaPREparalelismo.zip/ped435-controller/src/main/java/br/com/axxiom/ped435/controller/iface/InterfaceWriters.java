package br.com.axxiom.ped435.controller.iface;

import org.apache.ibatis.session.SqlSession;

public interface InterfaceWriters {

	public boolean write(Object object);
	public boolean write(Object object, SqlSession sqlSession);
}
