package br.com.axxiom.ped435.controller.iface;

import java.util.List;

import au.com.bytecode.opencsv.CSVReader;

public interface InterfaceReaders {

	List<String[]> read(String path);
	CSVReader read(String path, char separator);
}
