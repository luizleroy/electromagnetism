package br.com.axxiom.ped435.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Random;

import org.apache.log4j.PropertyConfigurator;

public class Const {
	public static final int dimensaoGlobal = 10;
	public static int dims = dimensaoGlobal;
	public static TestFunction func;
	public static int samples;

	public static final Random random = new Random(System.nanoTime());
	public static final String separator = "\t";

	// RNA
	// dependente da entrada X
	// nNeur[0]= 1; exemplo
	// nos neurônios abaixo, as camadas intermediárias são livres.
	// nNeur[...]= 12; exemplo
	// dependente da saída Y
	// nNeur[nNeur.length]= 1; exemplo
	public static int[] nNeur;
	public static int firstIndexWB = 0;

	// PSO
	public static final int loop = 1000*Const.dimensaoGlobal;
	public static final int dots = 100*Const.dimensaoGlobal;
	public static final double pMut = 0.1;
	public static final long nMut = Math.round(pMut * dots * dims);
	public static final double c1 = 1.5;
	public static final double c2 = 1.5;
	public static final double W1 = -0.5;
	public static final double W2 = +0.5;

	// private static Logger log = Logger.getLogger(Const.class);

	public static void configuraDimRNA(int[] nNeurData) {
		nNeur = nNeurData; // recebe e seta a topologia
		int wb = 0;
		int w = 0;
		for (int k = 0; k < (nNeur.length - 1); k++) {
			w += nNeur[k] * nNeur[k + 1];
			wb += nNeur[k + 1];
		}
		Const.dims = w + wb; // configura a dimensão
		Const.firstIndexWB = w; // seta o índice que separa w e wb
	}

	/**
	 * Metodo setLog - Configura o log da aplicacao LOG4J.
	 * 
	 * @throws Exception
	 *             - Lanca uma execao em caso de erro na configuracao do log.
	 */
	public static void setLog() {
		Properties prop = new Properties();
		try {
			InputStream is = new FileInputStream("PeD435.log4j");
			prop.load(is);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		PropertyConfigurator.configure(prop);
		// outra forma...
		// org.apache.log4j.Logger.getRootLogger().info("teste: org.apache.log4j.Logger.getRootLogger().info(\"message\")");
	}
}
