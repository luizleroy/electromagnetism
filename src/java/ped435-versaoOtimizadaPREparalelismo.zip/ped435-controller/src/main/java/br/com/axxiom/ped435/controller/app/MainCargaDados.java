package br.com.axxiom.ped435.controller.app;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.controller.util.Config;
import br.com.axxiom.ped435.controller.util.FileUtil;
import br.com.axxiom.ped435.util.Const;

/**
 * Classe Aplicaao - Esta classe é o front crontoller da aplicação. Como não
 * temos ainda camada de apresentacao, o inicio do processamento sera atraves do
 * front crontroller. Atraves desta classe inicia-se o processamento.
 * 
 * @author ssoares - Sólon Soares - solon.soares@axxiom.com.br<br />
 *         Axxiom Soluções Tecnológicas S.A. - www.axxiom.com.br<br />
 * @modification: luizLeRoy
 * 
 *                LUIZ LE ROY: Esta é um dos "FRONT CONTROLLER" do sistema,
 *                responsável por inicializar a carga dos dados de medição.
 * 
 */
public class MainCargaDados {

	private static Logger log = Logger.getLogger(MainCargaDados.class);
	private static String parametroCarregarArquivosIniciais = null;
	private static String parametroArquivoMedicoes = null;

	/**
	 * Metodo main - Este metodo inicia o processamento da aplicacao. Configura
	 * o gestor de logs, valida as entradas do arquivo de properties e em
	 * seguida executa a aplicacao.
	 * 
	 * @param args
	 *            - nao utilizado.
	 */
	public static void main(String[] args) {

		try {
			Const.setLog();
		} catch (Exception e) {
			e.printStackTrace();
		}

		String controle = "true";
		if (controle.equals("true")) {
			throw new RuntimeException(
					"Não executar no momento para manter os dados no banco constantes!");
		}

		boolean isPesquisa = true;

		if (isPesquisa) {

		} else {

			log.info("Programa Iniciado: " + new Date());

			if (validarEntradas()) {
				executar();
			}

			log.info("Programa Finalizado: " + new Date());
		}
	}

	/**
	 * Metodo executar - Inicia o processamento de execucao da aplicacao criando
	 * um Runnable para posível implementação em Threads futuramente. Em seguida
	 * dispara as execucoes.
	 */
	public static void executar() {

		List<Runnable> arrayProc = new ArrayList<Runnable>();

		ProcessarMedicoes processarMedicoes = new ProcessarMedicoes(
				parametroArquivoMedicoes);

		arrayProc.add(processarMedicoes);

		for (Runnable runnable : arrayProc) {
			runnable.run();
		}
	}

	/**
	 * Metodo validarEntradas - Valida todas as entradas do arquivo de
	 * properties.
	 * 
	 * @return - Caso a validacao ocorra da forma correta retorna verdadeiro. Se
	 *         ocorrer algum problema retorna falso.
	 */
	public static boolean validarEntradas() {

		parametroArquivoMedicoes = Config.getKey("dir.entrada.medicoes");
		parametroCarregarArquivosIniciais = Config
				.getKey("carregar.arquivos.iniciais");

		if (parametroCarregarArquivosIniciais.equalsIgnoreCase("sim")) {
			if (!FileUtil.checkDiretorio(parametroArquivoMedicoes)) {
				log.error("Arquivo de configuracao: propriedade dir.entrada.medicoes com entrada inválida!");
				return false;
			}
		}
		return true;
	}
}
