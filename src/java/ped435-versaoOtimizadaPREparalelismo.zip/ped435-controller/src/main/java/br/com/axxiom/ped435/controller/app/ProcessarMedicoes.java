package br.com.axxiom.ped435.controller.app;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import au.com.bytecode.opencsv.CSVReader;
import br.com.axxiom.ped435.controller.entidade.MedidorMedicoes;
import br.com.axxiom.ped435.controller.iface.InterfaceReaders;
import br.com.axxiom.ped435.controller.readers.CSVAxxiomReader;
import br.com.axxiom.ped435.controller.util.FileUtil;
import br.com.axxiom.ped435.controller.util.MedicoesUtil;
import br.com.axxiom.ped435.controller.writers.SQLServerWriter;
import br.com.axxiom.ped435.model.dao.enums.FormatoMedicaoEnum;
import br.com.axxiom.ped435.model.dao.enums.GrandezaEnum;
import br.com.axxiom.ped435.model.dao.enums.SituacaoMedicaoEnum;
import br.com.axxiom.ped435.model.dao.service.BaseDBPED435DAO;
import br.com.axxiom.ped435.model.dao.service.TValidSimplefitService;
import br.com.axxiom.ped435.model.dao.service.TclienteService;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidSimplefit;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tcliente;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TclienteMedidor;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TformatoMedicao;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tgrandeza;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedicao;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedidor;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TparametroMedidor;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TsituacaoMedicao;

/**
 * Classe ProcessarMedicoes. Processa a leitura e escrita das Medicoes de
 * cliente.
 * 
 * @author ssoares - Sólon Soares - solon.soares@axxiom.com.br<br />
 *         Axxiom Soluções Tecnológicas S.A. - www.axxiom.com.br<br />
 */
public class ProcessarMedicoes implements Runnable {

	private static Logger log = Logger.getLogger(ProcessarMedicoes.class);
	List<String> logRegistros = new ArrayList<String>();
	List<String> logMedicoesDuplicadas = new ArrayList<String>();
	List<String> logMedicoesIncompletas = new ArrayList<String>();
	List<String> logMedicoesIncoerentes = new ArrayList<String>();
	private String pathArquivoMedicoes;

	/**
	 * Construtor da classe
	 * 
	 * @param pathArquivoMedicoes
	 *            - Caminho do diretorio onde encontram-se os arquivos de
	 *            medicao.
	 */
	public ProcessarMedicoes(String pathArquivoMedicoes) {
		this.pathArquivoMedicoes = pathArquivoMedicoes;
	}

	/**
	 * Metodo run - Realiza as chamadas dos metodos de leitura e escrita e log
	 * de informacoes.
	 */
	public void run() {

		Map<String, MedidorMedicoes> mapaMedidorMedicoes = processRead();
		processWrite(mapaMedidorMedicoes);

		// Mostra Log de registros
		for (String st : logRegistros) {
			log.info(st);
		}

		// Mostra Log de registros duplicados. Já existe medicao para uma mesma
		// data e hora.
		if (!logMedicoesDuplicadas.isEmpty()) {
			log.info("+------------------------------------------------------------------+");
			log.info("| MEDICOES DUPLICADAS - EXISTE A MESMA MEDICAO PARA OUTRO REGISTRO |");
			log.info("+------------------------------------------------------------------+");
			for (String st : logMedicoesDuplicadas) {
				log.info(st);
			}
		}

		// Mostra Log de Medicoes incompletas. Não possuem os 3 canais
		if (!logMedicoesIncompletas.isEmpty()) {
			log.info("+---------------------------------------------------------+");
			log.info("| MEDICOES INCOMPLETAS - A MEDICAO NAO POSSUI OS 3 CANAIS |");
			log.info("+---------------------------------------------------------+");
			for (String st : logMedicoesIncompletas) {
				log.info(st);
			}
		}

		// Mostra Log de Medicoes incoerentes. Não possuem as mesmas quantidades
		// de medicoes nos 3 canais.
		if (!logMedicoesIncoerentes.isEmpty()) {
			log.info("+--------------------------------------------------------------------------------------------+");
			log.info("| MEDICOES INCOERENTES - A MEDICAO NAO POSSUI A MESMA QUANTIDADE DE MEDICOES PARA OS 3 CANAIS|");
			log.info("+--------------------------------------------------------------------------------------------+");
			for (String st : logMedicoesIncoerentes) {
				log.info(st);
			}
		}
	}

	/**
	 * Metodo processRead - Este metodo processa a leitura de todos os dados dos
	 * arquivos de medicao
	 * 
	 * @return - Retorna uma mapa contendo um objeto MedidorMedicao por
	 *         cliente(numInstalacao)
	 */
	public Map<String, MedidorMedicoes> processRead() {

		// Inicializa variáveis para contadores de logs de inserção.
		Integer contClientesLidos = 0;
		Integer contMedidoresLidos = 0;
		Integer contMedicoesLidos = 0;
		Integer contArquivosLidos = 0;
		Integer contRegistrosLidos = 0;
		Integer contFormatoMedicaoLidos = 0;
		Integer contGrandezaLidos = 0;
		Integer contSituacaoMedicaoLidos = 0;
		Integer contParametroMedidorLidos = 0;
		Integer contMedicaoDuplicada = 0;
		Integer contMedicaoIncompleta = 0;
		Integer contMedicaoIncoerente = 0;

		InterfaceReaders ireader = new CSVAxxiomReader();
		File fileDir = new File(pathArquivoMedicoes);
		File[] files = FileUtil.lerArquivosDiretorio(fileDir, "csv");

		// Cria mapa de clientes e medicoes
		Map<String, MedidorMedicoes> mapClienteMedicoes = new HashMap<String, MedidorMedicoes>();

		// Cria Arraylist para os clientes aprovados
		TclienteService ser = new TclienteService();
		List<String> listInstalacaoAprovadas = ser
				.selectListClientesAprovadosRevisaoTarifaria();

		MedidorMedicoes medidorMedicoes = new MedidorMedicoes();
		MedidorMedicoes medidorMedicoesHold = null;

		for (File file : files) {

			++contArquivosLidos;

			CSVReader reader = ireader.read(file.getAbsolutePath(), ';');

			// Este bloco somente será feito na carga do primeiro arquivo
			if (contArquivosLidos == 1) {

				// Configura dados básicos ficticios
				// Parametros do Medidor
				++contParametroMedidorLidos;
				TparametroMedidor parametroMedidor = new TparametroMedidor();
				parametroMedidor
						.setCodParametroMedidor(contParametroMedidorLidos);
				parametroMedidor.setValDenominador(10.0);
				parametroMedidor.setValNumerador(10.0);
				parametroMedidor.setValRtc(10.0);
				parametroMedidor.setValRtp(10.0);

				medidorMedicoes.setParametroMedidor(parametroMedidor);

				// Configura o formato que as medições foram escritas no campo
				// de medicoes
				// da tabela medicoes

				++contFormatoMedicaoLidos;
				TformatoMedicao formatoMedicao = new TformatoMedicao();
				formatoMedicao
						.setCodFormatoMedicao(FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS
								.getCodFormatoMedicao());
				formatoMedicao
						.setDesFormatoMedicao(FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS
								.getDesFormatoMedicao());
				formatoMedicao
						.setTipFormatoMedicao(FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS
								.getTipFormatoMedicao());

				medidorMedicoes.setFormatoMedicao(formatoMedicao);

				// Configura as grandezas para 3 canais
				contGrandezaLidos = 3;
				Map<Integer, Tgrandeza> mapGr = new HashMap<Integer, Tgrandeza>();
				for (int i = 1; i <= 3; i++)
					mapGr.put(i, MedicoesUtil.getGrandezaPorCanal(i));
				medidorMedicoes.setMapCanalGrandeza(mapGr);

				// Configura a situacao medicao
				contSituacaoMedicaoLidos = SituacaoMedicaoEnum.values().length;

				// Clona o objeto que contem os valores default setados no
				// processo acima. E guarda numa variavel para ser utilizado
				// em todos os novos objetos do tipo MedidorMedicao que vierem a
				// ser criados.
				try {
					medidorMedicoesHold = (MedidorMedicoes) medidorMedicoes
							.clone();
				} catch (CloneNotSupportedException e) {
					log.error(e.getMessage());
				}
			}

			String[] array;
			// Inicia processamento das linhas do arquivo.
			try {
				while ((array = reader.readNext()) != null) {

					if (array.length > 0) {

						++contRegistrosLidos;

						// Captura registros
						String numInstalacao = array[1];
						String strDataMedicao = array[4];
						Date dataMedicao = MedicoesUtil
								.stringToDate(strDataMedicao);
						Integer intervalo = 15;
						Integer qtdRegistros = MedicoesUtil
								.getQtdTemposPorDia(intervalo);

						String[] medicoes = new String[qtdRegistros];

						int j = 0;

						// Monta array de medicões por linha do arquivo
						for (int i = 5; i < (qtdRegistros + 5); i++) {
							medicoes[j++] = array[i];
						}

						// Se mapa não possui o medidorMedicoes então adiciona
						// ele ao mapa
						if (listInstalacaoAprovadas.contains(numInstalacao)) {
							if (!mapClienteMedicoes.containsKey(numInstalacao)) {

								// Obtem um novo objeto medidorMedicoes atraves
								// do medidorMedicoesHold
								try {
									medidorMedicoes = (MedidorMedicoes) medidorMedicoesHold
											.clone();
								} catch (CloneNotSupportedException e) {
									log.error(e.getMessage());
								}

								// Configura o cliente para a instalacao
								++contClientesLidos;
								Tcliente cliente = new Tcliente();
								cliente.setCodCliente(contClientesLidos);
								cliente.setNumInstalcao(numInstalacao);
								cliente.setValConstPerdas(0.0);
								medidorMedicoes.setCliente(cliente);

								// Configura o medidor para o cliente
								++contMedidoresLidos;
								Tmedidor medidor = new Tmedidor();
								medidor.setCodMedidor(contMedidoresLidos
										.toString());
								medidor.setCodParametroMedidor(medidorMedicoes
										.getParametroMedidor()
										.getCodParametroMedidor());
								medidor.setTipProprietario("CLIENTE");
								medidorMedicoes.setMedidor(medidor);

								// Configura as medicoes
								++contMedicoesLidos;
								List<Tmedicao> listaMedicoes = new ArrayList<Tmedicao>();
								Tmedicao medicao = new Tmedicao();
								medicao.setCodFormatoMedicao(medidorMedicoes
										.getFormatoMedicao()
										.getCodFormatoMedicao());
								medicao.setCodMedidor(medidorMedicoes
										.getMedidor().getCodMedidor());
								medicao.setDatGravacao(new Date());
								medicao.setDatMedicao(dataMedicao);
								medicao.setNomOrigemInformacao("excel-cemig");
								String medicaoDia = "";
								Integer grandeza = medidorMedicoes
										.getMapCanalGrandeza()
										.get(contArquivosLidos)
										.getCodGrandeza();
								medicaoDia = MedicoesUtil
										.geraStringMedicoesDoDia(medicoes,
												grandeza, dataMedicao,
												intervalo);
								medicao.setValMedicao(medicaoDia);
								medicao.setCodSituacaoMedicao(SituacaoMedicaoEnum.VALIDO
										.getCodSituacaoMedicao());
								listaMedicoes.add(medicao);
								medidorMedicoes.setMedicoes(listaMedicoes);

								// Configura a relacao entre cliente e medidor
								TclienteMedidor clienteMedidor = new TclienteMedidor();
								clienteMedidor.setCodCliente(cliente
										.getCodCliente());
								clienteMedidor.setCodMedidor(medidor
										.getCodMedidor());
								medidorMedicoes
										.setClienteMedidor(clienteMedidor);

								// Adiciona o medidorMedicoes ao mapa.
								mapClienteMedicoes.put(numInstalacao,
										medidorMedicoes);

							} else {

								// Se já existir no mapa e for da mesma data
								// então concatena as medicoes
								++contMedicoesLidos;
								MedidorMedicoes medMedicoes = mapClienteMedicoes
										.get(numInstalacao);
								List<Tmedicao> listaMedicoes = medMedicoes
										.getMedicoes();

								Boolean atualizou = false;

								// Procura pelas medicoes de mesma data
								for (Tmedicao tmedicoes : listaMedicoes) {

									String medicaoDia = "";
									Integer numCanal = contArquivosLidos;
									Integer grandeza = medMedicoes
											.getMapCanalGrandeza()
											.get(contArquivosLidos)
											.getCodGrandeza();

									// Se existir a mesma data, então concatena
									// os canais
									if (tmedicoes.getDatMedicao().compareTo(
											dataMedicao) == 0) {

										// Só concatena se não existir medicao
										// para este canal
										if (tmedicoes.getValMedicao().indexOf(
												"canal" + numCanal) == -1) {
											medicaoDia = MedicoesUtil
													.concatenaStringMedicoesCanalMedicao(
															tmedicoes
																	.getValMedicao(),
															medicoes, grandeza,
															dataMedicao,
															intervalo, numCanal);
											tmedicoes.setValMedicao(medicaoDia);
										} else {
											// Configura o registro de Medicao
											// como duplicado
											tmedicoes
													.setCodSituacaoMedicao(SituacaoMedicaoEnum.INVALIDO_MEDICAO_DUPLICADA
															.getCodSituacaoMedicao());

											// Insere o novo registro como
											try {
												Tmedicao medicaoHold = (Tmedicao) tmedicoes
														.clone();
												MedicoesUtil
														.apagaCanal(
																medicaoHold
																		.getValMedicao(),
																numCanal);
												String medDia = MedicoesUtil
														.concatenaStringMedicoesCanalMedicao(
																medicaoHold
																		.getValMedicao(),
																medicoes,
																grandeza,
																dataMedicao,
																intervalo,
																numCanal);
												medicaoHold
														.setValMedicao(medDia);
												listaMedicoes.add(medicaoHold);
											} catch (CloneNotSupportedException e) {
												log.error(e.getMessage());
											}

											logMedicoesDuplicadas
													.add("CONSUMIDOR|"
															+ medMedicoes
																	.getCliente()
																	.getNumInstalacao()
															+ "|MEDIDOR|"
															+ medMedicoes
																	.getMedidor()
																	.getCodMedidor()
															+ "|DATAMEDICAO|"
															+ tmedicoes
																	.getDatMedicao()
															+ "|MEDICOES|"
															+ Arrays.toString(medicoes));
											++contMedicaoDuplicada;
										}

										atualizou = true;
										break;
									}
								}

								// Se não atualizou a medicao do cliente então
								// insere a nova medicao para o mesmo cliente.
								if (!atualizou) {

									Tmedicao medicao = new Tmedicao();
									medicao.setCodFormatoMedicao(medMedicoes
											.getFormatoMedicao()
											.getCodFormatoMedicao());
									medicao.setCodMedidor(medMedicoes
											.getMedidor().getCodMedidor());
									medicao.setDatGravacao(new Date());
									medicao.setDatMedicao(dataMedicao);
									medicao.setNomOrigemInformacao("excel-cemig");
									medicao.setCodSituacaoMedicao(SituacaoMedicaoEnum.VALIDO
											.getCodSituacaoMedicao());
									String medicaoDia = "";
									Integer grandeza = medMedicoes
											.getMapCanalGrandeza()
											.get(contArquivosLidos)
											.getCodGrandeza();
									medicaoDia = MedicoesUtil
											.geraStringMedicoesDoDia(medicoes,
													grandeza, dataMedicao,
													intervalo);
									medicao.setValMedicao(medicaoDia);
									listaMedicoes.add(medicao);
								}
							}
						}
					}
				}
			} catch (IOException e) {
				log.error(e.getMessage());
				e.printStackTrace();
			}
		}

		// Verifica registros que não possuem todos os canais de medicao e
		// retira-os das listas de medicoes
		for (String consumidor : listInstalacaoAprovadas) {
			MedidorMedicoes mm = mapClienteMedicoes.get(consumidor);
			if (mm != null) {
				List<Tmedicao> lstMedicoes = mm.getMedicoes();
				// List<Tmedicao> listaIncompleta = new ArrayList<Tmedicao>();
				for (Tmedicao tmedicoes2 : lstMedicoes) {
					if (!(tmedicoes2.getValMedicao().contains("canal1")
							&& tmedicoes2.getValMedicao().contains("canal2") && tmedicoes2
							.getValMedicao().contains("canal3"))) {
						logMedicoesIncompletas.add("CONSUMIDOR|" + consumidor
								+ "|MEDIDOR|" + tmedicoes2.getCodMedidor()
								+ "|DATAMEDICAO|" + tmedicoes2.getDatMedicao()
								+ "|MEDICOES|" + tmedicoes2.getValMedicao());
						tmedicoes2
								.setCodSituacaoMedicao(SituacaoMedicaoEnum.INVALIDO_CANAL_FALTANTE
										.getCodSituacaoMedicao());
						// listaIncompleta.add(tmedicoes2);
						++contMedicaoIncompleta;
					}
				}
				// lstMedicoes.removeAll(listaIncompleta);
			}
		}

		// Verifica registros que não possuem em seus 3 canais de medicao a
		// mesma quantidade de medições.
		for (String consumidor : listInstalacaoAprovadas) {
			MedidorMedicoes mm = mapClienteMedicoes.get(consumidor);
			if (mm != null) {
				List<Tmedicao> lstMedicoes = mm.getMedicoes();
				// List<Tmedicao> listaIncoerente = new ArrayList<Tmedicao>();
				for (Tmedicao tmedicoes2 : lstMedicoes) {
					if (!MedicoesUtil.checkAllChannels(
							FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS,
							tmedicoes2.getValMedicao(), 3)) {
						logMedicoesIncoerentes.add("CONSUMIDOR|" + consumidor
								+ "|MEDIDOR|" + tmedicoes2.getCodMedidor()
								+ "|DATAMEDICAO|" + tmedicoes2.getDatMedicao()
								+ "|MEDICOES|" + tmedicoes2.getValMedicao());
						tmedicoes2
								.setCodSituacaoMedicao(SituacaoMedicaoEnum.INVALIDO_CANAIS_INCOERENTES
										.getCodSituacaoMedicao());
						// listaIncoerente.add(tmedicoes2);
						++contMedicaoIncoerente;
					}
				}
				// lstMedicoes.removeAll(listaIncoerente);
			}
		}

		// Guarda os log de leitura
		logRegistros.add(formatLogString("CLIENTES LIDOS",
				contClientesLidos.toString()));
		logRegistros.add(formatLogString("MEDIDORES LIDOS",
				contMedidoresLidos.toString()));
		logRegistros.add(formatLogString("PARAMETROS MEDIDORES LIDOS",
				contParametroMedidorLidos.toString()));
		logRegistros.add(formatLogString("GRANDEZAS LIDAS",
				contGrandezaLidos.toString()));
		logRegistros.add(formatLogString("FORMATOS MEDICOES LIDAS",
				contFormatoMedicaoLidos.toString()));
		logRegistros.add(formatLogString("SITUACAO MEDICOES LIDAS",
				contSituacaoMedicaoLidos.toString()));
		logRegistros.add(formatLogString("MEDICOES LIDAS",
				contMedicoesLidos.toString()));
		logRegistros.add(formatLogString("MEDICOES DUPLICADAS",
				contMedicaoDuplicada.toString()));
		logRegistros.add(formatLogString("MEDICOES INCOMPLETAS",
				contMedicaoIncompleta.toString()));
		logRegistros.add(formatLogString("MEDICOES INCOERENTES",
				contMedicaoIncoerente.toString()));
		logRegistros.add(formatLogString("TOTAL LINHAS ARQUIVOS LIDAS",
				contRegistrosLidos.toString()));
		logRegistros.add(formatLogString("TOTAL ARQUIVOS LIDOS",
				contArquivosLidos.toString()));

		return mapClienteMedicoes;
	}

	/**
	 * Metodo processWrite - Este metodo processa a escrita no banco de todos os
	 * dados obtidos da leitura dos arquivos.
	 * 
	 * @param mapaMedidorMedicoes
	 *            - Mapa de MedidorMedicoes a ser escrito no banco.
	 */
	public void processWrite(Map<String, MedidorMedicoes> mapaMedidorMedicoes) {

		Integer contClientesInseridos = 0;
		Integer contParametroMedidorInseridos = 0;
		Integer contGrandezaInseridos = 0;
		Integer contFormatoMedicaoInseridos = 0;
		Integer contMedidoresInseridos = 0;
		Integer contClienteMedidorInseridos = 0;
		Integer contMedicoesInseridos = 0;
		Integer contTotalRegistrosInseridos = 0;
		Integer contSituacaoMedicaoInseridos = 0;

		SQLServerWriter sqlWriter = new SQLServerWriter();
		BaseDBPED435DAO service = new TclienteService();
		SqlSession sqlSession = service.getSqlSessionFactory().openSession();
		Boolean inseriu = false;

		try {
			for (Entry<String, MedidorMedicoes> entry : mapaMedidorMedicoes
					.entrySet()) {

				log.debug("###########################################");
				log.debug("Processando cliente: " + entry.getKey());
				log.debug("###########################################");

				MedidorMedicoes medidorMedicoes = entry.getValue();

				// Esses 3 parametros somente serão inseridos uma vez pois são
				// padrão para todos os registros.
				if (!inseriu) {

					// Insere o parametro do medidor.
					sqlWriter.write(medidorMedicoes.getParametroMedidor(),
							sqlSession);
					++contParametroMedidorInseridos;

					// Insere todas as grandezas de medicao do enum GrandezaEnum
					GrandezaEnum[] grandezaEnumArray = GrandezaEnum.values();
					for (GrandezaEnum grandezaEnum : grandezaEnumArray) {
						Tgrandeza grandeza = new Tgrandeza();
						grandeza.setCodGrandeza(grandezaEnum.getCodGrandeza());
						grandeza.setSigGrandeza(grandezaEnum.getSigGrandeza());
						grandeza.setDesGrandeza(grandezaEnum.getDesGrandeza());
						sqlWriter.write(grandeza, sqlSession);
						++contGrandezaInseridos;
					}

					// Insere todos os formatos de medicao do enum
					// FormatoMedicaoEnum
					FormatoMedicaoEnum[] formatoMedicaoArray = FormatoMedicaoEnum
							.values();
					for (FormatoMedicaoEnum formatoMedicaoEnum : formatoMedicaoArray) {
						TformatoMedicao formatoMedicao = new TformatoMedicao();
						formatoMedicao.setCodFormatoMedicao(formatoMedicaoEnum
								.getCodFormatoMedicao());
						formatoMedicao.setTipFormatoMedicao(formatoMedicaoEnum
								.getTipFormatoMedicao());
						formatoMedicao.setDesFormatoMedicao(formatoMedicaoEnum
								.getDesFormatoMedicao());
						sqlWriter.write(formatoMedicao, sqlSession);
						++contFormatoMedicaoInseridos;
					}

					// Insere todos as situações de medição do enum
					// SituacaoMedicaoEnum
					SituacaoMedicaoEnum[] situacaoMedicaoEnumArray = SituacaoMedicaoEnum
							.values();
					for (SituacaoMedicaoEnum situacaoMedicaoEnum : situacaoMedicaoEnumArray) {
						TsituacaoMedicao situacaoMedicao = new TsituacaoMedicao();
						situacaoMedicao
								.setCodSituacaoMedicao(situacaoMedicaoEnum
										.getCodSituacaoMedicao());
						situacaoMedicao
								.setTipSituacaoMedicao(situacaoMedicaoEnum
										.getTipSituacaoMedicao());
						situacaoMedicao
								.setDesSituacaoMedicao(situacaoMedicaoEnum
										.getDesSituacaoMedicao());
						sqlWriter.write(situacaoMedicao, sqlSession);
						++contSituacaoMedicaoInseridos;
					}

					inseriu = true;
				}

				// Insere os clientes
				sqlWriter.write(medidorMedicoes.getCliente(), sqlSession);
				++contClientesInseridos;

				// Insere os medidores
				sqlWriter.write(medidorMedicoes.getMedidor(), sqlSession);
				++contMedidoresInseridos;

				// Insere a relacao cliente medidor
				sqlWriter
						.write(medidorMedicoes.getClienteMedidor(), sqlSession);
				++contClienteMedidorInseridos;

				// Insere as medicoes
				for (Tmedicao medicoes : medidorMedicoes.getMedicoes()) {
					sqlWriter.write(medicoes, sqlSession);
					++contMedicoesInseridos;
				}

				// Comita registros a cada 4000 regitros
				if (contTotalRegistrosInseridos % 4000 == 0) {
					sqlSession.commit();
					sqlSession.clearCache();
				}
			}

			// Comita o restante dos registros.
			sqlSession.commit();
			sqlSession.clearCache();
		} finally {
			// Finaliza o Transaction
			sqlSession.close();
		}

		// Contabiliza o total de registros Inseridos
		contTotalRegistrosInseridos = contClientesInseridos
				+ contParametroMedidorInseridos + contGrandezaInseridos
				+ contFormatoMedicaoInseridos + contSituacaoMedicaoInseridos
				+ contMedidoresInseridos + contClienteMedidorInseridos
				+ contMedicoesInseridos + contTotalRegistrosInseridos;

		// Guarda os logs de insercao
		logRegistros.add(formatLogString("CLIENTES INSERIDOS",
				contClientesInseridos.toString()));
		logRegistros.add(formatLogString("MEDIDORES INSERIDOS",
				contMedidoresInseridos.toString()));
		logRegistros.add(formatLogString("PARAMETROS MEDIDORES INSERIDOS",
				contParametroMedidorInseridos.toString()));
		logRegistros.add(formatLogString("GRANDEZAS INSERIDAS",
				contGrandezaInseridos.toString()));
		logRegistros.add(formatLogString("FORMATOS MEDICOES INSERIDOS",
				contFormatoMedicaoInseridos.toString()));
		logRegistros.add(formatLogString("FORMATOS MEDICOES INSERIDOS",
				contSituacaoMedicaoInseridos.toString()));
		logRegistros.add(formatLogString("MEDICOES INSERIDAS",
				contMedicoesInseridos.toString()));
		logRegistros.add(formatLogString("TOTAL REGISTROS INSERIDOS",
				contTotalRegistrosInseridos.toString()));
	}

	/**
	 * Metodo formatLogString - Este metodo formata a String de log.
	 * 
	 * @param parameter
	 *            - O parametro que estiver sendo monitorado.
	 * @param value
	 *            - O valor do parametro que estiver sendo monitorado.
	 * @return - Retorna a string contendo o parametro e valor monitorado
	 *         separado por 40 pontilhados.
	 */
	public static String formatLogString(String parameter, String value) {
		return StringUtils.rightPad(parameter, 40, '.') + ": " + value;
	}
}
