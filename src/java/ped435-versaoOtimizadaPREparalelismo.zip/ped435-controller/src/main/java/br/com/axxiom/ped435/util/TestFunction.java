package br.com.axxiom.ped435.util;

public interface TestFunction {

	double[] getOptimum();

	double[] getUpValue();

	double[] getDnValue();

	/**
	 * This is ff(X)
	 * 
	 * @param x
	 *            is a input vector
	 */
	double get(double[] x); // inserir o contador no início do método: não queremos uma chamada a função não contabilizada

	long getCounter();

	void resetCounter();
}
