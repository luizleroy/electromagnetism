/**
 * 
 */
package br.com.axxiom.ped435.controller.app;

/**
 * @author luizleroy
 *
 */
public abstract class AbstractSerializador implements Runnable{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
