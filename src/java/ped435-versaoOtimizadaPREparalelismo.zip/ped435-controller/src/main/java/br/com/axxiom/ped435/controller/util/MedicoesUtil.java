package br.com.axxiom.ped435.controller.util;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.model.dao.enums.FormatoMedicaoEnum;
import br.com.axxiom.ped435.model.dao.enums.GrandezaEnum;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tgrandeza;

/**
 * Classe MedicoesUtil - Classe utilitária para manipulação dos registros de medição.
 * @author ssoares - Sólon Soares - solon.soares@axxiom.com.br<br />
 * Axxiom Soluções Tecnológicas S.A. - www.axxiom.com.br<br />
 */
public class MedicoesUtil {

	private static Logger log = Logger.getLogger(MedicoesUtil.class);
	
	/**
	 * Metodo getQtdTemposPorDia - Este metodo retorna a quantidade de intervalos que possui um dia
	 * de acordo com os minutos informados.
	 * Ex.: se 15 min de intervalos, então temos 96 intervalos de 15 minutos em um dia.
	 * @param minutos - Intervalo de minutos.
	 * @return - Retorna um inteiro com a quantidade de intervalos em um dia.
	 */
	public static int getQtdTemposPorDia(Integer minutos){
		return 24 * 60 / minutos;
	}
	
	/**
	 * Metodo getQtdTemposPorDia - Este metodo retorna a quantidade de intervalos que possui um dia
	 * de acordo com os minutos e a hora inicial informados. Subtrai a hora inicial do dia e calcula sobre o restante.
	 * @param intervalo - Intervalo de minutos.
	 * @param horaInicio - Hora de inicio do ciclo.
	 * @return - Retorna um inteiro com a quantidade de intervalos em um dia menos a hora inicial.
	 */
	public static int getQtdTemposPorDia(Integer intervalo, Date horaInicio){		
		Integer totalIntervalosDia = getQtdTemposPorDia(intervalo);
		Integer totalIntervaloInicio = 0;
		
		//Configura Calendar com primeira hora do dia.
		Calendar calDoDia = Calendar.getInstance();
		calDoDia.setTime(new Date());
		calDoDia.set(Calendar.HOUR_OF_DAY, 0);
		calDoDia.set(Calendar.MINUTE, 0);
		calDoDia.set(Calendar.SECOND, 0);
		calDoDia.set(Calendar.MILLISECOND, 0);		
		
		//Configura calendar com a hora Inicial de Medicao,
		//Para não ter problemas de ano, mes e dia, configuramos estes para o mesmo do Calendar com primeira hora do dia.
		//Somente interessa para nós o tempo de 1 dia.
		Calendar calHoraInicio = Calendar.getInstance();
		calHoraInicio.setTime(horaInicio);
		calHoraInicio.set(Calendar.YEAR, calDoDia.get(Calendar.YEAR));
		calHoraInicio.set(Calendar.MONTH, calDoDia.get(Calendar.MONTH));
		calHoraInicio.set(Calendar.DAY_OF_MONTH, calDoDia.get(Calendar.DAY_OF_MONTH));		
		calHoraInicio.set(Calendar.SECOND, calDoDia.get(Calendar.SECOND));
		calHoraInicio.set(Calendar.MILLISECOND, calDoDia.get(Calendar.MILLISECOND));
		
		//Caminha no tempo de acordo com o intervalo
		for (Calendar c = calDoDia; c.getTime().before(calHoraInicio.getTime()); c.add (Calendar.MINUTE, intervalo)) {
			log.debug("Hora Inicio: "+calHoraInicio.getTime());
			log.debug("Hora contador: "+c.getTime());
			++totalIntervaloInicio;
		}
		
		//Retira 2 porque o hora inicial 00:00 e a final não deve ser contabilizada.
		if (calHoraInicio.get(Calendar.MINUTE) >= 23 && calHoraInicio.get(Calendar.SECOND) >= 59)
			totalIntervaloInicio -= 2;
		else
			totalIntervaloInicio -= 1;
		
		return totalIntervalosDia - totalIntervaloInicio;
	}
	
	/**
	 * Método getMedicoesPorCanal - Este metodo obtem todas as medicoes de um canal, armazenado no campo valMedicoes da tabela Tmedicoes.
	 * 
	 * @param formatoMedicao - O formato que foi armazena a string de medicao.
	 * @param valMedicoes - O valor do campo valMedicoes da tabela Tmedicoes
	 * @param canal - O numero de canal a ser obtido as medições.
	 * @return - Retorna todas as medições de um dado canal.
	 */
	public static String[] getMedicoesPorCanal(FormatoMedicaoEnum formatoMedicao, String valMedicoes, Integer canal){
		String[] valMed = valMedicoes.split("\\|");
		String[] resultado = null;
		Integer posicaoInicial = 0;
		Integer posicaoFinal = 0;
		Integer intervalo = 0;
		
		if (formatoMedicao == FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS){
			for (int i=0; i<valMed.length; i++){
				
				if (valMed[i].contains("canal"+canal)){
					posicaoInicial = i + 2;
					i = posicaoInicial;
					continue;
				}
				
				if (valMed[i].contains("canal"+(canal+1))){
					posicaoFinal = i-1;
					break;
				}
				
				posicaoFinal = i;			
			}
			
			intervalo = posicaoFinal - posicaoInicial;
			resultado = new String[intervalo + 1];
			
			int k = 0;
			
			for (int i = posicaoInicial; i <= posicaoFinal; i++){
				resultado[k++] = valMed[i];
			}
		}
		
		
		return resultado;
	}
	
	/**
	 * Metodo checkChannel - Este metodo verifica se a quantidade de medicoes do canal está com a quantidade que deveria ter.
	 *
	 * @param formatoMedicao - O formato que foi armazenada a string contendo as medicoes.
	 * @param valMedicoes - String que contem os registros de medição
	 * @param canal - Numero do canal que será analisado.
	 * @param horaInicio - Hora de inicio das medições.
	 * @param intervalo - Intervalo entre uma medição e outra.
	 * @return - Retorna verdadeiro se a quantidade de medições for igual ao resultante do total de intervalos do dia subtraído da hora inicio.
	 */
	public static boolean checkChannel(FormatoMedicaoEnum formatoMedicao, String valMedicoes, Integer canal){
		
		String[] medicoes = getMedicoesPorCanal(formatoMedicao, valMedicoes, canal);
		Integer qtdTempo = getQtdTemposPorDia(getIntervalo(formatoMedicao, valMedicoes), getHoraInicio(formatoMedicao, valMedicoes));
				
		return (medicoes.length == qtdTempo);		
	}
	
	/**
	 * Metodo getHoraInicio - Este metodo obtem a hora inicial da string armazenada em valMedicoes na tabela Tmedicoes.
	 * @param valMedicoes - A string que contem as medicoes.
	 * @return - Retorna um Date contendo a hora inicial de armazenamento das medicoes.
	 */
	public static Date getHoraInicio(FormatoMedicaoEnum formatoMedicao, String valMedicoes){		
		String[] valMed = valMedicoes.split("\\|");
		Calendar cal = Calendar.getInstance();
		String strTime = null;
		
		if (formatoMedicao == FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS){

			strTime = valMed[1];
			Integer hora = Integer.parseInt(strTime.substring(0, 2));
			Integer minutos = Integer.parseInt(strTime.substring(3, 5));
					
			cal.set(Calendar.HOUR_OF_DAY, hora);
			cal.set(Calendar.MINUTE, minutos);
		}		
		
		return cal.getTime();
	}
	
	/**
	 * Metodo getIntervalo - Este metodo obtem o intervalo da string armazenada em valMedicoes na tabela Tmedicoes.
	 * @param valMedicoes - A string que contem os medicoes armazenadas.
	 * @return - Retorna o intervalo de tempos que foi armazenadas as medicoes.
	 */
	public static int getIntervalo(FormatoMedicaoEnum formatoMedicao, String valMedicoes){
		String[] valMed = valMedicoes.split("\\|");
		String strIntervalo = null;
		if (formatoMedicao == FormatoMedicaoEnum.FORMATO_MEDICAO_3_CANAIS){
			strIntervalo = valMed[0];
		}
		
		return Integer.parseInt(strIntervalo);
	}
	
	
	/**
	 * Metodo checkAllChannels - Este metodo verifica a quantidade de medicoes em todos os canais.
	 *
	 * @param formatoMedicao - O formato que foi armazenado as medicoes no banco de dados.
	 * @param valMedicoes - String contentdo as 3 medicoes.
	 * @param qtdCanais - Quantidade de canais analisados.
	 * @return - Retorna verdadeiro se os 3 canais possuirem a mesma quantidade de medições.
	 */
	public static boolean checkAllChannels(FormatoMedicaoEnum formatoMedicao, String valMedicoes, Integer qtdCanais){
		
		//Verificacao se todos os canais estao de acordo com a quantidade de intervalos do canal.
		for(int i=1; i<=qtdCanais; i++)
			if (!checkChannel(formatoMedicao, valMedicoes, i))
				return false;
		return true;

	}
	
	/**
	 * Metodo stringToDate - Este metodo transforma uma string de data no formato 99/99/99 para um objeto do tipo Date
	 * @param data - String com a data no formato 99/99/99
	 * @return - Retorna um objeto do tipo Date
	 */
	public static Date stringToDate(String data){
		Calendar cal = Calendar.getInstance();
		Integer dia = Integer.parseInt(data.substring(0, 2));
		Integer mes = Integer.parseInt(data.substring(3, 5));
		Integer ano = Integer.parseInt("20"+data.substring(6, 8));
		cal.set(Calendar.YEAR, ano);
		cal.set(Calendar.MONTH, mes -1);
		cal.set(Calendar.DAY_OF_MONTH, dia);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
	
	/**
	 * Metodo formatDecimal - Este metodo formata a saida de valores decimais de duas casas e menores que 9
	 * @param decimal - Valor do decimal a ser formatado.
	 * @return - Retorna a string com o decimal formatado.
	 */
	public static String formatDecimal(int decimal){
		
		if (decimal < 9)
			return "0"+String.valueOf(decimal);			
		else
			return String.valueOf(decimal);
	}
	
	/**
	 * Metodo geraStringMedicoesDoDia - Este metodo gera a String de medicao do dia, iniciando no canal 1.
	 * 
	 * @param medicoes -  Medicoes que serao utilizadas para criar a string de medicao
	 * @param grandeza -  Codigo da grandeza da medicao
	 * @param dataMedicao - Data da medicao
	 * @param intervalo - Intervalo que foi feito as medicoes. Ex.: 15 em 15 min ou 05 em 05 min.
	 * @return - Retorna a string gerada com as medicoes.
	 */
	public static String geraStringMedicoesDoDia(String[] medicoes, Integer grandeza, Date dataMedicao, Integer intervalo){
		
		Calendar cale = Calendar.getInstance();
		cale.setTime(dataMedicao);
		cale.add(Calendar.MINUTE, intervalo);		
		String horaInicio = formatDecimal(cale.get(Calendar.HOUR_OF_DAY))+":"+formatDecimal(cale.get(Calendar.MINUTE));		
				
		String medicaoDia = intervalo.toString()+"|"+horaInicio+"|canal1"+"|"+grandeza;		
		
		for (String med : medicoes){			
			medicaoDia += 	"|"+med;
		}
		return medicaoDia;
	}
	
	/**
	 * Metodo concatenaStringMedicoesCanalMedicao - Este metodo concatena a string de medicao com medicoes novas de outros canais.
	 * 
	 * @param valMedicao - Medicao base. Onde será concatenada a ela as outras medicoes de outros canais. 
	 * @param medicoes - Medicoes que serao utilizadas para concatenar ao valMedicao
	 * @param grandeza -  Codigo da grandeza da medicao
	 * @param dataMedicao - Data da medicao
	 * @param intervalo - Intervalo que foi feito as medicoes. Ex.: 15 em 15 min ou 05 em 05 min.
	 * @param numCanal - Numero do canal que será adicionado ao valMedicao. 
	 * @return - Retorna a string com as medicoes concatenadas.
	 */
	public static String concatenaStringMedicoesCanalMedicao(String valMedicao, String[] medicoes, Integer grandeza, Date dataMedicao, Integer intervalo, Integer numCanal){
		
		valMedicao += "|canal"+numCanal+"|"+grandeza;
		for (String med : medicoes){		
			valMedicao += 	"|"+med;
		}
		return valMedicao;
	}
	
	/**
	 * Método isMedicaoDuplicada - Este metodo verifica se a medicao que será adicionada a um
	 * consumidor já existe. A fim de nao duplica-la.
	 *  
	 * @param valMedicao - Valor da medicao ja configurada para o cliente.
	 * @param medicoes - Valor da medicao que sera concatenada.
	 * @param canal - Canal onde esta ocorrendo a duplicidade.
	 * @param intervalo - Intervalo de tempo entre as medicoes.
	 * @return - Retorna verdadeiro se for duplicado.
	 */
	public static boolean isMedicaoDuplicada(String valMedicao, String[] medicoes, Integer canal, Integer intervalo){
		
		String[] valMed = valMedicao.split("\\|");
		String[] valMedNew = new String[getQtdTemposPorDia(intervalo)];
		Integer posicaoInicial = 0;
		for (int i = 0; i<valMed.length; i++){
			
			if (valMed[i].equalsIgnoreCase("canal"+canal)){
				posicaoInicial = i + 2;
				break;				
			}
		}
		
		int k = 0;
		
		for (int j = posicaoInicial; j<(getQtdTemposPorDia(intervalo)+posicaoInicial); j++){
			valMedNew[k++] = valMed[j];
		}
		
		Set<String> set1 = new TreeSet<String> (String.CASE_INSENSITIVE_ORDER);
		Set<String> set2 = new TreeSet<String> (String.CASE_INSENSITIVE_ORDER);

		set1.addAll(Arrays.asList(valMedNew));
		set2.addAll(Arrays.asList(medicoes));

		return set1.containsAll(set2);		

	}
	
	/**
	 * Metodo apagaCanal - Este metodo apaga o canal da string de medicoes.
	 * @param valMedicao - String contendo as medicoes
	 * @param numCanal - Numero do canal a ser apagado
	 */
	public static void apagaCanal(String valMedicao, Integer numCanal){
		valMedicao = valMedicao.substring(0,valMedicao.indexOf("canal"+numCanal));
	}
	
	/**
	 * Metodo getGrandezaPorCanal - Este metodo obtem a grandeza de acordo com o canal.
	 * @param numCanal - Numero do canal que contém a grandeza.
	 * @return - Retorna um objeto Tgrandeza devidamente configurado.
	 */
	public static Tgrandeza getGrandezaPorCanal(Integer numCanal){
		Tgrandeza gr = new Tgrandeza();
				
		if (numCanal == 1){
			//Configura a grandeza eletrica para o canal 2.
			gr.setCodGrandeza(GrandezaEnum.KWH_DIRETO.getCodGrandeza());
			gr.setSigGrandeza(GrandezaEnum.KWH_DIRETO.getSigGrandeza());
			gr.setDesGrandeza(GrandezaEnum.KWH_DIRETO.getDesGrandeza());					
		}
		
		if (numCanal == 2){
			//Configura a grandeza eletrica para o canal 2.
			gr.setCodGrandeza(GrandezaEnum.KVARH_INDUTIVO_DIRETO.getCodGrandeza());
			gr.setSigGrandeza(GrandezaEnum.KVARH_INDUTIVO_DIRETO.getSigGrandeza());
			gr.setDesGrandeza(GrandezaEnum.KVARH_INDUTIVO_DIRETO.getDesGrandeza());			
		}
		
		if (numCanal == 3){
			//Configura a grandeza eletrica para o canal 3.		
			gr.setCodGrandeza(GrandezaEnum.KVARH_CAPACITIVO_DIRETO.getCodGrandeza());
			gr.setSigGrandeza(GrandezaEnum.KVARH_CAPACITIVO_DIRETO.getSigGrandeza());
			gr.setDesGrandeza(GrandezaEnum.KVARH_CAPACITIVO_DIRETO.getDesGrandeza());			
		}
		return gr;
	}
}
