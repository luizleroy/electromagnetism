/**
 * 
 */
package br.com.axxiom.ped435.controller.app;

import java.util.ArrayList;
import java.util.List;

import br.com.axxiom.ped435.controller.util.Config;
import br.com.axxiom.ped435.model.dao.service.TconsRevTarifariaService;
import br.com.axxiom.ped435.model.entidade.dbcon435.dbo.TconsRevTarifaria;

/**
 * @author luizleroy
 * 
 */
public class SerializarArquivos extends AbstractSerializador {

	private List<List<String>> listListCombo = new ArrayList<List<String>>();

	/*
	 * (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	// TODO pode-se começar o paralelismo aqui!
	@Override
	public void run() {
		TconsRevTarifariaService tconsRevTarifariaService = new TconsRevTarifariaService();
		List<String> listClasse = tconsRevTarifariaService.selectComboClasse();
		listListCombo.add(listClasse);
		List<String> listDesRamoAtivSor = tconsRevTarifariaService.selectComboDesRamoAtivSor();
		listListCombo.add(listDesRamoAtivSor);
		// List<String> listFaixa = tconsRevTarifariaService.selectComboFaixa();
		// listListCombo.add(listFaixa);
	}

	public List<List<String>> getListListCombo() {
		return listListCombo;
	}

	public void setListListCombo(List<List<String>> listListCombo) {
		this.listListCombo = listListCombo;
	}

	// FIXME vou voltar a utilizar o mybatis???
	public List<String> getListClientsByNumInstalacao(String dataCombo[]) {
		List<String> clientByNumInstalacao = new ArrayList<String>();
		if (dataCombo == null) {
			return clientByNumInstalacao;
		}
		TconsRevTarifariaService tconsRevTarifariaService = new TconsRevTarifariaService();
		List<TconsRevTarifaria> allClientsByNumInstalacao = tconsRevTarifariaService.selectAll();
		String todos = Config.getKey("all.classes");
		for (TconsRevTarifaria tconsRevTarifaria : allClientsByNumInstalacao) {
			// for(int i = 0; i < dataCombo.length; i++) {
			// // // TODO -> verificar se é bug ao voltar a utlizar este código
			// }
			if ((tconsRevTarifaria.getDesClasse().equals(dataCombo[0]))
					&& (tconsRevTarifaria.getDesRamoAtivSor().equals(dataCombo[1]))) {
				clientByNumInstalacao.add(tconsRevTarifaria.getNumInstalacao());
			}
		}
		return clientByNumInstalacao;
	}
}
