package br.com.axxiom.ped435.functions;

import java.util.List;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.model.dao.service.TValidSimplefitService;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidSimplefit;
import br.com.axxiom.ped435.model.util.Matrix;
import br.com.axxiom.ped435.util.Const;
import br.com.axxiom.ped435.util.TestFunction;

public class Encoding implements TestFunction {
	private static Logger log = Logger.getLogger(Encoding.class);
	private double errorAndRestriction = 0.;
	private long counter;

	private static final double modInit = 10.;

	// a ordem de inicialização é importante: o build abaixo constrói o tamanho
	// da topologia da RNA e configura o tamanho do vetor de entrada do PSO que
	// por sua vez monta as dimensãoes dos vetores de iniecialização abaixo
	private final Matrix[] xy = build();
	private double[] dnValue = new double[Const.dims];
	private double[] upValue = new double[Const.dims];
	private double[] optimum = new double[Const.dims];

	private void init(double t[], double val) {
		for (int i = 0; i < Const.dims; i++) {
			t[i] = val;
		}
	}

	public Encoding() {
		this.setDnValue();
		this.setUpValue();
		this.setOptimum();
		this.counter = 0L;
		Const.samples = xy[0].getC();
	}

	private void setDnValue() {
		this.init(this.dnValue, -modInit);
	}

	@Override
	public double[] getDnValue() {
		return this.dnValue;
	}

	private void setUpValue() {
		this.init(this.upValue, modInit);
	}

	@Override
	public double[] getUpValue() {
		return this.upValue;
	}

	private void setOptimum() {
		this.init(this.optimum, errorAndRestriction);
	}

	@Override
	public double[] getOptimum() {
		return this.optimum;
	}

	@Override
	public double get(double[] f) {
		this.counter++;
		double erros;
		try {
			Matrix w[] = buildW(f);
			Matrix wb[] = buildWB(f);
			erros = 0.;
			double err = 0.;
			for (int k = 0; k < Const.samples; k++) {
				Matrix r = xy[0].buildVectorCol(k);
				// LEMBRAR: O VETOR DE ENTRADA XY CONTÉM O CONJUNTO DE ENTRADAS NA
				// PRIMEIRA MATRIZ E O CONJUNTO DE SAIDAS NA SEGUNDA MATRIZ
				r = r.transpose();
				for (int m = 0; m < (Const.nNeur.length - 1); m++) {
					r = (r.multiply(w[m])).add(wb[m]);
					r = r.expPlus1Inv();
				}
				for (int p = 0; p < xy[1].getL(); p++) {
					err = r.get(0, p) - xy[1].get(p, k);
					erros += err * err;
				}
			}
			erros = erros / (xy[1].getL() * Const.samples);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
		return erros;
	}

	/**
	 * Recebe o vetor de pesos completo da RNA e codifica na matriz de pesos.
	 * VIDE _codifica_pesos.m.
	 * 
	 * @param f
	 *            é o vetor de pesos candidato
	 * @return matrizes de peso da RNA
	 */

	public Matrix[] buildW(double[] f) {
		int size = Const.nNeur.length - 1;
		Matrix[] w = new Matrix[size];
		int cont = 0;
		for (int k = 0; k < size; k++) {
			double wk[][] = new double[Const.nNeur[k]][Const.nNeur[k + 1]];
			for (int m = 0; m < Const.nNeur[k]; m++) {
				for (int n = 0; n < Const.nNeur[k + 1]; n++) {
					wk[m][n] = f[cont];
					cont++;
				}
			}
			w[k] = new Matrix(wk);
		}
		return w;
	}

	/**
	 * Recebe o vetor de pesos completo da RNA e codifica na matriz de pesos
	 * (Bias). VIDE RNA_codifica_pesos.m.
	 * 
	 * @param f
	 *            é o vetor de pesos candidato
	 * @return matrizes de peso da RNA
	 */
	public Matrix[] buildWB(double[] f) {
		int size = Const.nNeur.length - 1;
		Matrix[] b = new Matrix[size];
		int cont = Const.firstIndexWB;
		for (int k = 0; k < size; k++) {
			double wk[][] = new double[1][Const.nNeur[k + 1]];
			for (int n = 0; n < Const.nNeur[k + 1]; n++) {
				wk[0][n] = f[cont];
				cont++;
			}
			b[k] = new Matrix(wk);
		}
		return b;
	}

	@Override
	public void resetCounter() {
		counter = 0L;
	}

	@Override
	public long getCounter() {
		return counter;
	}

	// TODO @Override
	protected Matrix[] build() {
		// TODO: para desempenho: testar também JDBC direto: APENAS EM GRANDE
		// CARGA DE DADOS!
		TValidSimplefitService tValidSimplefitService = new TValidSimplefitService();
		List<TValidSimplefit> list = tValidSimplefitService.select();
		int x = 1;
		int y = 1;
		int[] nNeurData = { x, 20, y };
		Const.configuraDimRNA(nNeurData);
		double[][] targetx = new double[x][list.size()];
		double[][] targety = new double[y][list.size()];
		for (int i = 0; i < list.size(); i++) {
			targetx[0][i] = list.get(i).getInput();
			targety[0][i] = list.get(i).getOutput();
		}
		Matrix xx = new Matrix(targetx);
		Matrix yy = new Matrix(targety);
		Matrix target[] = { xx, yy };
		return target;
	}

	public void getEstatistica(double[] f) {
		Matrix w[] = buildW(f);
		Matrix wb[] = buildWB(f);
		double err = 0.;
		StringBuilder stringBuilderLog = new StringBuilder("\nErro" + Const.separator + "="
				+ Const.separator
				+ "(calculado" + Const.separator + Const.separator + "-" + Const.separator
				+ "real)^2\n");
		for (int k = 0; k < Const.samples; k++) {
			Matrix r = xy[0].buildVectorCol(k);
			// LEMBRAR: O VETOR DE ENTRADA XY CONTÉM O CONJUNTO DE ENTRADAS NA
			// PRIMEIRA MATRIZ E O CONJUNTO DE SAIDAS NA SEGUNDA MATRIZ
			r = r.transpose();
			for (int m = 0; m < (Const.nNeur.length - 1); m++) {
				r = (r.multiply(w[m])).add(wb[m]);
				r = r.expPlus1Inv();
			}
			for (int p = 0; p < xy[1].getL(); p++) {
				err = r.get(0, p) - xy[1].get(p, k);

				stringBuilderLog.append(err * err).append(Const.separator).append("=")
						.append(Const.separator+"(").append(r.get(0, p))
						.append(Const.separator).append("-")
						.append(Const.separator).append(xy[1].get(p, k))
						.append(")^2\n");
			}
		}
		log.debug(stringBuilderLog.toString());
	}
}
