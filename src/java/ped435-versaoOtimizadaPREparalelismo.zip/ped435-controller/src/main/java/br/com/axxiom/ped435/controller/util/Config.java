package br.com.axxiom.ped435.controller.util;

import java.util.ResourceBundle;

/**
 * Classe Config - Esta classe é um FACADE para a classe ResourceBundle
 * 
 * @author Sólon Soares - solon.soares@axxiom.com.br<br/>
 * Axxiom Solucoes Tecnologicas S.A.<br/>
 * www.axxiom.com.br
 */
public class Config {

    private static final ResourceBundle bundle = ResourceBundle.getBundle("config-ped435");

    public static String getKey(String key) {

        return bundle.getString(key);
    }    
    
    public static boolean containsKey(String key) {
        return bundle.containsKey(key);
    }
}
