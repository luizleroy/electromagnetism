package br.com.axxiom.ped435.controller.readers;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import au.com.bytecode.opencsv.CSVReader;
import br.com.axxiom.ped435.controller.iface.InterfaceReaders;

public class CSVAxxiomReader implements InterfaceReaders {

	private static Logger log = Logger.getLogger(CSVAxxiomReader.class);

	public List<String[]> read(String file) {
	
		List<String[]> arrayList = new ArrayList<String[]>();
		
		try {
		
			@SuppressWarnings("resource")
			CSVReader reader = new CSVReader(new FileReader(file), ';');
			String[] nextLine;
			Integer line=1;
			log.info("Lendo arquivo: " + file);

			while ((nextLine = reader.readNext()) != null ) {
				log.info("linha: "+line+" Dado Posicao 1: "+ nextLine[0]);				
				if (nextLine.length > 0){
					arrayList.add(nextLine);					
				}
				else {
					throw new IOException("Warning : Linha: " + line + " estah em branco.");
				}
				line ++;
			}			
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return arrayList;
	}
	
	public CSVReader read(String file, char separator){
		
		CSVReader reader = null;
		try {			
			reader = new CSVReader(new FileReader(file), separator);
			log.info("Lendo arquivo: " + file);			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return reader;
	}
}
