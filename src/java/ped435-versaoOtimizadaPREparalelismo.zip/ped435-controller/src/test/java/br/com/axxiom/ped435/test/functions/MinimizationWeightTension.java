package br.com.axxiom.ped435.test.functions;

import br.com.axxiom.ped435.util.Const;
import br.com.axxiom.ped435.util.TestFunction;



public class MinimizationWeightTension implements TestFunction {
	
	private double[] dnValue = new double[3];
	private double[] upValue = new double[3];
	private double[] optimum = new double[3];
	private long counter;
	
	public MinimizationWeightTension() {
		Const.dims = 3;
		if(Const.dims != 3) {
			throw new RuntimeException("DIM is required to BE EQUAL TO 3 to perform this function!");
		}
		this.setDnValue();
		this.setUpValue();
		this.setOptimum();
		this.counter = 0L;
	}
	
	private void setDnValue() {
		dnValue[0] = (0.05);
		dnValue[1] = (0.25);
		dnValue[2] = (2.);

	}
	
	@Override
	public double[] getDnValue() {
		return this.dnValue;
	}

	private void setUpValue() {
		upValue[0] = (2.);
		upValue[1] = (1.3);
		upValue[2] = (15.);
	}
	
	@Override
	public double[] getUpValue() {
		return this.optimum;
	}

	private void setOptimum() {
		// best solution by: Solving Engineering Optimization Problem /
		// lcagnina@unsl.edu.ar / Carlos A. Coello Coello
		// f(x) = 1.724852
		optimum[0] = 0.;
		optimum[1] = 0.;
		optimum[2] = 0.;
	}

	@Override
	public double[] getOptimum() {
		return this.optimum;
	}
	
	@Override
	public double get(double[] x) {
		double x1 = x[0];
		double x2 = x[1];
		double x3 = x2;
		this.counter++;
		return (x3+2)*x2*x1;
	}

	public double[] getRestriction(double[] x) {
		double[] target = new double[4];
		double x1 = x[0];
		double x2 = x[1];
		double xx2 = x2 * x2;
		double xxx2 = xx2 * x2;
		double x3 = x[2];
		double xx3 = x3 * x3;
		double xxx3 = xx3 * x3;
		double xxxx3 = xxx3 * x3;

		Double g1 = 1 - xxx2*x3/71785/x2;
		target[0]=g1;
		Double g2 = 4*xx2-x1*x2/12566/(x2*xxx3-xxxx3);
		target[1]=g2;
		Double g3 = 1 - 140.45*x1/xx2/x3;
		target[2]=g3;
		Double g4 = (x1 + x2)/1.5 - 1;
		target[3]=g4;

		return target;
	}
	
	@Override
	public void resetCounter() {
		counter = 0L;
	}

	@Override
	public long getCounter() {
		return this.counter;
	}
	
}
