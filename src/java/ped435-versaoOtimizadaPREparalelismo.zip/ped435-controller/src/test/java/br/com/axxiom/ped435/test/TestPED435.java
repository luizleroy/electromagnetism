package br.com.axxiom.ped435.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.junit.Test;

import br.com.axxiom.ped435.controller.util.Util;
import br.com.axxiom.ped435.functions.Encoding;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.EncodedEntity;
import br.com.axxiom.ped435.model.util.Matrix;
import br.com.axxiom.ped435.pso.PSONativeDataStruct;
import br.com.axxiom.ped435.test.functions.Function;
import br.com.axxiom.ped435.util.Const;

import com.cedarsoftware.util.io.JsonWriter;

public class TestPED435 {
	private static Logger log = Logger.getLogger(TestPED435.class);
	private static final short printTest = 1;
	// É uma condição "de assert": considera-se que 11 é um número mágico bom...
	private static final short numTest = 10;

	public static void main(String[] args) {
//		Runnable runnable = () -> TestPED435.run();
//		runnable.run();
		run();
	}
	
	public static void run() {
		TestPED435 testPED435 = new TestPED435();
		testPED435.testWithFunctionsBenchmark();
		testPED435.testWithDataRNA();
		// leitura em banco não executa no Maven!
		// testWithDataRNAReadSQLServer();
	}

	@Test
	public void testWithDataRNA() {
		Const.setLog();
		long initialTime = System.nanoTime();
		SimpleDateFormat dt = new SimpleDateFormat("yy/MM/dd HH:mm:ss.SSS EEE");
		log.info(dt.format(new Date()));
		// separator, // dois para visualização no console de saída
		String sFuncts[] = { "xOR2", "xOR3", "xOR4" };
		for (int i = 0; i < sFuncts.length; i++) { // numExec
			optimizationByDataRNA(sFuncts[i]);
		}
		long finalTime = System.nanoTime();
		log.info("Total: " + ((finalTime - initialTime) / 1e9) + "s");
	}

	@Test
	public void testWithFunctionsBenchmark() {
		Const.setLog();
		long initialTime = System.currentTimeMillis();
		SimpleDateFormat dt = new SimpleDateFormat("yy/MM/dd HH:mm:ss.SSS EEE");
		log.info(dt.format(new Date()));
		/*
		 * Pode-se testar com as funções de engenharia abaixo, separadamente e
		 * após revisar qual é o valor ótimo, segundo suas estatísticas:
		 * "minimizationWeightTension"
		 * ,"minimizationWeightSpeed","designWeldedBeam","designPressureVessel"
		 */

		/*
		 * A função "rosenbrock" só operada com exatamente duas variáves
		 */
		String sFuncts[] = { "sphere\t", "bohachevsky", "dejong_1", "rastrigin", "schaffer", "schwefel_1",
				"schwefel_2", "schwefel_3" };
		for (int i = 0; i < sFuncts.length; i++) {
			optimizationByFunctionBenchmark(sFuncts[i]);
		}
		long finalTime = System.currentTimeMillis();
		log.info("Total: " + ((finalTime - initialTime) / 1000.) + "s");
	}

	// testes com dados de banco não são compatíveis com JUNIT/Maven...
	private static void testWithDataRNAReadSQLServer() {
		Const.setLog();
		long initialTime = System.nanoTime();
		SimpleDateFormat dt = new SimpleDateFormat("yy/MM/dd HH:mm:ss.SSS EEE");
		log.info(dt.format(new Date()));
		// separator, // dois para visualização no console de saída
		String sFuncts[] = { "grupo13", "encoding" };
		for (int i = 0; i < sFuncts.length; i++) {
			optimizationByDataRNA(sFuncts[i]);
		}
		long finalTime = System.nanoTime();
		log.info("Total: " + ((finalTime - initialTime) / 1e9) + "s");
	}

	private static void optimizationByDataRNA(String sFun) {
		long initialTime = System.nanoTime();
		double mseM = 0.;
		double bestBest = Double.MAX_VALUE;
		double bestBestArray[] = null;
		int mediaChamadaFunc = 0;
		for (int i = 0; i < numTest; i++) {
			Const.func = Function.factoryMethod(sFun);
			double best[] = PSONativeDataStruct.pso();
			mediaChamadaFunc += Const.func.getCounter();
			double result = Const.func.get(best);
			mseM += result;
			// FIXME é necessário garantir que esta porção de código só exibe
			// testes...
			if ((i % printTest) == 0) { // diminuir o número de logs com grande
				// quantidade de testes.
				log.debug(String.format("nNeur[%d]=", Const.nNeur.length) + Arrays.toString(Const.nNeur));
				log.debug("Const.firstIndexWB: " + Const.firstIndexWB);
				((Encoding) Const.func).getEstatistica(best);
				log.debug(String.format("Erro do \"%s\" no teste %d):%e", sFun, i, result));
				log.trace("Arrays.toString(best): " + Arrays.toString(best));
			}
			if (bestBest > result) {
				bestBest = result;
				bestBestArray = best;
			}
			log.debug("result: " + result);
		}
		double mediaQtdChamadaFunc = ((double) mediaChamadaFunc) / numTest;
		log.debug("Melhor resultado encontrado, ou seja, \"o cara\": " + bestBest);

		long finalTime = System.nanoTime();
		mseM = mseM / numTest;
		long tt = finalTime - initialTime;
		double lMtime = ((double) tt) / 1e9; // tempo em nanosegundos convertido
												// para segundos
		double sMtime = lMtime / numTest;
		double constTest = 0.05;
		char isBad = mseM > constTest ? '*' : ' ';
		String type = "RNA";
		StringBuilder logg = printStudy(sFun, mseM, sMtime, isBad, mediaQtdChamadaFunc, type);
		log.info(logg);

		assert (mseM < constTest) : "Falha em " + sFun;

		// String form =
		// "%s => Const.dims: %d | %s | Const.loop: %1$,d | numTest: %d | Const.dots: %1$,d | mediaQtdChamadaFunc: %1$,.0f | sMtime: %.2es | meanError: %.2e%c";
		// log.info(String.format(form, sFun, Const.dims, "RNA", Const.loop,
		// numTest, Const.dots, mediaQtdChamadaFunc,
		// sMtime, mseM, isBad));

		if (bestBestArray == null) {
			throw new RuntimeException("Ningém foi melhor na avalicação que o Double.MAX_VALUE! Debugar PSO!!!");
		} else {
			log.debug(Arrays.toString(bestBestArray));
			Matrix matrixW[] = ((Encoding) Const.func).buildW(bestBestArray);
			log.debug(Arrays.toString(matrixW));
			Matrix matrixWB[] = ((Encoding) Const.func).buildWB(bestBestArray);
			log.debug(Arrays.toString(matrixWB));
			log.info(String.format("Melhor RNA tipo %s caracterizada por nNeur[%d] = %s:", Const.func.getClass(),
					Const.nNeur.length, Arrays.toString(Const.nNeur)));

			int count = 0;
			for (int i = 0; i < matrixW.length; i++) {
				assert (Const.nNeur[count] == matrixW[i].getL());
				count++;
				assert (Const.nNeur[count] == matrixW[i].getC());
			}
			for (int i = matrixWB.length - 1; i > -1; i--) {
				assert (1 == matrixWB[i].getL());
				assert (Const.nNeur[count] == matrixWB[i].getC());
				count--;
			}

			count = 0;
			for (int i = 0; i < matrixW.length; i++) {
				for (int l = 0; l < matrixW[i].getL(); l++) {
					for (int c = 0; c < matrixW[i].getC(); c++) {
						assert (bestBestArray[count] == matrixW[i].get(l, c)) : String.format(
								"bestBestArray[%d] != matrixW[%d].get(%d, %d)) | %f != %f", count, i, l, c,
								bestBestArray[count], matrixW[i].get(l, c));
						count++;
					}
				}
			}
			for (int i = 0; i < matrixWB.length; i++) {
				for (int l = 0; l < matrixWB[i].getL(); l++) {
					for (int c = 0; c < matrixWB[i].getC(); c++) {
						assert (bestBestArray[count] == matrixWB[i].get(l, c)) : String.format(
								"bestBestArray[%d] != matrixWB[%d].get(%d, %d)) | %f != %f", count, i, l, c,
								bestBestArray[count], matrixWB[i].get(l, c));
						count++;
					}
				}
			}
			serializationWeights(bestBest, bestBestArray, matrixW, matrixWB);
		}
	}

	private static void serializationWeights(double bestBest, double[] bestBestArray, Matrix[] matrixW,
			Matrix[] matrixWB) {
		// TODO verificar o texto abaixo..
		log.info(String.format("Serialização do melhor resultado de erro médio em %s: %f",
				Util.formatNameFileEncoding(Const.func.getClass()), bestBest));
		EncodedEntity enc = new EncodedEntity();
		enc.setBestBestArray(bestBestArray);
		enc.setBestBest(bestBest);
		enc.setnNeur(Const.nNeur);
		String string = Util.createURIJson(Const.func, Calendar.getInstance().getTime());
		createJSONFile(string, enc);
	}

	/**
	 * @param relativePath
	 * @throws FileNotFoundException
	 * @throws IOException
	 *             TODO: não deveria estar na camada MODEL ???
	 */
	public static void createJSONFile(String relativePath, Object entity) {
		// Exempl. conforme: https://code.google.com/p/json-io/
		// TODO para escrita VIDE POCJsonIO.java em model
		// Example 4: Java Object to OutputStream
		// tempToWrite.setCodTemperatura(777);
		OutputStream outputStream;
		try {
			outputStream = new FileOutputStream(new File(relativePath));
			JsonWriter jw = new JsonWriter(outputStream);
			jw.write(entity);
			jw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// emp obtained from database
	}

	private static void optimizationByFunctionBenchmark(String sFun) {
		long initialTime = System.nanoTime();
		double mseM = 0.;
		long mediaChamadaFunc = 0L;
		for (int i = 0; i < numTest; i++) {
			Const.func = Function.factoryMethod(sFun);
			double bestPSO[] = PSONativeDataStruct.pso();
			mediaChamadaFunc += Const.func.getCounter();
			double result = calcMSEDims(bestPSO);
			mseM += result;
			if ((i % printTest) == 0) { // diminuir o número de logs com grande
				// quantidade de testes.
				log.debug(String.format("Melhor saída encontrada em %s no teste %d:", sFun, i));
				log.debug(Arrays.toString(bestPSO));
			}
		}
		long finalTime = System.nanoTime();
		mseM = mseM / numTest;
		long tt = finalTime - initialTime;
		double lMtime = ((double) tt) / 1e9; // tempo em nanosegundos convertido
												// para segundos
		double sMtime = lMtime / numTest;
		double constTest = 0.05;
		char isBad = mseM > constTest ? '*' : ' ';
		double mediaQtdChamadaFunc = ((double) mediaChamadaFunc) / numTest;
		String type = "PSO";
		StringBuilder logg = printStudy(sFun, mseM, sMtime, isBad, mediaQtdChamadaFunc, type);

		log.info(logg);

		assert (mseM < constTest) : "Falha em " + sFun;
	}

	private static StringBuilder printStudy(String sFun, double mseM, double sMtime, char isBad,
			double mediaCF, String type) {
		long maxCF = (Const.loop + 1) * Const.dots;
		StringBuilder stringBuilder = new StringBuilder(String.format("%s %s (%d) => ", type, sFun, Const.dims));
		stringBuilder.append(String.format("Const.dots: %,d | ", Const.dots));
		stringBuilder.append(String.format("Const.loop: %,d | ", Const.loop));
		stringBuilder.append(String.format("maxCF: %,d | ", maxCF));
		double percent = 100 * ((double) mediaCF)
				/ ((double) maxCF);
		stringBuilder.append(String.format("Média Chamdada Func.: %.2f %s | ", percent, "%"));
		stringBuilder.append(String.format("mediaCF: %,.0f | ", mediaCF));
		stringBuilder.append(String.format("numTest: %d | ", numTest));
		stringBuilder.append(String.format("meanError: %.2e%c | ", mseM, isBad));
		stringBuilder.append(String.format("sMtime: %.3es | ", sMtime));
		return stringBuilder;
	}

	// MSE - mean square error | Em relação a distância euclidiana dos valores
	// de entrada
	private static double calcMSEDims(double[] best) {
		double sumErrDim2 = 0.;
		double optimum[] = Const.func.getOptimum();
		for (int i = 0; i < Const.dims; i++) {
			double diff = best[i] - optimum[i];
			sumErrDim2 += Math.pow((diff), 2);
		}
		return Math.sqrt(sumErrDim2) / Const.dims;
	}
}