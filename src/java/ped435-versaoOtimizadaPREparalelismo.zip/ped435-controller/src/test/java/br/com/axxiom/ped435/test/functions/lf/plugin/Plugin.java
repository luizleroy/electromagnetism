package br.com.axxiom.ped435.test.functions.lf.plugin;

import br.com.axxiom.ped435.test.functions.lf.rede.Rede;


public interface Plugin {
	public Rede carregaRede(String nomeArquivo);
	
}
