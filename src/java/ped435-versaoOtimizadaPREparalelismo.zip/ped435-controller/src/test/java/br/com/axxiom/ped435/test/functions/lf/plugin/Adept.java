package br.com.axxiom.ped435.test.functions.lf.plugin;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import flanagan.complex.Complex;

import br.com.axxiom.ped435.test.functions.Schwefel_3;
import br.com.axxiom.ped435.test.functions.lf.rede.Rede;

/**
 * Não inserir circuito com chaves abertas!!!
 * @author lhipolito
 *
 */
public class Adept implements Plugin {
	private static Logger log = Logger.getLogger(Adept.class);
	private Rede redeAdept;

	public Adept() {
		redeAdept = new Rede();
	}

	public Rede carregaRede(String nomeArquivo) {

		Map<String, List<String>> mapAdept = this.carregaArquivo(nomeArquivo);

		// Carrega o arquivo com o DE/Para entre o código do GDIS e do Adept
		Map<String, Integer> mapAdeptDePara = this
				.carregaBibliotecaDePara("src/test/resources/condeqp.txt");

		// Carrega a biblioteca de condutores. Somente os condutores presente no
		Map<String, List<Double>> mapAdeptCondutores = this
				.carregaBibliotecaCondutores(
						"src/test/resources/Adept_ATUALIZADA_dezembro2010.con", mapAdeptDePara);

		// Carrega as barras
		this.carregaNodes(mapAdept.get("NODES"));

		// Carrega as cargas
		this.carregaLoads(mapAdept.get("LOADS"));

		// Carrega os Branchs (Trechos / Chaves / RT�s)
		// FIXME: ADEPT NÃO CARREGA BRANCH DEPOIS DAS CHAVES!
		//this.carregaBranch(mapAdept.get("BRANCH"), mapAdeptCondutores);

		// Carrega a fonte
		this.carregaSource(mapAdept.get("SOURCE"));

		return redeAdept;
	}

	// Carrega o arquivo completo do Adept e retorna um Map
	private Map<String, List<String>> carregaArquivo(String nomeArquivo) {
		Map<String, List<String>> mapAdept = new HashMap<String, List<String>>();
		List<String> linhaLista = new ArrayList<String>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(nomeArquivo));
			while (br.ready()) {
				String linha = br.readLine();
				// log.info(linha);

				linhaLista.add(linha);

				// Fim de uma se��o do arquivo | verifica se o texto come�a com
				// END
				if (linha.length() > 3 && linha.substring(0, 3).equals("END")) {
					String nomeSecao = linha.substring(5, linha.length());
					linhaLista.remove(linhaLista.size() - 1); // remove a ultima
																// linha
																// inserida... �
																// a linha que
																// come�a com
																// END
					// Coloca dentro do map do Adept
					mapAdept.put(nomeSecao, linhaLista);
					// Cria uma nova linha
					linhaLista = new ArrayList<String>();
				}
			}
			br.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		return mapAdept;
	}

	private void carregaNodes(List<String> listNodes) {

		for (String linhaNode : listNodes) {

			String[] linhaSplit = linhaNode.split(" ");

			Integer IdBarra = Integer.valueOf(linhaSplit[0]);
			Double tensaoNominal = Double.valueOf(linhaSplit[1]);
			Double coordX = Double.valueOf(linhaSplit[2]);
			Double coordY = Double.valueOf(linhaSplit[3]);

			redeAdept.addBarra(IdBarra, tensaoNominal, coordX, coordY);

		}

	}

	private void carregaLoads(List<String> listLoads) {

		for (String linhaLoad : listLoads) {

			String[] linhaSplit = linhaLoad.split(" ");

			// Identificador da barra da rede
			Integer IdBarra = Integer.valueOf(linhaSplit[0]);

			Integer modeloCarga = 1; // valor default do modelo de carga -
										// Corrente Constante

			// Converte o modelo de Carga do Adept para o modelo Exponencial.
			if (Integer.valueOf(linhaSplit[2]) == 1)
				modeloCarga = 0; // potencia constante
			else if (Integer.valueOf(linhaSplit[2]) == 2)
				modeloCarga = 2; // impedancia constante
			else if (Integer.valueOf(linhaSplit[2]) == 3)
				modeloCarga = 1; // corrente constante

			// Fase A
			Complex potenciaNom_FsA = new Complex();
			potenciaNom_FsA.setReal(Double.valueOf(linhaSplit[3]));
			potenciaNom_FsA.setImag(Double.valueOf(linhaSplit[4]));

			// Fase B
			Complex potenciaNom_FsB = new Complex();
			potenciaNom_FsB.setReal(Double.valueOf(linhaSplit[5]));
			potenciaNom_FsB.setImag(Double.valueOf(linhaSplit[6]));

			// Fase C
			Complex potenciaNom_FsC = new Complex();
			potenciaNom_FsC.setReal(Double.valueOf(linhaSplit[7]));
			potenciaNom_FsC.setImag(Double.valueOf(linhaSplit[8]));

			redeAdept.addCargaBarra(IdBarra, modeloCarga, potenciaNom_FsA,
					potenciaNom_FsB, potenciaNom_FsC);

		}

	}

	private void carregaSource(List<String> listSources) {

		if (listSources.size() > 1) {
			log.info(" Existe mais de uma fonte neste alimentador");
			return;
		}

		String[] linhaSplit = listSources.get(0).split(" ");

		Integer idBarraSource = (Integer.valueOf(linhaSplit[0]));

		if (this.redeAdept.getBarra(idBarraSource) == null) {
			log.info(" A barra da fonte n�o est� na lista de barras");
			return;
		} else {
			redeAdept.setBarraFonte(idBarraSource);
		}

	}

	private Map<String, Integer> carregaBibliotecaDePara(String nomeArquivo) {

		String linha = null;

		Map<String, Integer> mapAdeptDePara = new HashMap<String, Integer>();
		BufferedReader br = null;
		try {

			br = new BufferedReader(new FileReader(nomeArquivo));

			while (br.ready()) {
				linha = br.readLine();
				mapAdeptDePara.put(linha, 0);
			}

		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return mapAdeptDePara;

	}

	private Map<String, List<Double>> carregaBibliotecaCondutores(
			String nomeArquivoBiblioteca, Map<String, Integer> mapAdeptDePara) {

		Map<String, List<Double>> mapAdeptCondutores = new HashMap<String, List<Double>>();

		String linha = null;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(nomeArquivoBiblioteca));

			boolean inicioDados = false;

			// Procura o inicio dos dados da Biblioteca
			// o inicio dos dados est� quando o inicio da linha come�a com valor
			// diferente de "!"
			while (br.ready() && inicioDados == false) {

				linha = br.readLine();

				// log.info("Substring: " + linha.substring(0, 1) +
				// " teste: " + linha.substring(0, 1).equals("!"));

				if (linha.substring(0, 1).equals("!") == false)
					inicioDados = true;

			}

			// Percore a lista de condutores e chaves
			do {

				if (linha.substring(0, 2).equals("*,") == false) {

					String condutorDescricao = linha.substring(0, 28).replace(
							" ", "");
					String condutorImpedancia = linha.substring(28,
							linha.length() - 1);

					if (mapAdeptDePara.containsKey(condutorDescricao)) {
						String[] linhaSplit = condutorImpedancia.split(",");

						Double r1 = Double.valueOf(linhaSplit[0].replace(" ",
								""));
						Double x1 = Double.valueOf(linhaSplit[1].replace(" ",
								""));

						Double r0 = Double.valueOf(linhaSplit[2].replace(" ",
								""));
						Double x0 = Double.valueOf(linhaSplit[3].replace(" ",
								""));

						List<Double> listImpedancia = new ArrayList<Double>();

						listImpedancia.add(r1);
						listImpedancia.add(x1);
						listImpedancia.add(r0);
						listImpedancia.add(x0);

						mapAdeptCondutores.put(condutorDescricao,
								listImpedancia);

						mapAdeptDePara.put(condutorDescricao, 1);
					}

				}

				linha = br.readLine();

			} while (br.ready());

		} catch (IOException ioe) {
			ioe.printStackTrace();

		} finally {
			try {
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		// log.info("map DE PARA:" + mapAdeptDePara.toString());

		return mapAdeptCondutores;

	}

}
