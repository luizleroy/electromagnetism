package br.com.axxiom.ped435.test.functions.lf.plugin;

import br.com.axxiom.ped435.test.functions.lf.rede.Rede;
import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;

public class RedeIEEE4NodesTestFeeder {

	private Rede rede;

	public RedeIEEE4NodesTestFeeder() {

		this.rede = new Rede();

	}

	public Rede carregaRede() {
		this.carregaBarras();
		this.carregaCargas();
		this.carregaTrechos();
		this.carregaFonte();
		return rede;
	}

	private void carregaBarras() {

		double tensaoNominal = 12470.; // volts

		this.rede.addBarra(1, tensaoNominal);
		this.rede.addBarra(2, tensaoNominal);
		this.rede.addBarra(3, tensaoNominal);
		this.rede.addBarra(4, tensaoNominal);
	}

	private void carregaCargas() {

		Complex cargaFase = new Complex(1800, 0.0); // em kW -> TODO verificar
													// FP

		rede.addCargaBarra(4, 0, cargaFase, cargaFase, cargaFase);
	}

	private void carregaTrechos() {
		ComplexMatrix ZabcAux;
		Complex ZApropria;

		ZabcAux = new ComplexMatrix(3, 3); // ohms / mile
		ZApropria = new Complex(0.4013, 1.4133);
		ZabcAux.setElement(0, 0, ZApropria);
		ZabcAux.setElement(1, 1, ZApropria);
		ZabcAux.setElement(2, 2, ZApropria);

		ZabcAux.setElement(0, 1, new Complex(0.0953, 0.8515));
		ZabcAux.setElement(1, 0, new Complex(0.0953, 0.8515));

		ZabcAux.setElement(0, 2, new Complex(0.0953, 0.7266));
		ZabcAux.setElement(2, 0, new Complex(0.0953, 0.7266));

		ZabcAux.setElement(1, 2, new Complex(0.0953, 0.7802));
		ZabcAux.setElement(2, 1, new Complex(0.0953, 0.7802));

		// converter pés em milhas: mi =ft * 0.00018939
		this.rede.addTrecho(1, 2, "ABC", 2000. * 0.00018939, ZabcAux);

		ZabcAux = new ComplexMatrix(3, 3); // ohms / mile
		ZApropria = new Complex(0.4013, 1.4133);
		ZabcAux.setElement(0, 0, ZApropria);
		ZabcAux.setElement(1, 1, ZApropria);
		ZabcAux.setElement(2, 2, ZApropria);

		ZabcAux.setElement(0, 1, new Complex(0.0953, 0.8515));
		ZabcAux.setElement(1, 0, new Complex(0.0953, 0.8515));

		ZabcAux.setElement(0, 2, new Complex(0.0953, 0.7266));
		ZabcAux.setElement(2, 0, new Complex(0.0953, 0.7266));

		ZabcAux.setElement(1, 2, new Complex(0.0953, 0.7802));
		ZabcAux.setElement(2, 1, new Complex(0.0953, 0.7802));

		// converter pés em milhas: mi =ft * 0.00018939
		this.rede.addTrecho(3, 4, "ABC", 2500. * 0.00018939, ZabcAux);

		// simplificação sem trafo: conexão de baixa impedância entre barra 2 e
		// 3:
		ZabcAux = new ComplexMatrix(3, 3); // ohms / mile
		ZApropria = new Complex(0.00001, 0.00001);
		ZabcAux.setElement(0, 0, ZApropria);
		ZabcAux.setElement(1, 1, ZApropria);
		ZabcAux.setElement(2, 2, ZApropria);

		ZabcAux.setElement(0, 1, new Complex(0.00001, 0.00001));
		ZabcAux.setElement(1, 0, new Complex(0.00001, 0.00001));

		ZabcAux.setElement(0, 2, new Complex(0.00001, 0.00001));
		ZabcAux.setElement(2, 0, new Complex(0.00001, 0.00001));

		ZabcAux.setElement(1, 2, new Complex(0.00001, 0.00001));
		ZabcAux.setElement(2, 1, new Complex(0.00001, 0.00001));

		// converter pés em milhas: mi =ft * 0.00018939
		this.rede.addTrecho(2, 3, "ABC", 1. * 0.00018939, ZabcAux);
	}

	private void carregaFonte() {

		this.rede.setBarraFonte(1);

	}

}