package br.com.axxiom.ped435.test.functions.lf.rede;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.test.functions.lf.rede.elementos.Carga;
import br.com.axxiom.ped435.test.functions.lf.rede.elementos.Chave;
import br.com.axxiom.ped435.test.functions.lf.rede.elementos.Trecho;
import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;

public class Rede {
	private static Logger log = Logger.getLogger(Rede.class);
	Map<Integer, Barra> mapRede;
	ArrayList<Barra> listBarraRaiz;
	Map<Integer, ArrayList<Integer>> mapNivelBarra;
	Boolean isConstruida = false;
	private Barra barraFonte;

	public Rede() {

		this.mapRede = new HashMap<Integer, Barra>();
		this.listBarraRaiz = new ArrayList<Barra>();
		this.mapNivelBarra = new HashMap<Integer, ArrayList<Integer>>();
	}

	public void fluxoVarredura() {
		for (Barra barraRaiz : this.listBarraRaiz) {
			this.fluxoVarredura(barraRaiz.getID());
		}
	}

	public void fluxoVarredura(int idBarraRaiz) {
		double tolerancia = 1e-5;
		int qteIteracoesMax = 100;
		int iteracao = 0;
		Double erro = Double.MAX_VALUE;
		// Verifica se a rede ja foi construida.
		if (this.isConstruida == false)
			this.constroiRede();
		log.info(String.format("****** %s ***** ", "Varredura"));
		this.caminhaLargura(idBarraRaiz, true);
		while ((erro > tolerancia) && (iteracao <= qteIteracoesMax)) {
			this.atualizaCorrentes(idBarraRaiz);
			this.varreduraInversa(idBarraRaiz);
			this.varreduraDireta(idBarraRaiz);
			erro = this.getMaxMismatch(idBarraRaiz);
			log.info(String.format("##### Iteraçao %2d) %f #####", iteracao, erro));
			iteracao++;
		}
	}

	private void varreduraInversa(int idBarraRaiz) {
		log.debug("------ Varredura Inversa --------");
		ArrayList<Integer> listNivelBarra = new ArrayList<Integer>();
		// lista de Nivel de barras da barra com raiz idBarraRaiz
		listNivelBarra = this.mapNivelBarra.get(idBarraRaiz);
		int qteBarra = listNivelBarra.size() - 1;

		for (int i = 0; i <= qteBarra; i++) {
			int idBarraAux = listNivelBarra.get(qteBarra - i);
			Barra barraAux = this.mapRede.get(idBarraAux);
			// se não for a barra raiz da rede

			if (this.mapNivelBarra.containsKey(barraAux.getID()) == false) {
				List<SegmentoEletrico> listSegmentoEletricoAux = barraAux.getListSegmentoEletrico(false, true);

				if (listSegmentoEletricoAux.size() == 1) {
					// pega o primeiro/ínico segmento da lista
					SegmentoEletrico segmentoEletrico = listSegmentoEletricoAux.get(0);
					ComplexMatrix correnteSegmento = segmentoEletrico.getCorrente();
					barraAux = this.mapRede.get(segmentoEletrico.getBarraID());
					listSegmentoEletricoAux = barraAux.getListSegmentoEletrico(false, true);

					if (listSegmentoEletricoAux.size() == 1 && listSegmentoEletricoAux != null) {
						segmentoEletrico = listSegmentoEletricoAux.get(0);

						segmentoEletrico.addCorrente(correnteSegmento);
						this.updateBarraSegmentoEletrico(barraAux, segmentoEletrico);
					}

				} else {
					log.error(" Erro - Varredura Inversa: Há mais de um segmento alimentando a barra "
							+ barraAux.getID());
				}
			}
		}

	}

	private void varreduraDireta(int idBarraRaiz) {
		log.debug("------ Varredura Direta --------");
		for (Integer idBarra : this.mapNivelBarra.get(idBarraRaiz)) {
			Barra barraFonte = mapRede.get(idBarra);
			for (SegmentoEletrico segmentoEletrico : barraFonte.getListSegmentoEletrico(true, true)) {
				ComplexMatrix tensao = segmentoEletrico.calculaTensao(barraFonte.getTensaoCalculada());
				Barra barraCarga = mapRede.get(segmentoEletrico.getBarraID());
				barraCarga.setTensaoCalculada(tensao);
			}
		}
	}

	// Atualiza as correntes solicitadas pelas cargas em cada barra
	// e coloca esta corrente no segmento eletrico que alimenta essa barra
	// (segmento eletrico montante)
	private void atualizaCorrentes(int idBarraRaiz) {
		log.debug("Atualizacao das correntes das barras");

		for (Integer idBarra : this.mapNivelBarra.get(idBarraRaiz)) {
			Barra barra = this.mapRede.get(idBarra);

			if (this.mapNivelBarra.containsKey(barra.getID()) == false) {
				// Pega o segmento eletrico a montante
				List<SegmentoEletrico> listSegmentoEletricos = barra.getListSegmentoEletrico(false, true);
				if (listSegmentoEletricos.size() == 1) {
					SegmentoEletrico segmentoMontante = listSegmentoEletricos.get(0);

					// coloca a corrente total solicitadas pelas cargas no
					// segmento a montade
					segmentoMontante.setCorrente(barra.getCorrenteCalculadaCargas());
					// atualiza o segmento eletrico contrario
					this.updateBarraSegmentoEletrico(barra, segmentoMontante);
				} else {
					log.error(" Erro na atualização das barras. Há mais de um segmento - Barra: " + barra.getID()
							+ " Tamanho da lista " + listSegmentoEletricos.size());
					return;
				}
			}
		}
	}

	private double getMaxMismatch(int idBarraRaiz) {
		double maiorMismatch = Double.MIN_VALUE;
		for (Integer idBarra : this.mapNivelBarra.get(idBarraRaiz)) {
			Barra barra = this.mapRede.get(idBarra);
			double mismatchAtual = barra.getMismatch();
			if (mismatchAtual > maiorMismatch) {
				maiorMismatch = mismatchAtual;
			}
		}

		return maiorMismatch;
	}

	private void updateBarraSegmentoEletrico(Barra barra, SegmentoEletrico segmentoEletrico) {
		log.debug(" INICIO Update segmento eletrico ");
		log.debug(" >>>>> Barra / Seg:" + barra.getID() + "-" + segmentoEletrico.getBarraID() + " Estado: "
				+ segmentoEletrico.getStatus() + " Corrente: "
				+ matrixFlanaganToStringABS(segmentoEletrico.getCorrente()));
		SegmentoEletrico segmentoEletricoDirecaoOposta = new SegmentoEletrico(barra.getID(),
				!segmentoEletrico.getDirecao(), segmentoEletrico.getStatus(), segmentoEletrico.getCorrente());
		Barra barraAux = mapRede.get(segmentoEletrico.getBarraID());
		barraAux.updateSegmentoEletrico(segmentoEletricoDirecaoOposta);
		log.debug("do Segmento oposto -> Estado: " + segmentoEletrico.getStatus() + " Corrente   "
				+ matrixFlanaganToStringABS(segmentoEletricoDirecaoOposta.getCorrente()));
		log.debug(" FIM Update segmento eletrico ");
	}

	private List<Barra> caminhaLargura(int idBarraInicio, boolean direcao) {
		// Caminha em largura
		// Cria a lista de Niveis das barras
		ArrayList<Integer> listNivelBarraAux = new ArrayList<Integer>();
		log.debug(" Busca em Largura ");
		LinkedList<Integer> fila = new LinkedList<Integer>();
		boolean status = true; // pega somente os segmentos eletricos fechados
		List<SegmentoEletrico> listSegmentoEletricoAux = mapRede.get(idBarraInicio).getListSegmentoEletrico(direcao);
		List<Barra> listBarraCaminho = new ArrayList<Barra>();
		listBarraCaminho.add(mapRede.get(idBarraInicio));
		mapRede.get(idBarraInicio).setVerificado(true);
		listNivelBarraAux.add(idBarraInicio);
		// pega os segmentos eletricos ligados � barra com idInicio
		for (SegmentoEletrico segmentoEletrico : listSegmentoEletricoAux) {
			fila.add(segmentoEletrico.getBarraID());
		}
		while (fila.isEmpty() == false) {
			Integer barra_id = fila.poll();
			listNivelBarraAux.add(barra_id);
			mapRede.get(barra_id).setVerificado(true);
			listSegmentoEletricoAux = mapRede.get(barra_id).getListSegmentoEletrico(direcao, status);
			listBarraCaminho.add(mapRede.get(barra_id));
			// Adiciona os segmentosEletricos nas barras
			for (SegmentoEletrico segmentoEletrico : listSegmentoEletricoAux) {
				fila.add(segmentoEletrico.getBarraID());
			}
		}
		this.mapNivelBarra.put(idBarraInicio, listNivelBarraAux);
		log.debug("Lista de Nivel " + this.mapNivelBarra.get(idBarraInicio).toString());
		return listBarraCaminho;
	}

	public void toStringBarras() {
		log.info("****** Barras da rede ***** ");
		Iterator<Integer> iterator = mapRede.keySet().iterator();
		while (iterator.hasNext()) {
			Barra barraAux = mapRede.get(iterator.next());
			String print = barraAux.toString();
			log.info(print);
		}
	}

	public void toStringCorrente() {
		log.info("****** Trechos da rede ***** ");
		Iterator<Integer> iterator = mapRede.keySet().iterator();
		while (iterator.hasNext()) {
			Barra barraAux = mapRede.get(iterator.next());
			ArrayList<SegmentoEletrico> list = barraAux.getListSegmentoEletrico();
			for (SegmentoEletrico segmentoEletrico : list) {
				if (segmentoEletrico.direcao) {
					log.info(String.format("Barra de/para: %4d -> %4d: %s", barraAux.getID(),
							segmentoEletrico.getBarraID(), toStringCorrente(segmentoEletrico)));
				}
			}
		}
	}

	private String toStringCorrente(SegmentoEletrico segmentoEletrico) {
		// FIXME verificar o fator Newton abaixo...
		return matrixFlanaganToStringABS(segmentoEletrico.getCorrente());
	}

	public void toStringTensao() {
		Iterator<Integer> iterator = mapRede.keySet().iterator();
		while (iterator.hasNext()) {
			Barra barraAux = mapRede.get(iterator.next());
			String print = toStringTensao(barraAux);
			log.info(print);
		}
	}

	private String toStringTensao(Barra barraAux) {
		// multiplicar por raiz de 3 para a visualização...
		String tensaoByPhases = matrixFlanaganToStringABS(barraAux.getTensaoCalculada().times(Math.sqrt(3)));
		String print = String.format("%4d, %b. %s", barraAux.getID(), barraAux.isVerificado(), tensaoByPhases);
		return print;
	}

	@Deprecated
	public void toStringCorrenteCargas() {
		Iterator<Integer> iterator = mapRede.keySet().iterator();
		while (iterator.hasNext()) {
			Barra barraAux = mapRede.get(iterator.next());
			log.info(barraAux + "Corrente na Carga:");
			log.info("implementar");
		}
	}

	public static String matrixFlanaganToString(ComplexMatrix complexMatrix) {
		StringBuilder toString = new StringBuilder();
		Complex[][] array = complexMatrix.getArrayPointer();
		for (int i = 0; i < complexMatrix.getNrow(); i++) {
			for (int j = 0; j < complexMatrix.getNcol(); j++) {
				log.debug(String.format("%+f %+fj", array[i][j].getReal(), array[i][j].getImag()));
			}
		}
		return toString.toString();
	}

	// TODO É NECESSÁRIO CRIAR COMPATIBILIDADE ...
	public static String matrixFlanaganToStringABS(ComplexMatrix complexMatrix) {
		StringBuilder tensaoByPhases = new StringBuilder();
		for (int i = 0; i < complexMatrix.getNrow(); i++) {
			for (int j = 0; j < complexMatrix.getNcol(); j++) {
				tensaoByPhases = tensaoByPhases
						.append(String.format("%.3f ", complexMatrix.getElementCopy(i, j).abs()));
				// argDeg %+.0f, %+.0f %+.0f
			}

		}
		return tensaoByPhases.toString();
	}

	private void montaRedeSegmentoOposto(Barra barra, SegmentoEletrico segmentoEletrico) {
		log.debug("	Segmento Oposto --------------");
		if (segmentoEletrico instanceof Chave) {
			log.debug("	Chave ");
			Barra barraChave = this.mapRede.get(segmentoEletrico.getBarraID());
			Chave chaveDirecaoOposta = new Chave(barra.getID(), segmentoEletrico.getStatus(),
					!segmentoEletrico.getDirecao());
			barraChave.addSegmentoEletrico(chaveDirecaoOposta);
			
			// TODO: este trecho, ao ser descomentado, acaba com a
			// convergência do algoritmo por varredura!** WHY????
			// **} else if (segmentoEletrico instanceof Trecho) {
			
			log.debug("	Trecho ");
			log.debug("		Barra: " + barra.getID() + " para " + segmentoEletrico.getBarraID());

			Barra barraTrecho = this.mapRede.get(segmentoEletrico.getBarraID());
			try {
				Trecho trecho = (Trecho) segmentoEletrico;
				Trecho trechoDirecaoOposta = new Trecho(trecho);
				trecho.BarraID = barraTrecho.getID();
				trecho.status = segmentoEletrico.getStatus();
				trechoDirecaoOposta.direcao = !trecho.direcao;
				barraTrecho.addSegmentoEletrico(trechoDirecaoOposta);
			} catch (ClassCastException e) {
				// TODO parte de instabilidade: tratamento inserido por
				// LuizLeRoy lhipolito
				e.printStackTrace();
			}
		} else {
			log.debug("	segmentoEletrico ");
			log.debug("		Barra: " + barra.getID() + " para " + segmentoEletrico.getBarraID());
			Barra barraSegmento = this.mapRede.get(segmentoEletrico.getBarraID());
			SegmentoEletrico segmentoEletricoDirecaoOposta = new SegmentoEletrico(barra.getID(),
					!segmentoEletrico.getDirecao(), segmentoEletrico.getStatus());
			barraSegmento.addSegmentoEletrico(segmentoEletricoDirecaoOposta);
		}

	}

	// Adiciona barra com coordenadas zeradas
	public void addBarra(Integer idBarra, double tensaoNominal) {
		// verfica se a barra j� existe
		if (this.mapRede.containsKey(idBarra)) {
			log.warn(String.format("Barra %d já existente. Não adicionada!", idBarra));
			return;
		}
		// Adiciona a barra com as coordenadas zeradas
		this.addBarra(idBarra, tensaoNominal, 0.0, 0.0);
	}

	public void addBarra(Integer idBarra, double tensaoNominal, Double coordX, Double coordY) {
		// verfica se a barra já existe
		if (this.mapRede.containsKey(idBarra)) {
			log.warn(String.format("Barra %d já existente. Não adicionada!", idBarra));
			return;
		}
		// Cria a barra | Coloca a tensão nominal | Coloca a barra do Tipo PQ =
		// 0
		Barra barra = new Barra(idBarra);
		barra.setTensaoNominal(tensaoNominal);
		barra.setTipoBarra(0);
		// Adiciona a barra no hash
		this.mapRede.put(barra.getID(), barra);
		if (barra.getTipoBarra() == 3)
			this.listBarraRaiz.add(barra);
	}

	public Barra getBarra(Integer idBarra) throws RuntimeException {
		return this.mapRede.get(idBarra);
	}

	public void setBarraFonte(Integer idBarra) {
		// verifica se a Barra existe
		if (this.mapRede.containsKey(idBarra)) {
			this.listBarraRaiz.add(this.mapRede.get(idBarra));
			this.mapRede.get(idBarra).setTipoBarra(3);
			this.barraFonte = this.mapRede.get(idBarra);
		} else {
			log.error(" ERRO: Não existe a barra no map de barras. Não é possível setar como barra fonte. ");
			throw new RuntimeException();
		}
	}

	public Barra getBarraFonte() {
		return this.barraFonte;
	}

	public void addTrecho(Integer idBarraFonte, Integer idBarraCarga, String fases, Double comprimento,
			ComplexMatrix Zabc) {

		// verifica se a barra fonte existe
		if (this.mapRede.containsKey(idBarraFonte) == false) {
			log.error("ERRO: Impossivel adicionar trecho. Barra fonte não existe");
			return;
		}

		// verifica se a barra carga existe
		if (this.mapRede.containsKey(idBarraCarga) == false) {
			log.error("ERRO: Impossivel adicionar trecho. Barra carga não existe");
			return;
		}

		Barra barraFonte = this.mapRede.get(idBarraFonte);
		Trecho trecho = new Trecho(idBarraCarga, fases, comprimento, Zabc);
		barraFonte.addSegmentoEletrico(trecho);
	}

	public void addTrecho(Integer idBarraFonte, Integer idBarraCarga, String fases, Double comprimento, Double r1,
			Double x1, Double r0, Double x0) {

		// verifica se a barra fonte existe
		if (this.mapRede.containsKey(idBarraFonte) == false) {
			log.info("ERRO: Impossivel adicionar trecho. Barra fonte n�o existe");
			return;
		}
		// verifica se a barra carga existe
		if (this.mapRede.containsKey(idBarraCarga) == false) {
			log.info("ERRO: Impossivel adicionar trecho. Barra carga n�o existe");
			return;
		}
		Barra barraFonte = this.mapRede.get(idBarraFonte);
		Trecho trecho = new Trecho(idBarraCarga, fases, comprimento, r1, x1, r0, x0);
		barraFonte.addSegmentoEletrico(trecho);
	}

	public void addCargaBarra(Integer idBarra, double expoente, Complex potenciaNom_FsA, Complex potenciaNom_FsB,
			Complex potenciaNom_FsC) {

		if (this.mapRede.containsKey(idBarra) == false) {
			log.info(" ERRO: A carga est� associada � uma barra inexistente: " + idBarra
					+ "  .Impossivel adicionar carga");
			return;
		}

		Barra barra = this.mapRede.get(idBarra);

		ComplexMatrix potencias = new ComplexMatrix(3, 1);

		potencias.setElement(0, 0, potenciaNom_FsA);
		potencias.setElement(1, 0, potenciaNom_FsB);
		potencias.setElement(2, 0, potenciaNom_FsC);

		Carga carga = new Carga(potencias, barra.getTensaoNominal(), expoente);

		barra.addCarga(carga);

	}

	private HashMap<Integer, Integer> getListChaves() {

		log.info(" ---- Lista de Chaves ");

		List<SegmentoEletrico> listChaveAux = new ArrayList<SegmentoEletrico>();

		HashMap<Integer, Integer> mapChave = new HashMap<Integer, Integer>();

		Set<Integer> setKey = mapRede.keySet();

		for (Integer barraFonteID : setKey) {

			Barra barra = mapRede.get(barraFonteID);

			listChaveAux = barra.getListChaves();

			for (SegmentoEletrico seg : listChaveAux) {
				log.info("Chave de: " + barra.getID() + " para: " + seg.getBarraID() + " estado: " + seg.getStatus());
				mapChave.put(barra.getID(), seg.getBarraID());
			}
		}
		return mapChave;
	}

	public void constroiRede() {
		Iterator<Integer> iterator = mapRede.keySet().iterator();
		log.info("****** Montando a rede... ***** ");
		while (iterator.hasNext()) {
			Barra barraAux = mapRede.get(iterator.next());

			log.debug("Barra : " + barraAux.getID());
			log.debug("        Antes: Barra " + barraAux.getID() + " Segmentos: " + barraAux.getListSegmentoEletrico());

			for (SegmentoEletrico segmentoEletrico : barraAux.getListSegmentoEletrico(true)) {
				this.montaRedeSegmentoOposto(barraAux, segmentoEletrico);
				// log.warn("Verificar necessidade e deletar!!!");
			}
			log.debug("        Depois: Barra " + barraAux.getID() + " Segmentos: " + barraAux.getListSegmentoEletrico());
		}
		this.isConstruida = true;
		log.debug("Rede " + mapRede.toString());
		log.info("It was built? A.: " + this.isConstruida);
	}
}

//private List<Barra> caminha_Profundidade(int idBarraInicio, boolean
	// direcao) {
	// // log.info(" Busca em profundidade ");
	// Stack<Integer> pilha = new Stack<Integer>();
	// boolean status = true; // pega somente os segmentos eletricos fechados
	// List<SegmentoEletrico> listSegmentoEletricoAux = mapRede.get(
	// idBarraInicio).getListSegmentoEletrico(direcao);
	// List<Barra> listBarraCaminho = new ArrayList<Barra>();
	// listBarraCaminho.add(mapRede.get(idBarraInicio));
	// mapRede.get(idBarraInicio).setVerificado(true);
	// // pega os segmentos eletricos ligados � barra com idInicio
	// for (SegmentoEletrico segmentoEletrico : listSegmentoEletricoAux)
	// pilha.add(segmentoEletrico.getBarraID());
	// while (pilha.isEmpty() == false) {
	// Integer barra_id = pilha.pop();
	// mapRede.get(barra_id).setVerificado(true);
	// listSegmentoEletricoAux = mapRede.get(barra_id)
	// .getListSegmentoEletrico(direcao, status);
	// listBarraCaminho.add(mapRede.get(barra_id));
	// for (SegmentoEletrico segmentoEletrico : listSegmentoEletricoAux)
	// pilha.add(segmentoEletrico.getBarraID());
	// }
	// return listBarraCaminho;
	// }