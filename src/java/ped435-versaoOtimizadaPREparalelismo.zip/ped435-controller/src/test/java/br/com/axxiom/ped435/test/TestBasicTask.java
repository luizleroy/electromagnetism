/**
 * 
 */
package br.com.axxiom.ped435.test;

import java.util.List;

import org.apache.commons.math.linear.Array2DRowRealMatrix;
import org.apache.commons.math.linear.MatrixVisitorException;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealMatrixPreservingVisitor;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;
import org.junit.Test;

import br.com.axxiom.ped435.model.dao.service.TValidGrupo13FCService;
import br.com.axxiom.ped435.model.dao.service.TValidGrupo13Service;
import br.com.axxiom.ped435.model.dao.service.TValidSimplefitService;
import br.com.axxiom.ped435.model.dao.service.TclienteService;
import br.com.axxiom.ped435.model.dao.service.TmedidorService;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidGrupo13;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidGrupo13FC;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidSimplefit;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tcliente;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.Tmedidor;
import br.com.axxiom.ped435.model.util.Matrix;
import br.com.axxiom.ped435.test.functions.lf.plugin.DISS;
import br.com.axxiom.ped435.test.functions.lf.rede.Rede;
import br.com.axxiom.ped435.util.Const;

/**
 * @author lhipolito / Luiz Le Roy
 * 
 */
public class TestBasicTask {
	private static Logger log = Logger.getLogger(TestBasicTask.class);

	public static void main(String args[]) {
		Const.setLog();
//		// As funções abaixo são testadas sem uso do Maven por fazer acesso a banco de dados
		getNumInstalacao();
		tValidGrupo13FCTest();
		tValidSimplefitTest();
		tValidGrupo13Test();
		TestBasicTask classeTeste = new TestBasicTask();
		classeTeste.manipulaMatrixTest();
		classeTeste.testValidaPluginDISS();
	}

	private static void getNumInstalacao() {
		TclienteService service = new TclienteService();
		SqlSessionFactory factory = service.getSqlSessionFactory();
		SqlSession sqlSession = factory.openSession();
		Tcliente cliente = service.selectByPrimaryKey(1, sqlSession);
		log.info("Num. Instalacao: " + cliente.getNumInstalacao());

		TmedidorService medService = new TmedidorService();
		Tmedidor medidor = medService.selectByPrimaryKey("1", sqlSession);
		log.info(medidor.getTipProprietario());
		sqlSession.close();

	}

	private static void tValidGrupo13Test() {
		log.info("analise o tempo de execução do carregamento no banco!");
		TValidGrupo13Service tValid = new TValidGrupo13Service();
		List<TValidGrupo13> list = tValid.select();
		log.info("End tValidGrupo13FCTest() Leitura dos dados");
		for (int i = 0; i < list.size() - 1; i++) {
			log.debug("getIdentificadorCliente() = "
					+ list.get(i).getIdentificadorCliente());
			log.debug("getDiaMedicao() = " + list.get(i).getDiaMedicao());
			log.debug("getDemandaMedia() = " + list.get(i).getDemandaMedia());
			log.debug("getDemandaMaxima() = " + list.get(i).getDemandaMaxima());
			log.debug("getPotInstalada() = " + list.get(i).getPotInstalada());
			log.debug("getFatorDeCarga() = " + list.get(i).getFatorDeCarga());
			log.debug("getFatorDeCarga() = " + list.get(i).getFatorDeDemanda());
		}
		int i = list.size() - 1;
		log.info("getIdentificadorCliente() = "
				+ list.get(i).getIdentificadorCliente());
		log.info("getDiaMedicao() = " + list.get(i).getDiaMedicao());
		log.info("getDemandaMedia() = " + list.get(i).getDemandaMedia());
		log.info("getDemandaMaxima() = " + list.get(i).getDemandaMaxima());
		log.info("getPotInstalada() = " + list.get(i).getPotInstalada());
		log.info("getFatorDeCarga() = " + list.get(i).getFatorDeCarga());
		log.info("getFatorDeCarga() = " + list.get(i).getFatorDeDemanda());
		
		log.info("End tValidGrupo13Test() (para analisar I.O.)");
	}

	private static void tValidGrupo13FCTest() {
		log.info("analise o tempo de execução do carregamento no banco!");
		TValidGrupo13FCService tValid = new TValidGrupo13FCService();
		List<TValidGrupo13FC> list = tValid.select();
		log.info("End tValidGrupo13FCTest() Leitura dos dados");
		for (int i = 0; i < list.size(); i++) {
			log.debug("getIdentificadorCliente() = "
					+ list.get(i).getIdentificadorCliente());
			log.debug("getDiaMedicao() = " + list.get(i).getDiaMedicao());
			log.debug("getDemandaMedia() = " + list.get(i).getDemandaMedia());
			log.debug("getDemandaMaxima() = " + list.get(i).getDemandaMaxima());
			log.debug("getPotInstalada() = " + list.get(i).getPotInstalada());
			log.debug("getFatorDeCarga() = " + list.get(i).getFatorDeCarga());
		}
		log.info("End tValidGrupo13FCTest() (para analisar I.O.)");
	}

	private static void tValidSimplefitTest() {
		log.debug("analise o tempo de execução do carregamento no banco!");
		TValidSimplefitService tValidSimplefitService = new TValidSimplefitService();
		List<TValidSimplefit> list = tValidSimplefitService.select();
		log.debug("End Leitura dos dados");
		for (int i = 0; i < list.size(); i++) {
			log.debug("getInput() = " + list.get(i).getInput());
			log.debug("getOutput() = " + list.get(i).getOutput());
		}
		log.debug("End tValidSimplefitTest() (para analisar I.O.)");
	}

	@Test
	public void manipulaMatrixTest() {
		Const.setLog();
		// x =
		//
		// 1.4000
		// 1.7000
		// 4.8000
		// 7.3000
		// 6.9000
		// 0.4000
		double[][] xData = { { 1.4 }, { 1.7 }, { 4.8 }, { 7.3 }, { 6.9 },
				{ 0.4 } };
		log.debug("Classe de testes de manipulação de matrizes (propósito geral)");
		log.debug("Input (exponenciação da RNA):");
		Matrix x = new Matrix(xData);
		log.debug(x);
		f(x);
		log.debug("Metodologia para percorrer matrizes:");
		double[][] data = { { 1d, 2d, 3d }, { 4d, 6d, 8d } };
		log.debug("Input (dados no formato 2x3 e 3x2):");
		RealMatrix x23 = new Array2DRowRealMatrix(data, false);
		log.debug(x23);
		// apenas um exemplo para caminhar em matrizes: utlizar dentro do ambiente de matriz do projeto!
		testVisitor(x23);
	}

	private void testVisitor(RealMatrix x23) {
		RealMatrixPreservingVisitor visitor = new RealMatrixPreservingVisitor() {

			@Override
			public void visit(int row, int column, double value)
					throws MatrixVisitorException {
				log.debug(value);
			}

			@Override
			public void start(int rows, int columns, int startRow, int endRow,
					int startColumn, int endColumn) {
			}

			@Override
			public double end() {
				return 0;
			}
		};
		log.debug("Caminhando por colunas...");
		log.debug(visitor);
		log.debug("Caminhando por linhas...");
		x23.walkInOptimizedOrder(visitor);
	}

	private void f(Matrix x) {
		// function [ y ] = f( x )
		// w = ...
		// wb = ...
		// y=x;
		// for m=1:2 % tamanho da rede neural
		// y=w{m}'*y+wb{m}';
		// y=1./(exp(-y)+1);
		// end
		// end

		// w{1} = ...
		// [1.4091444212109794 0.84395330719713546 -0.28216428084305223;
		// -0.66770911344833983 0.30500536768988845 1.0359765741600739;
		// 0.12416332286170202 -0.020794606179823691 -0.22044960324092677;
		// -1.5052338208309244 0.07839256062603818 -0.20927800272471209;
		// 0.090106407025410645 -0.24270094897270694 -0.073654409946084812;
		// -0.36409178658957275 0.2141084106743171 1.4134116102142253];
		double[][] dataW1 = {
				{ 1.4091444212109794, 0.84395330719713546, -0.28216428084305223 },
				{ -0.66770911344833983, 0.30500536768988845, 1.0359765741600739 },
				{ 0.12416332286170202, -0.020794606179823691,
						-0.22044960324092677 },
				{ -1.5052338208309244, 0.07839256062603818,
						-0.20927800272471209 },
				{ 0.090106407025410645, -0.24270094897270694,
						-0.073654409946084812 },
				{ -0.36409178658957275, 0.2141084106743171, 1.4134116102142253 } };
		Matrix w1 = new Matrix(dataW1);
		// w{2} = [0.26167218067835235; -0.31285990640802008;
		// 2.3834205607328638];
		double[][] dataW2 = { { 0.26167218067835235 },
				{ -0.31285990640802008 }, { 2.3834205607328638 } };
		Matrix w2 = new Matrix(dataW2);
		// wb{1} = [0.42804185968026431 1.3838358090744787 0.17493775984673404];
		double[][] dataWb1 = { { 0.42804185968026431, 1.3838358090744787,
				0.17493775984673404 } };
		Matrix wb1 = new Matrix(dataWb1);
		// wb{2} = -1.5321194114583445;
		double[][] dataWb2 = { { -1.5321194114583445 } };
		Matrix wb2 = new Matrix(dataWb2);

		// avaliando entrada genérica x...
		Matrix y;
		// for (int m = 0; m < 2; m++) {
		y = x.preMultiply(w1.transpose()).add(wb1.transpose());
		y.expPlus1Inv();
		y = y.preMultiply(w2.transpose()).add(wb2.transpose());
		y.expPlus1Inv();
		// }
		log.debug("Output:");
		log.debug(y);
		assert ("1x1 Impl{{0.2387111390339273}}".equals(y.toString())) : "Não está correto em relação a simulação do matlab";
	}
	
	@Test
	public void testValidaPluginDISS() {
		DISS diss = new DISS();
//		Rede rede = diss.carregaRede("src/test/resources/IEEE_13barras.3dis");
		Rede rede = diss.carregaRede("src/test/resources/IEEE_13barras.3dis");
		rede.constroiRede();
//		log.info(String.format("****** %s ***** ","Antes da Varredura"));
		rede.toStringBarras();
//		log.info(String.format("****** %s ***** ","Depois da Varredura"));
		rede.fluxoVarredura();
		rede.toStringTensao();
		rede.toStringCorrente();
		assert(rede != null);
	}
}
