package br.com.axxiom.ped435.test.functions.lf.plugin;

import br.com.axxiom.ped435.test.functions.lf.rede.Rede;
import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;

public class RedePequenaTesteNewton {

	private Rede rede;

	public RedePequenaTesteNewton() {

		this.rede = new Rede();

	}

	public Rede carregaRede() {

		this.carregaBarras();

		this.carregaFonte();

		this.carregaTrechos();

		this.carregaCargas();

		return rede;

	}

	private void carregaBarras() {

		double tensaoNominal = 13800.;

		this.rede.addBarra(1, tensaoNominal);
		this.rede.addBarra(2, tensaoNominal);
		this.rede.addBarra(3, tensaoNominal);
		this.rede.addBarra(4, tensaoNominal);
	}

	public void carregaCargas() {
		Complex cargaFase = new Complex(0.1, 0.2);
		cargaFase = cargaFase.times(5000);
		rede.addCargaBarra(2, 0, cargaFase, cargaFase, cargaFase);
		rede.addCargaBarra(3, 0, cargaFase, cargaFase, cargaFase);
		rede.addCargaBarra(4, 0, cargaFase, cargaFase, cargaFase);
	}

	private void carregaTrechos() {
		ComplexMatrix ZabcAux = new ComplexMatrix(3, 3);
		double ff = 100.;
		Complex ZApropria = new Complex(0.0054, 0.0156);
		Complex ZAmutua = new Complex(0, 0.0049);

		ZabcAux.setElement(0, 0, ZApropria);
		ZabcAux.setElement(1, 1, ZApropria);
		ZabcAux.setElement(2, 2, ZApropria);

		ZabcAux.setElement(0, 1, ZAmutua);
		ZabcAux.setElement(0, 2, ZAmutua);
		ZabcAux.setElement(1, 0, ZAmutua);

		ZabcAux.setElement(1, 2, ZAmutua);
		ZabcAux.setElement(2, 0, ZAmutua);
		ZabcAux.setElement(2, 1, ZAmutua);
		this.rede.addTrecho(1, 2, "ABC", 1.0, ZabcAux.times(ff));

		ZabcAux = new ComplexMatrix(3, 3);

		ZApropria = new Complex(0.0172, 0.0168);
		ZAmutua = new Complex(0, 0.0049);

		ZabcAux.setElement(0, 0, ZApropria);
		ZabcAux.setElement(1, 1, ZApropria);
		ZabcAux.setElement(2, 2, ZApropria);

		ZabcAux.setElement(0, 1, ZAmutua);
		ZabcAux.setElement(0, 2, ZAmutua);
		ZabcAux.setElement(1, 0, ZAmutua);

		ZabcAux.setElement(1, 2, ZAmutua);
		ZabcAux.setElement(2, 0, ZAmutua);
		ZabcAux.setElement(2, 1, ZAmutua);
		this.rede.addTrecho(2, 3, "ABC", 1.0, ZabcAux.times(ff));

		ZabcAux = new ComplexMatrix(3, 3);

		ZApropria = new Complex(0.0172, 0.0168);
		ZAmutua = new Complex(0, 0.0049);

		ZabcAux.setElement(0, 0, ZApropria);
		ZabcAux.setElement(1, 1, ZApropria);
		ZabcAux.setElement(2, 2, ZApropria);

		ZabcAux.setElement(0, 1, ZAmutua);
		ZabcAux.setElement(0, 2, ZAmutua);
		ZabcAux.setElement(1, 0, ZAmutua);

		ZabcAux.setElement(1, 2, ZAmutua);
		ZabcAux.setElement(2, 0, ZAmutua);
		ZabcAux.setElement(2, 1, ZAmutua);
		this.rede.addTrecho(2, 4, "ABC", 1.0, ZabcAux.times(ff));
	}

	private void carregaFonte() {
		this.rede.setBarraFonte(1);
	}
}