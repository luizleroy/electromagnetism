package br.com.axxiom.ped435.test.functions.lf.rede.elementos;

import br.com.axxiom.ped435.test.functions.lf.rede.SegmentoEletrico;
import flanagan.complex.ComplexMatrix;


public class Chave extends SegmentoEletrico{

	boolean statusOriginal;
	
	public Chave(int Barra_ID, boolean status){

		this.BarraID = Barra_ID;
		this.direcao = true;
		this.status = status;
		this.corrente= new ComplexMatrix(3,1);
		this.zeraCorrente();
		
		this.statusOriginal=status;
		
	}
	
	public Chave(int Barra_ID, boolean status, boolean direcao){

		this.BarraID = Barra_ID;
		this.direcao = direcao;
		this.status = status;
		this.corrente= new ComplexMatrix(3,1);
		this.zeraCorrente();
		
		this.statusOriginal=status;
		
	}

	
	public Chave(String codigo, int Barra_ID, boolean status){
		
		this.codigo=codigo;
		this.BarraID = Barra_ID;
		this.direcao = true;
		this.status = status;
		this.corrente= new ComplexMatrix(3,1);
		this.zeraCorrente();
		
		this.statusOriginal=status;
		
	}
	
	public Chave(Chave chaveCopy){
		
		this.codigo=chaveCopy.codigo;
		this.BarraID = chaveCopy.BarraID;
		this.direcao = chaveCopy.direcao;
		this.status = chaveCopy.status;
		this.corrente= chaveCopy.corrente.copy();
		this.statusOriginal=chaveCopy.status;
		
	}
	
	public boolean getStatusOriginal(){
		return this.statusOriginal;
	}
	
}
