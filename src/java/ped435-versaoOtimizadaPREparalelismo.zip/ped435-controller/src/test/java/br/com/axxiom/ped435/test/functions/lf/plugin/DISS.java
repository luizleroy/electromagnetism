package br.com.axxiom.ped435.test.functions.lf.plugin;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;

import br.com.axxiom.ped435.test.functions.lf.rede.Rede;

public class DISS implements Plugin {
	private static final String SEPARATOR = ",";
	String file;
	private static Logger log = Logger.getLogger(DISS.class);

	// TODO: a ordem deve ser igual ao arquivo nome do arquivo no campo acima!
	public enum Sec {
		Bus(4), Line(5), Load(5);
		public int value;

		Sec(int valor) {
			value = valor;
		}
	}

	private Rede redeDISS = new Rede();

	@Override
	public Rede carregaRede(String nomeArquivo) {
		log.info(String.format("****** %s ***** ", "Lendo a rede"));
		file = nomeArquivo;
		Map<String, List<String>> map = loadFileToMapFeeder(file);
		log.debug(map.get("Line"));

		// Carrega as barras
		this.createBuses(map.get("Bus"));

		this.loadTrechos(map.get("Line"));

		// Carrega as cargas
		this.loadCargas(map.get("Load"));
		return redeDISS;
	}

	private void loadCargas(List<String> listLoads) {
		double ar, ai, br, bi, cr, ci, expoenteAlpha;
		int nnn;
		for (String linhaLoad : listLoads) {
			String[] splitLine = linhaLoad.split(SEPARATOR);
			nnn = Integer.parseInt(splitLine[1].trim());// 671;
			log.info(String
					.format("Tipo da Carga Estrela-aterrado (Yg): %15s. Tensão: %s. ->%s<-", splitLine[0].trim(),
							splitLine[2].trim(), splitLine[3]));
			expoenteAlpha = Double.parseDouble(splitLine[4].trim());
			ar = Double.parseDouble(splitLine[5].trim());
			br = Double.parseDouble(splitLine[6].trim());
			cr = Double.parseDouble(splitLine[7].trim());
			ai = Double.parseDouble(splitLine[8].trim());
			bi = Double.parseDouble(splitLine[9].trim());
			ci = Double.parseDouble(splitLine[10].trim());
			this.redeDISS.addCargaBarra(nnn, expoenteAlpha, new Complex(ar, ai),
					new Complex(br, bi), new Complex(cr, ci));
		}
	}

	private void loadTrechos(List<String> listTrechos) {
		for (String linhaTrecho : listTrechos) {
			String[] splitLine = linhaTrecho.split(SEPARATOR);
			int bf, bc;
			double km, pri, seg, ter, qua, qui, sex, set, oit, non, dec, dec1, dec2;
			// trecho 10: configuração SEISSENTOS_E_SETE
			bf = Integer.valueOf(splitLine[1].trim()); // 684;
			bc = Integer.valueOf(splitLine[2].trim()); // 652;
			km = Double.valueOf(splitLine[3].trim()); // 0.24384;
			int impedanciaLinha = Integer.valueOf(splitLine[4].trim()); // 0
			log.trace("Impedância da linha sempre em Ohms (Ω) e Siemens (S) => 0");
			pri = Double.valueOf(splitLine[5].trim()); // 0.834191;
			seg = Double.valueOf(splitLine[6].trim()); // 0.000000;
			ter = Double.valueOf(splitLine[7].trim()); // 0.000000;
			qua = Double.valueOf(splitLine[8].trim()); // 0.000000;
			qui = Double.valueOf(splitLine[9].trim()); // 0.000000;
			sex = Double.valueOf(splitLine[10].trim()); // 0.000000;
			set = Double.valueOf(splitLine[11].trim()); // 0.318391;
			oit = Double.valueOf(splitLine[12].trim()); // 0.00000000;
			non = Double.valueOf(splitLine[13].trim()); // 0.00000000;
			dec = Double.valueOf(splitLine[14].trim()); // 0.00000000;
			dec1 = Double.valueOf(splitLine[15].trim()); // 0.00000000;
			dec2 = Double.valueOf(splitLine[16].trim()); // 0.00000000;//
															// 0.0,0.0,0.0,0.0,0.0,0.0,
															// 55.296568e-6,
			// 0.000000e-6,
			// 0.000000e-6, 0.000000e-6, 0.000000e-6,
			// 0.000000e-6
			this.addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit,
					non, dec, dec1, dec2);
		}
	}

	private void addTrecho(int bf, int bc, double km, double pri, double seg,
			double ter, double qua, double qui, double sex, double set,
			double oit, double non, double dec, double dec1, double dec2) {
		ComplexMatrix config = new ComplexMatrix(3, 3);
		// R(1=0,7=0), R(2=0,8=1), R(3=0,9=2), R(4=1,10=1), R(5=1,11=2),
		// R(6=2,12=2)
		config.setElement(0, 0, new Complex(pri, set)); // *
		config.setElement(0, 1, new Complex(seg, oit));
		config.setElement(0, 2, new Complex(ter, non));
		config.setElement(1, 1, new Complex(qua, dec)); // *
		config.setElement(1, 2, new Complex(qui, dec1));
		config.setElement(2, 2, new Complex(sex, dec2)); // *
		config.setElement(1, 0, new Complex(seg, oit));
		config.setElement(2, 0, new Complex(ter, non));
		config.setElement(2, 1, new Complex(qui, dec1));
		redeDISS.addTrecho(bf, bc, "ABC", km, config);
	}

	// TODO -> chamar o M. para resolver este pepino!!!
	private void createBuses(List<String> listNodes) {
		for (String linhaNode : listNodes) {
			String[] splitLine = linhaNode.split(SEPARATOR);
			Integer idBarra = Integer.valueOf(splitLine[1].trim());
			Double nominalVoltage = Double.valueOf(splitLine[2].trim());
			nominalVoltage = nominalVoltage/Math.sqrt(3);
			redeDISS.addBarra(idBarra, nominalVoltage);
			if ("3".equals(splitLine[3].trim())) {
				redeDISS.setBarraFonte(idBarra);
			}
			log.debug(redeDISS.getBarra(idBarra));
		}
		// TODO tratar não existência de barra fonte
		log.info(redeDISS.getBarraFonte().toString()
				.replaceAll("Barra número", "Barra fonte"));
	}

	private Map<String, List<String>> loadFileToMapFeeder(String nomeArquivo) {
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		try {
			BufferedReader br = new BufferedReader(new FileReader(nomeArquivo));
			Sec sec;
			while (br.ready()) {
				String linha = br.readLine();
				if (linha.trim().equals("")) {
					continue;
				}
				switch (linha.split(SEPARATOR)[0]) {
				case "Bus":
					sec = Sec.Bus;
					createSec(map, br, sec, linha);
					break;
				case "Line":
					sec = Sec.Line;
					createSec(map, br, sec, linha);
					break;
				case "Load":
					sec = Sec.Load;
					createSec(map, br, sec, linha);
					break;
				}
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		return map; // TODO pode ser vazio?
	}

	/**
	 * @param map
	 * @param br
	 * @param sec
	 * @param linha
	 */
	private void createSec(Map<String, List<String>> map, BufferedReader br,
			Sec sec, String linha) {
		Integer sizeSec;
		ArrayList<String> listLine;
		sizeSec = Integer.valueOf(linha.substring(sec.value).trim());
		listLine = new ArrayList<String>(sizeSec);
		createSec(br, listLine, sizeSec);
		map.put(sec.name(), listLine);
	}

	private void createSec(BufferedReader br, List<String> listLine, int secLine) {
		try {
			for (int i = 0; i < secLine; i++) {
				listLine.add(br.readLine());
			}
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
}
