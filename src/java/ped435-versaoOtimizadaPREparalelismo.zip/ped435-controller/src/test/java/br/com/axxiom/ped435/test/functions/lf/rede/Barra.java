package br.com.axxiom.ped435.test.functions.lf.rede;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.test.functions.lf.rede.elementos.Carga;
import br.com.axxiom.ped435.test.functions.lf.rede.elementos.Chave;
import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;


public class Barra {
	private static Logger log = Logger.getLogger(Barra.class);
	private int ID;
	private boolean verificado;
	private ArrayList<SegmentoEletrico> listSegmentoEletrico;
	private Double coordX;
	private Double coordY;
	
	private int tipoBarra; // PQ = 0; PV = 2; VO = 3
	private double tensaoNominal;
	private ComplexMatrix tensaoCalculada;
	
	private double mismatchMaior; 

	private List<Carga> listCargas;

	public Barra(){

		this.ID=-1;
		this.inicializaVariaveis();
		this.listCargas= new ArrayList<Carga>();
	}
	
	public Barra(int ID){

		this.ID=ID;
		this.inicializaVariaveis();
		this.listCargas= new ArrayList<Carga>();
	}
	
	public Barra(int ID,List<Carga> listCargas){

		this.ID=ID;
		this.inicializaVariaveis();
		this.listCargas= listCargas;
	}
	
	private void inicializaVariaveis(){
		
		this.verificado=false;
		this.listSegmentoEletrico = new ArrayList<SegmentoEletrico>();
		//this.tensaoCalculada = new Complex[3];
		this.mismatchMaior=Double.MIN_VALUE;
		this.tensaoCalculada = new ComplexMatrix(3,1);

		//this.correnteCalculadaCargas = new Complex[3];
	}
	
	void addSegmentoEletrico(SegmentoEletrico segmentoEletrico){	
		this.listSegmentoEletrico.add(segmentoEletrico);
	}

	void addSegmentoEletrico(int barraID, boolean direcao){	
		
		SegmentoEletrico segmentoEletrico = new SegmentoEletrico();
		
		segmentoEletrico.setBarraID(barraID);
		segmentoEletrico.setDirecao(direcao);
		segmentoEletrico.setStatus(true);
		this.listSegmentoEletrico.add(segmentoEletrico);
	}
	
	public void atualizaCorrenteSegmentoMontante(){
		
		ArrayList<SegmentoEletrico> listSegmentoEletricoAux= this.getListSegmentoEletrico(false,true);
		
		if (listSegmentoEletricoAux.size()>1 )
			log.info(" Há mais de um segmento alimentando a barra " + this.ID);
		
		if (listSegmentoEletricoAux.size()==1){
			SegmentoEletrico segmentoMontante = listSegmentoEletricoAux.get(0);
			
			//Zera a corrente do Segmento Eletrico a Montante
			segmentoMontante.zeraCorrente();
			
			//log.info("Antes :     De: " + segmentoMontante.getBarra_ID() + " Para: " + this.ID + " Corrente: " + segmentoMontante.imprimeCorrente() );
			
			segmentoMontante.setCorrente(this.getCorrenteCalculadaCargas());
			
			//log.info("Depois:     De: " + segmentoMontante.getBarra_ID() + " Para: " + this.ID  + " Corrente: " + segmentoMontante.imprimeCorrente() );
			
			//log.info("------");
		}

	}
	
	public boolean existeSegmentoEletrico(int barra_id){
		
		boolean existe=false;
		
		for(SegmentoEletrico segmentoEletricoAux:this.listSegmentoEletrico){
			
			if (segmentoEletricoAux.getBarraID()==barra_id){
				existe=true;
				return existe;
			}
		}

		return existe;
	}
		

	public SegmentoEletrico findSegmentoEletrico(int barra_id){
		
		for(SegmentoEletrico segmentoEletricoAux:this.listSegmentoEletrico){
			
			if (segmentoEletricoAux.getBarraID()==barra_id)
				return segmentoEletricoAux;
		}
		
		log.info(" Segmento Eletrico n�o encontrado ");
		return null;
	}
	
	
	
	public void updateSegmentoEletrico(SegmentoEletrico segmentoEletrico){
		
		//log.info(  " ZZZZZZZZZZZZZZ>>>> *****  BARRA " + this.getID() + " segmentos " + this.listSegmentoEletrico.toString());
		
		if (this.existeSegmentoEletrico(segmentoEletrico.BarraID)==false){
			log.info("------------ ERRO: Segmento Eletrico de " + this.ID + " para " + segmentoEletrico.getBarraID() + " n�o existe. Impossivel atualizar.");
		}
		
		//
//		SegmentoEletrico segmentoEletricoAux =this.findSegmentoEletrico(segmentoEletrico.Barra_ID);
//		
//		if (segmentoEletricoAux!=null){
//			
//			segmentoEletricoAux.copySegmentoEletrico(segmentoEletrico);
//			
//		}else{
//			log.info("--- ERRO: Segmento Eletrico n�o existe. Impossivel atualizar.");
//			
//		}
		
		for(SegmentoEletrico segmentoEletricoAux:this.listSegmentoEletrico){
			
			if (segmentoEletricoAux.getBarraID()==segmentoEletrico.getBarraID()){
				
				//log.info("Antes " + arestaAux);
				
				segmentoEletricoAux.copySegmentoEletrico(segmentoEletrico);
								
				//log.info("Depois " + findAresta(arestaAux.No_ID));
			}
		}
		
	}
	
	public ArrayList<SegmentoEletrico> getListSegmentoEletrico(){
		return this.listSegmentoEletrico;
	}
	
	public ArrayList<SegmentoEletrico> getListSegmentoEletrico(boolean direcao){
		
		ArrayList<SegmentoEletrico> listSegmentoEletricoAux = new ArrayList<SegmentoEletrico>();
		for (SegmentoEletrico segmentoEletrico : this.listSegmentoEletrico) {
			if (segmentoEletrico.getDirecao()==direcao)
				listSegmentoEletricoAux.add(segmentoEletrico);
		}
		return listSegmentoEletricoAux;
	}
	
	public ArrayList<SegmentoEletrico> getListSegmentoEletrico(boolean direcao,boolean status){
		
		ArrayList<SegmentoEletrico> listSegmentoEletricoAux = new ArrayList<SegmentoEletrico>();
		for (SegmentoEletrico segmentoEletrico : this.listSegmentoEletrico) {
			if (segmentoEletrico.getDirecao()==direcao && segmentoEletrico.getStatus()==status)
				listSegmentoEletricoAux.add(segmentoEletrico);
		}
		return listSegmentoEletricoAux;
	}
	
	public ArrayList<SegmentoEletrico> getListChaves(){
	
		ArrayList<SegmentoEletrico> listSegmentoEletricoAux = new ArrayList<SegmentoEletrico>();
		
		// percorre todos os segmentos com orientado fonte -> carga (sentido=true)
		for (SegmentoEletrico segmentoEletrico : this.getListSegmentoEletrico(true) ) {
			
			// se o segmento � uma Chave
			if ( segmentoEletrico instanceof Chave)
					listSegmentoEletricoAux.add(segmentoEletrico);
			
		}
		return listSegmentoEletricoAux;
	}
	
	public ArrayList<SegmentoEletrico> getListChaves(Boolean status){
		
		ArrayList<SegmentoEletrico> listSegmentoEletricoAux = new ArrayList<SegmentoEletrico>();
		
		// percorre todos os segmentos com orientado fonte -> carga (sentido=true) e com status
		for (SegmentoEletrico segmentoEletrico : this.getListSegmentoEletrico(false,status)) {
			
			// se o segmento � uma Chave e est� na direcao orientada 
			if ( segmentoEletrico instanceof Chave)
					listSegmentoEletricoAux.add(segmentoEletrico);
			
		}
		return listSegmentoEletricoAux;
	}
	
	

	public double getTensaoNominal() {
		return tensaoNominal;
	}

	public void setTensaoNominal(double tensaoNominal) {
		this.tensaoNominal = tensaoNominal;///Math.sqrt(3);
		this.inicializaTensao();
	}

	public void inicializaTensao(){
		Complex tensao = new Complex(this.tensaoNominal*Math.cos(0*Math.PI/180),this.tensaoNominal*Math.sin(0*Math.PI/180));
		assert(tensao.abs()/this.tensaoNominal > 0.999);
		assert(tensao.abs()/this.tensaoNominal < 1.001);
		this.tensaoCalculada.setElement(0, 0, tensao);
		tensao = new Complex(this.tensaoNominal*Math.cos(-120*Math.PI/180),this.tensaoNominal*Math.sin(-120*Math.PI/180));
		assert(tensao.abs()/this.tensaoNominal > 0.999);
		assert(tensao.abs()/this.tensaoNominal < 1.001);
		this.tensaoCalculada.setElement(1, 0, tensao);
		tensao = new Complex(this.tensaoNominal*Math.cos(120*Math.PI/180),this.tensaoNominal*Math.sin(120*Math.PI/180));
		assert(tensao.abs()/this.tensaoNominal > 0.999);
		assert(tensao.abs()/this.tensaoNominal < 1.001);
		this.tensaoCalculada.setElement(2, 0, tensao);
	}
	
	public int getTipoBarra() {
		return tipoBarra;
	}

	public void setTipoBarra(int nTipoBarra) {
		this.tipoBarra = nTipoBarra;
	}

	public void addCarga(Carga carga){
		
		this.listCargas.add(carga);
		
	}
	
	
	public ComplexMatrix getCorrenteCalculadaCargas() {
		ComplexMatrix correnteCargasTotal = new ComplexMatrix(3,1);
		for (Carga carga:listCargas){
			correnteCargasTotal = correnteCargasTotal.plus(carga.getCorrente(this.tensaoCalculada));
		}
		return correnteCargasTotal;
	}

	
	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public boolean isVerificado() {
		return verificado;
	}

	public void setVerificado(boolean verificado) {
		this.verificado = verificado;
	}
	
	public String toString(){
		String toString = String.format("Barra número: %4d. Lista de segmentos elétricos: %s", this.ID, this.listSegmentoEletrico.toString());
		return   toString;
	}
	
	public ComplexMatrix getTensaoCalculada() {
		return tensaoCalculada;
	}

	public void setTensaoCalculada(ComplexMatrix tensaoCalculada) {

		this.calculaMaiorMismatch(tensaoCalculada);
		this.tensaoCalculada = tensaoCalculada;
	}
	

	public double getMismatch() {
		return mismatchMaior;
	}
	
	private void calculaMaiorMismatch(ComplexMatrix tensaoCalculadaNova){
		
		this.mismatchMaior= Math.abs(this.tensaoCalculada.getElementCopy(0, 0).abs() - tensaoCalculadaNova.getElementCopy(0, 0).abs());
	
		for(int i=1 ; i<=2 ; i++){
			
			double mismatchAtual= Math.abs(this.tensaoCalculada.getElementCopy(i, 0).abs() - tensaoCalculadaNova.getElementCopy(i, 0).abs());
			
			if (mismatchAtual < this.mismatchMaior){
				this.mismatchMaior=mismatchAtual;
			}
			
			
		}
		
		log.debug("--------------------- Cálculo Mismatch ");
		log.debug("Barra: " +this.ID );
		log.debug("      Tensao calculada antiga: " + Rede.matrixFlanaganToStringABS(this.tensaoCalculada));
		log.debug("      Tensao calculada nova  :  " + Rede.matrixFlanaganToStringABS(tensaoCalculadaNova));
		log.debug("      Mismatch: " + this.mismatchMaior);
		
	}
	
	public void setCoord (Double coordX,Double coordY){
		this.coordX=coordX;
		this.coordY=coordY;
	}

	public Double getCoordX(){
		return this.coordX;
	}
	
	public Double getCoordY(){
		return this.coordY;
	}
	
	
}
