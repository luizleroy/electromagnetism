//package br.com.axxiom.ped435.test.functions.lf.rede;
//
//import br.com.axxiom.ped435.controller.app.MainCargaDados;
//import br.com.axxiom.ped435.test.functions.lf.plugin.Adept;
//
//public class TestLF {
//
//	/**
//	 * @param args
//	 */
//	// antes de transformar em um teste é necessário verificar se a biblioteca
//	// flanagan-math-fft é compatível com o build contínuo...
//	public static void main(String[] args) {
//		MainCargaDados.setLog();
//		Rede rede;
//		
//		Adept adept = new Adept();
////		rede = adept.carregaRede("src/test/resources/IEEE_13barras-Adaptado.3dis");
////		rede.constroiRede();
////		rede.fluxoVarredura();
//		
////		RedeIEEE13NodesTestFeeder test = new RedeIEEE13NodesTestFeeder();
////		rede = test.carregaRede();
////		rede.constroiRede();
////		rede.fluxoVarredura();
////		rede.toStringBarras();
//
////		RedeIEEE37NodesTestFeeder test = new RedeIEEE37NodesTestFeeder();
////		rede = test.carregaRede();
////		rede.constroiRede();
////		rede.fluxoVarredura();
//
////		RedePequenaTesteNewton fake = new RedePequenaTesteNewton();
////		rede = fake.carregaRede();
////		rede.constroiRede();
////		rede.fluxoVarredura();
////		rede.toStringBarras();
//
////		Pertec pertec = new Pertec();
////		rede = pertec.carregaRede("src/test/resources/SLAU07.xml");
////		rede.constroiRede();
////		rede.fluxoVarredura();
////
////		Adept adept = new Adept();
////		rede = adept.carregaRede("src/test/resources/IEEE_13barras-Adaptado.3dis");
////		rede.constroiRede();
////		rede.fluxoVarredura();
//	}
//
//	/*
//	 * rede.fluxoNewton(2811362); Rede rede = adept.carregaRede("UmaLinha.dat");
//	 * Rede rede = adept.carregaRede("CICM31.dat"); Rede rede =
//	 * adept.carregaRede("AMN 07.dat"); Rede rede =
//	 * adept.carregaRede("JQT 13.dat"); Rede rede =
//	 * adept.carregaRede("3000barras_SLAD214.dat"); Rede rede =
//	 * adept.carregaRede("CLHU07.dat"); Rede rede =
//	 * adept.carregaRede("1000barras_BRL_05.dat");
//	 */
//}
