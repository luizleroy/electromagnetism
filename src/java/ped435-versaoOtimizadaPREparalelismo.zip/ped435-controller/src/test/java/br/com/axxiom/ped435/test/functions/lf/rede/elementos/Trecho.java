package br.com.axxiom.ped435.test.functions.lf.rede.elementos;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.test.functions.lf.rede.SegmentoEletrico;
import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;

public class Trecho extends SegmentoEletrico {
	private static Logger log = Logger.getLogger(Trecho.class);
	private ComplexMatrix Zabc;
	private String fases;
	private Double comprimento;

	public Trecho() {
		this.corrente = new ComplexMatrix(3, 1);
		this.Zabc = new ComplexMatrix(3, 3);
		this.comprimento = 0.0;
		this.fases = "Não Informada ou Inválida";
	}

	public Trecho(Trecho trechoCopy) {

		this.Zabc = trechoCopy.Zabc.copy();
		this.corrente = trechoCopy.corrente.copy();
		this.comprimento = trechoCopy.comprimento;
		this.fases = trechoCopy.fases;
		this.status = trechoCopy.status;
		this.BarraID = trechoCopy.BarraID;

	}

	public Trecho(Integer IDBarraDestino, String fases, Double comprimento,
			ComplexMatrix Zabc) {
		this.BarraID = IDBarraDestino;
		this.direcao = true;
		this.status = true;
		this.Zabc = Zabc;
		this.comprimento = comprimento;
		this.corrente = new ComplexMatrix(3, 1);
	}

	public Trecho(Integer IDBarraDestino, String fases, Double comprimento,
			Double r1, Double x1, Double r0, Double x0) {
		this.BarraID = IDBarraDestino;
		this.direcao = true;
		this.status = true;
		this.comprimento = comprimento;
		this.setZabc(fases, comprimento, r1, x1, r0, x0);
		this.corrente = new ComplexMatrix(3, 1);
	}

	public ComplexMatrix calculaTensao(ComplexMatrix tensaoFonte) {
		ComplexMatrix quedaTensao = new ComplexMatrix(3, 0);
		ComplexMatrix tensaoCarga = new ComplexMatrix(3, 0);
		quedaTensao = Zabc.times(this.comprimento).times(corrente);
		quedaTensao = quedaTensao.times(0.001); // converte para kV
		tensaoCarga = tensaoFonte.minus(quedaTensao);
		return tensaoCarga;
	}

	public ComplexMatrix getZabc() {
		return this.Zabc;
	}

	public void setZabc(String fases, ComplexMatrix zabc) {
		this.fases = fases;
		this.Zabc = zabc;
		zeraFasesAusentes();
	}

	public void setZabc(String fases, Double comprimento, Complex z1, Complex z0) {
		this.fases = fases;
		this.converteSequenciaMatrizImpedancia(z1, z0);
	}

	public void setZabc(String fases, Double comprimento, Double r1, Double x1,
			Double r0, Double x0) {
		this.fases = fases;
		this.comprimento = comprimento;
		Complex z1 = new Complex(r1, x1);
		Complex z0 = new Complex(r0, x0);
		this.converteSequenciaMatrizImpedancia(z1, z0);
		this.zeraFasesAusentes();
	}

	// Zera as fases ausentes no trecho
	private void zeraFasesAusentes() {
		Double r = 0.0;// Double.MAX_VALUE;
		switch (this.fases) {
		case "A":
			// Linha 1
			this.Zabc.setElement(0, 1, r, 0);
			this.Zabc.setElement(0, 2, r, 0);
			// Linha 2
			this.Zabc.setElement(1, 0, r, 0);
			this.Zabc.setElement(1, 1, r, 0);
			this.Zabc.setElement(1, 2, r, 0);
			// Linha 3
			this.Zabc.setElement(2, 0, r, 0);
			this.Zabc.setElement(2, 1, r, 0);
			this.Zabc.setElement(2, 2, r, 0);
			break;
		case "B":
			// Linha 1
			this.Zabc.setElement(0, 0, r, 0);
			this.Zabc.setElement(0, 1, r, 0);
			this.Zabc.setElement(0, 2, r, 0);
			// Linha 2
			this.Zabc.setElement(1, 0, r, 0);
			this.Zabc.setElement(1, 2, r, 0);
			// Linha 3
			this.Zabc.setElement(2, 0, r, 0);
			this.Zabc.setElement(2, 1, r, 0);
			this.Zabc.setElement(2, 2, r, 0);
			break;
		case "C":
			// Linha 1
			this.Zabc.setElement(0, 0, r, 0);
			this.Zabc.setElement(0, 1, r, 0);
			this.Zabc.setElement(0, 2, r, 0);
			// Linha 2
			this.Zabc.setElement(1, 0, r, 0);
			this.Zabc.setElement(1, 1, r, 0);
			this.Zabc.setElement(1, 2, r, 0);
			// Linha 3
			this.Zabc.setElement(2, 0, r, 0);
			this.Zabc.setElement(2, 1, r, 0);
			break;
		case "AB":
			// Linha 1
			this.Zabc.setElement(0, 2, r, 0);
			// Linha 2
			this.Zabc.setElement(1, 2, r, 0);
			// Linha 3
			this.Zabc.setElement(2, 0, r, 0);
			this.Zabc.setElement(2, 1, r, 0);
			this.Zabc.setElement(2, 2, r, 0);
			break;
		case "AC":
			// Linha 1
			this.Zabc.setElement(0, 1, r, 0);
			// Linha 2
			this.Zabc.setElement(1, 0, r, 0);
			this.Zabc.setElement(1, 1, r, 0);
			this.Zabc.setElement(1, 2, r, 0);
			// Linha 3
			this.Zabc.setElement(2, 1, r, 0);
			break;
		case "BC":
			// Linha 1
			this.Zabc.setElement(0, 0, r, 0);
			this.Zabc.setElement(0, 1, r, 0);
			this.Zabc.setElement(0, 2, r, 0);
			// Linha 2
			this.Zabc.setElement(1, 0, r, 0);
			// Linha 3
			this.Zabc.setElement(2, 0, r, 0);
			break;
		case "ABC":
			break;
		default:
			log.info(" Fase informada inv�lida. Valor: " + this.fases);
		}
	}

	private void converteSequenciaMatrizImpedancia(Complex z1, Complex z0) {
		ComplexMatrix matrixSeq = new ComplexMatrix(3, 3);
		matrixSeq.setElement(0, 0, z0);
		matrixSeq.setElement(0, 1, 0, 0);
		matrixSeq.setElement(0, 2, 0, 0);

		matrixSeq.setElement(1, 0, 0, 0);
		matrixSeq.setElement(1, 1, z1);
		matrixSeq.setElement(1, 2, 0, 0);

		matrixSeq.setElement(2, 0, 0, 0);
		matrixSeq.setElement(2, 1, 0, 0);
		matrixSeq.setElement(2, 2, z1);

		Complex a = new Complex(Math.cos(Math.PI * 120 / 180),
				Math.sin(Math.PI * 120 / 180));

		Complex a2 = a.times(a);

		ComplexMatrix As = new ComplexMatrix(3, 3);

		As.setElement(0, 0, 1, 0);
		As.setElement(0, 1, 1, 0);
		As.setElement(0, 2, 1, 0);

		As.setElement(1, 0, 1, 0);
		As.setElement(1, 1, a2.getReal(), a2.getImag());
		As.setElement(1, 2, a.getReal(), a.getImag());

		As.setElement(2, 0, 1, 0);
		As.setElement(2, 1, a.getReal(), a.getImag());
		As.setElement(2, 2, a2.getReal(), a2.getImag());

		this.Zabc = As.times(matrixSeq).times((As).inverse());
	}

	public void zeraCorrente() {
		for (int i = 0; i <= 2; i++) {
			this.corrente.setElement(i, 0, new Complex(0, 0));
		}
	}

	public String printPolar(ComplexMatrix variavel) {
		String texto = "";
		for (int i = 0; i <= 2; i++) {
			String mag = String.valueOf(variavel.getElementCopy(i, 0).abs());
			String grau = String
					.valueOf(variavel.getElementCopy(i, 0).argDeg());
			texto = texto + mag + "|" + grau + "   ";
		}
		return texto;
	}

	public String printPolar3(ComplexMatrix variavel) {
		String texto = "\n            ";
		for (int i = 0; i <= 2; i++) {
			for (int j = 0; j <= 2; j++) {
				String var = String.valueOf(variavel.getElementCopy(i, j));
				texto = texto + var + "   ";
			}
			texto = texto + "\n            ";
		}
		return texto;
	}

	public Double getComprimento() {
		return comprimento;
	}

	public void setComprimento(Double comprimento) {
		this.comprimento = comprimento;
	}

}
