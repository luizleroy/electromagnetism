package br.com.axxiom.ped435.test.functions;

import br.com.axxiom.ped435.functions.Encoding;
import br.com.axxiom.ped435.util.Const;
import br.com.axxiom.ped435.util.TestFunction;

public class Function {
	public static TestFunction factoryMethod(String sFun) {
		Const.dims = Const.dimensaoGlobal;
		switch (sFun) {
		case "grupo13":
			return new EncodingGrupo13();
		case "encoding":
			return new Encoding();
		case "xOR2":
			return new EncodingXOR2();
		case "xOR3":
			return new EncodingXOR3();
		case "xOR4":
			return new EncodingXOR4();
		case "rastrigin":
			return new Rastrigin();
		case "bohachevsky":
			return new Bohachevsky();
		case "sphere\t":
			return new Sphere();
		case "schaffer":
			return new Schaffer();
		case "rosenbrock":
			return new Rosenbrock();
		case "schwefel_1":
			return new Schwefel_1();
		case "schwefel_2":
			return new Schwefel_2();
		case "schwefel_3":
			return new Schwefel_3();
		case "designPressureVessel":
			return new DesignPressureVessel();
		case "designWeldedBeam":
			return new DesignWeldedBeam();
		case "dejong_1":
			return new DeJong_1();
		case "minimizationWeightSpeed":
			return new MinimizationWeightSpeed();
		case "minimizationWeightTension":
			return new MinimizationWeightTension();
		default:
			throw new RuntimeException(sFun.toUpperCase()
					+ ": This Function is not implemented.");
		}
	}
}