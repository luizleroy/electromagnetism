package br.com.axxiom.ped435.test.functions;

import java.util.List;

import br.com.axxiom.ped435.functions.Encoding;
import br.com.axxiom.ped435.model.dao.service.TValidGrupo13Service;
import br.com.axxiom.ped435.model.entidade.dbped435.dbo.TValidGrupo13;
import br.com.axxiom.ped435.model.util.Matrix;
import br.com.axxiom.ped435.util.Const;
import br.com.axxiom.ped435.util.TestFunction;

public class EncodingGrupo13 extends Encoding implements TestFunction {
//	private static Logger log = Logger.getLogger(TestFunction.class);
	protected Matrix[] build() {
		TValidGrupo13Service tValid = new TValidGrupo13Service(); 
		// grupo de um determinado conjunto de ramos de atividade para testes
		List<TValidGrupo13> list = tValid.select();
		int x = 5;
		int y = 2;
		int[] nNeurData = {x,20,y};
		Const.configuraDimRNA(nNeurData);
		double[][] targetx = new double[x][list.size()]; // tamanho da entrada de dados da tabela do banco
		double[][] targety = new double[y][list.size()];
		for (int i = 0; i < list.size(); i++) {
			targetx[0][i] = list.get(i).getIdentificadorCliente();
			targetx[1][i] = list.get(i).getDiaMedicao();
			targetx[2][i] = list.get(i).getDemandaMedia();
			targetx[3][i] = list.get(i).getDemandaMaxima();
			targetx[4][i] = list.get(i).getPotInstalada();
			targety[0][i] = list.get(i).getFatorDeCarga();
			targety[1][i] = list.get(i).getFatorDeDemanda();
		}
		Matrix xx = new Matrix(targetx);
		Matrix yy = new Matrix(targety);
		Matrix target[] = {xx,yy};
		return target;
	}
}