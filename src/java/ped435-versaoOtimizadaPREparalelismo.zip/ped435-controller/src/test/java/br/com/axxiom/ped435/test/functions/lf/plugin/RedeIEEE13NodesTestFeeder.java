package br.com.axxiom.ped435.test.functions.lf.plugin;

import br.com.axxiom.ped435.test.functions.lf.rede.Rede;
import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;

public class RedeIEEE13NodesTestFeeder {

	Rede rede;

	public Rede carregaRede() {
		try {
			createBarramentos();
			carregaTrechos();
			carregaCargas();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		return rede;
	}

	private void carregaTrechos() throws NullPointerException {
		int bf, bc;
		double km, pri, seg, ter, qua, qui, sex, set, oit, non, dec, dec1, dec2;

		// trecho 1 configuração SEISSENTOS_E_UM
		bf = 650;
		bc = 632;
		km = 0.60960;
		pri = 0.215305;
		seg = 0.096934;
		ter = 0.098177;
		qua = 0.209713;
		qui = 0.095380;
		sex = 0.212136;
		set = 0.632494;
		oit = 0.31174193;
		non = 0.26321284;
		dec = 0.65107274;
		dec1 = 0.23916577;
		dec2 = 0.64299491;// 0.0,0.0,0.0,0.0,0.0,0.0, 0.642995e-6, -1.240133e-6,
							// -0.782617e-6, 3.703186e-6, -0.460871e-6,
							// 3.503664e-6
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
	
		// trecho 2: configuração SEISSENTOS_E_UM
		bf = 671;
		bc = 680;
		km = 0.30480;
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
		// trecho 3: configuração SEISSENTOS_E_UM
		bf = 632;
		bc = 671;
		// no arquivo do IEEE temos indicação "po", aqui e no 3diss são: 609.80m
		km = 0.6098;
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
		
//----------------
	// trecho 4: configuracao SEISSENTOS_E_DOIS
		bf = 632;
		bc = 633;
		km = 0.15240;
		pri = 0.191498;
		seg = 0.076580;
		ter = 0.068351;
		qua = 0.189315;
		qui = 0.076580;
		sex = 0.191498;
		set = 0.107073;
		oit = 0.00786914;
		non = 0.00343075;
		dec = 0.09694875;
		dec1 = 0.00786914;
		dec2 = 0.10707306;// 0.0,0.0,0.0,0.0,0.0,0.0, 3.541194e-6, -0.672137e-6,
							// -1.050428e-6, 3.218392e-6, -0.409359e-6,
							// 3.370690e-6
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);

		// -----------------
	// trecho 5: configuração SEISSENTOS_E_TRES	
		bf = 632;
		bc = 645;
		km = 0.15240;
		pri = 0.000000;
		seg = 0.000000;
		ter = 0.000000;
		qua = 0.826051;
		qui = 0.128375;
		sex = 0.822571;
		set = 0.000000;
		oit = 0.00000000;
		non = 0.00000000;
		dec = 0.83704913;
		dec1 = 0.28527151;
		dec2 = 0.84313857;// 0.0,0.0,0.0,0.0,0.0,0.0, 0.000000e-6, 0.000000e-6,
							// 0.000000e-6, 2.926472e-6, -0.559172e-6,
							// 2.899194e-6
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
		
		// trecho 6
		bf = 645;
		bc = 646;
		km = 0.09144;
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
		
		//  ------------------------
	// trecho 7: configuração SEISSENTOS_E_QUATRO	
		bf = 671;
		bc = 684;
		km = 0.09144;
		pri = 0.822571;
		seg = 0.000000;
		ter = 0.128375;
		qua = 0.000000;
		qui = 0.000000;
		sex = 0.826051;
		set = 0.843139;
		oit = 0.00000000;
		non = 0.28527151;
		dec = 0.00000000;
		dec1 = 0.00000000;
		dec2 = 0.83704913;// 0.0,0.0,0.0,0.0,0.0,0.0, 2.899193e-6, 0.000000e-6,
							// -0.559171e-6, 0.000000e-6, 0.000000e-6,
							// 2.926472e-6
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
		
		// ---------------------
		// trecho 8: configuração SEISSENTOS_E_CINCO
		bf = 684;
		bc = 611;
		km = 0.09144;
		pri = 0.000000;
		seg = 0.000000;
		ter = 0.000000;
		qua = 0.000000;
		qui = 0.000000;
		sex = 0.825927;
		set = 0.000000;
		oit = 0.00000000;
		non = 0.00000000;
		dec = 0.00000000;
		dec1 = 0.00000000;
		dec2 = 0.83729768;// 0.0,0.0,0.0,0.0,0.0,0.0, 0.000000e-6, 0.000000e-6,
							// 0.000000e-6, 0.000000e-6, 0.000000e-6,
							// 2.807019e-6
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
		
		// ---------------------
		// trecho 9: configuração SEISSENTOS_E_SEIS
		bf = 692;
		bc = 675;
		km = 0.15240;
		pri = 0.495978;
		seg = 0.198342;
		ter = 0.177029;
		qua = 0.490324;
		qui = 0.198342;
		sex = 0.495979;
		set = 0.277318;
		oit = 0.02038098;
		non = -0.0088856;
		dec = 0.25109610;
		dec1 = 0.02038098;
		dec2 = 0.27731796;
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
		
		// ------------------------
		// trecho 10: configuração SEISSENTOS_E_SETE	
		bf = 684;
		bc = 652;
		km = 0.24384;
		pri = 0.834191;
		seg = 0.000000;
		ter = 0.000000;
		qua = 0.000000;
		qui = 0.000000;
		sex = 0.000000;
		set = 0.318391;
		oit = 0.00000000;
		non = 0.00000000;
		dec = 0.00000000;
		dec1 = 0.00000000;
		dec2 = 0.00000000;// 0.0,0.0,0.0,0.0,0.0,0.0, 55.296568e-6, 0.000000e-6,
							// 0.000000e-6, 0.000000e-6, 0.000000e-6,
							// 0.000000e-6
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
		
		// -------------------------
		// TRECHO 11: CONFIG XFM-1
		bf = 633;
		bc = 634;
		km = 0.0;
		pri = 0.215305;
		seg = 0.096934;
		ter = 0.098177;
		qua = 0.209713;
		qui = 0.095380;
		sex = 0.212136;
		set = 0.632494;
		oit = 0.31174193;
		non = 0.26321284;
		dec = 0.65107274;
		dec1 = 0.23916577;
		dec2 = 0.64299491;// 0.0,0.0,0.0,0.0,0.0,0.0, 0.642995e-6, -1.240133e-6,
							// -0.782617e-6, 3.703186e-6, -0.460871e-6,
							// 3.503664e-6
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
		
	// ---------------
		// TRECHO 12: CONFIG SWITCH
		bf = 671;
		bc = 692;
		km = 0.0;
		pri = 0.215305;
		seg = 0.096934;
		ter = 0.098177;
		qua = 0.209713;
		qui = 0.095380;
		sex = 0.212136;
		set = 0.632494;
		oit = 0.31174193;
		non = 0.26321284;
		dec = 0.65107274;
		dec1 = 0.23916577;
		dec2 = 0.64299491;// 0.0,0.0,0.0,0.0,0.0,0.0, 0.642995e-6, -1.240133e-6,
							// -0.782617e-6, 3.703186e-6, -0.460871e-6,
							// 3.503664e-6
		addTrecho(bf, bc, km, pri, seg, ter, qua, qui, sex, set, oit, non,
				dec, dec1, dec2);
	}

	private void addTrecho(int bf, int bc, double km, double pri, double seg,
			double ter, double qua, double qui, double sex, double set,
			double oit, double non, double dec, double dec1, double dec2) {
		ComplexMatrix config = new ComplexMatrix(3, 3);
		// R(1=0,7=0), R(2=0,8=1), R(3=0,9=2), R(4=1,10=1), R(5=1,11=2),
		// R(6=2,12=2)
		config.setElement(0, 0, new Complex(pri, set)); // *
		config.setElement(0, 1, new Complex(seg, oit));
		config.setElement(0, 2, new Complex(ter, non));
		config.setElement(1, 1, new Complex(qua, dec)); // *
		config.setElement(1, 2, new Complex(qui, dec1));
		config.setElement(2, 2, new Complex(sex, dec2)); // *
		config.setElement(1, 0, new Complex(seg, oit));
		config.setElement(2, 0, new Complex(ter, non));
		config.setElement(2, 1, new Complex(qui, dec1));
		this.rede.addTrecho(bf, bc, "ABC", km, config);
	}

	private void carregaCargas() {
		// rede.addCargaBarra(nnn, 0, new Complex(ar, ai), new Complex(br,bi),
		// new Complex(cr,ci));
		double ar, ai, br, bi, cr, ci;
		int nnn;
		nnn = 645;
		ar = 0.;
		br = 170.;
		cr = 0.;
		ai = 0.;
		bi = 125.;
		ci = 0.;
		rede.addCargaBarra(nnn, 0, new Complex(ar, ai), new Complex(br, bi),
				new Complex(cr, ci));
		nnn = 646;
		ar = 0d;
		br = 230d;
		cr = 0d;
		ai = 0d;
		bi = 132d;
		ci = 0d;
		rede.addCargaBarra(nnn, 0, new Complex(ar, ai), new Complex(br, bi),
				new Complex(cr, ci));
		nnn = 652;
		ar = 128d;
		br = 0d;
		cr = 0d;
		ai = 86d;
		bi = 0d;
		ci = 0d;
		rede.addCargaBarra(nnn, 0, new Complex(ar, ai), new Complex(br, bi),
				new Complex(cr, ci));
		nnn = 671;
		ar = 385d;
		br = 385d;
		cr = 385d;
		ai = 220d;
		bi = 220d;
		ci = 220d;
		rede.addCargaBarra(nnn, 0, new Complex(ar, ai), new Complex(br, bi),
				new Complex(cr, ci));
		nnn = 675;
		ar = 485d;
		br = 68d;
		cr = 290d;
		ai = 190d;
		bi = 60d;
		ci = 212d;
		rede.addCargaBarra(nnn, 0, new Complex(ar, ai), new Complex(br, bi),
				new Complex(cr, ci));
		nnn = 611;
		ar = 0d;
		br = 0d;
		cr = 170d;
		ai = 0d;
		bi = 0d;
		ci = 80d;
		rede.addCargaBarra(nnn, 0, new Complex(ar, ai), new Complex(br, bi),
				new Complex(cr, ci));
		nnn = 888;
		ar = 11.33d;
		br = 44d;
		cr = 78d;
		ar = 6.67d;
		bi = 25.33d;
		ci = 45.33d;
		rede.addCargaBarra(nnn, 0, new Complex(ar, ai), new Complex(br, bi),
				new Complex(cr, ci));
	}

	private void createBarramentos() throws NullPointerException {
		rede = new Rede();
		double tensaoNominal = 4160.;
		int fonte = 650;
		this.rede.addBarra(fonte, tensaoNominal);
		this.rede.setBarraFonte(fonte);
		this.rede.addBarra(632, tensaoNominal);
		this.rede.addBarra(645, tensaoNominal);
		this.rede.addBarra(671, tensaoNominal);
		this.rede.addBarra(633, tensaoNominal);
		this.rede.addBarra(646, tensaoNominal);
		this.rede.addBarra(684, tensaoNominal);
		this.rede.addBarra(680, tensaoNominal);
		this.rede.addBarra(692, tensaoNominal);
		this.rede.addBarra(611, tensaoNominal);
		this.rede.addBarra(652, tensaoNominal);
		this.rede.addBarra(675, tensaoNominal);
		this.rede.addBarra(634, tensaoNominal);
	}

}
