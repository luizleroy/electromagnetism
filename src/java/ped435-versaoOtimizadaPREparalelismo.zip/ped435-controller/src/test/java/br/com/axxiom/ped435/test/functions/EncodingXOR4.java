package br.com.axxiom.ped435.test.functions;


import org.apache.log4j.Logger;

import br.com.axxiom.ped435.controller.util.Util;
import br.com.axxiom.ped435.functions.Encoding;
import br.com.axxiom.ped435.model.util.Matrix;
import br.com.axxiom.ped435.util.Const;
import br.com.axxiom.ped435.util.TestFunction;

// XOR implementa a famosa lógica do brinde: Ganha bata frita ou salada
// diferente do OR, que aceita alunos em um clube de xadrez, bons em matemática ou física.
public class EncodingXOR4 extends Encoding implements TestFunction {
	public static Logger log = Logger.getLogger(EncodingXOR4.class);

	protected Matrix[] build() {
		// grupo de um determinado conjunto de ramos de atividade para testes
		int x = 4;
		int[] nNeurData = { x, x, x, x, 1 };
		Const.configuraDimRNA(nNeurData);
		Matrix[] target = Util.createXorDataByXSquare(x);
		return target;
	}

	public static void main(String[] args) {
		Const.setLog();
		Util.createXorDataByXSquare(2); // TODO acadêmico
	}
}