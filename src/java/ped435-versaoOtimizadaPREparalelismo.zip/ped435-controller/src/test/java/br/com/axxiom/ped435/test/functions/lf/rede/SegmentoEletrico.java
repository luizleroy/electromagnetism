package br.com.axxiom.ped435.test.functions.lf.rede;

import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;


public class SegmentoEletrico  {
	
	protected String codigo;
	protected int BarraID;
	protected boolean direcao;
	protected boolean status;
	protected ComplexMatrix corrente;
	
	public SegmentoEletrico(){
		this.BarraID=-1;
	}
	
	public SegmentoEletrico(int Barra_ID, boolean direcao, boolean status) {
		super();
		this.BarraID = Barra_ID;
		this.direcao = direcao;
		this.status = status;
		this.corrente= new ComplexMatrix(3,1);
		this.zeraCorrente();
	}
	
	
	public SegmentoEletrico(String codigo, int Barra_ID, boolean direcao, boolean status) {
		this.BarraID = Barra_ID;
		this.direcao = direcao;
		this.status = status;
		this.corrente= new ComplexMatrix(3,1);
		this.zeraCorrente();

		this.codigo=codigo;
	}
	
	
	
	public SegmentoEletrico(int Barra_ID, boolean direcao, boolean status,ComplexMatrix corrente) {
		//super();
		this.BarraID = Barra_ID;
		this.direcao = direcao;
		this.status = status;
		this.corrente= corrente;

	}

	public SegmentoEletrico(SegmentoEletrico segmentoEletricoCopy){
		
		this.BarraID = segmentoEletricoCopy.BarraID;
		this.direcao = segmentoEletricoCopy.direcao;
		this.status = segmentoEletricoCopy.status;
		this.corrente=segmentoEletricoCopy.corrente.copy();

	}
	
	public void copySegmentoEletrico(SegmentoEletrico segmentoEletricoCopy){
		
		this.BarraID = segmentoEletricoCopy.BarraID;
		this.direcao = segmentoEletricoCopy.direcao;
		this.status = segmentoEletricoCopy.status;
		this.corrente=segmentoEletricoCopy.corrente.copy();

	}
	
	public ComplexMatrix calculaTensao(ComplexMatrix tensaoFonte){
		return tensaoFonte;
	}
	
	public void zeraCorrente(){
	
		for(int i=0; i<=2; i++){
			this.corrente.setElement(i, 0, new Complex(0,0));
		}
		
	}
	
	public void addCorrente(ComplexMatrix corrente){
		this.corrente=this.corrente.plus(corrente);
	}
	
	public void setCorrente(ComplexMatrix corrente){
		this.corrente=corrente;
	}
	
	public ComplexMatrix getCorrente(){
		
		return this.corrente;
	}
	
		
	public int getBarraID() {
		return BarraID;
	}

	public void setBarraID(int barraID) {
		BarraID = barraID;
	}
	
	
	public boolean getDirecao() {
		return direcao;
	}

	public void setDirecao(boolean direcao) {
		this.direcao = direcao;
	}
	
	public boolean getStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
	
public String toString(){
		
		String imprime= String.valueOf(this.BarraID);
		
		if (this.direcao==false && this.status==true)
			imprime=imprime+"*";
		
		if (this.status==false)
			imprime=imprime+"A";

		return imprime;
	}



	
}
