package br.com.axxiom.ped435.test.functions;

import java.util.Arrays;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.util.Const;
import br.com.axxiom.ped435.util.TestFunction;

public class Schaffer  implements TestFunction {
	private static Logger log = Logger.getLogger(Schaffer.class);
	private static final double modInit = 0.1;
	private static final double offSet = 0.;

	private double[] dnValue = new double[Const.dims];
	private double[] upValue = new double[Const.dims];
	private double[] optimum = new double[Const.dims];
	private long counter;

	Schaffer() {
		this.setDnValue();
		this.setUpValue();
		this.setOptimum();
		this.counter = 0L;
	}

	private void setDnValue() {
		this.init(this.dnValue, -modInit);
	}

	@Override
	public double[] getDnValue() {
		return this.dnValue;
	}

	private void setUpValue() {
		this.init(this.upValue, modInit);
	}

	@Override
	public double[] getUpValue() {
		return this.upValue;
	}

	private void setOptimum() {
		this.init(this.optimum, 0.);
	}

	@Override
	public double[] getOptimum() {
		return this.optimum;
	}

	private void init(double t[], double val) {
		for (int i = 0; i < Const.dims; i++) {
			t[i] = val;
		}
	}

	@Override
	public double get(double[] x) {
		double target = 0;
		for (Integer i = 0; i < Const.dims; i++) {
			double xi = x[i] - offSet;
			target += xi*xi;
		}
		target = Math.pow(target, 0.25)*(Math.sin(50*Math.pow(target,0.1))*Math.sin(50*Math.pow(target,0.1))+1);
		this.counter++;
		return target;
	}
	
	@Override
	public void resetCounter() {
		counter = 0L;
	}

	@Override
	public long getCounter() {
		return counter;
	}

	public static void main(String args[]) {
		Schaffer sch = new Schaffer();
		double x[] = sch.getOptimum();
		log.info(Arrays.toString(x));
		log.info(sch.get(x));
		log.info("\n");
		double my[] = {38.9504,51.6199,-13.4715,31.0996,-78.0490};
		log.info(Arrays.toString(my));
		log.info(sch.get(my));
		log.info("\n");
	}
}
