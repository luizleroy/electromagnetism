package br.com.axxiom.ped435.test.functions;

import br.com.axxiom.ped435.util.Const;
import br.com.axxiom.ped435.util.TestFunction;

public class Schwefel_2 implements TestFunction {
	private static final double modInitUp = 500.;//420.9687 + 220.9;//500.;
	private static final double modInitLow = 300.;//420.9687 - 220.9;//-500.;

	private double[] dnValue = new double[Const.dims];
	private double[] upValue = new double[Const.dims];
	private double[] optimum = new double[Const.dims];
	private long counter;

	public Schwefel_2() {
		this.setDnValue();
		this.setUpValue();
		this.setOptimum();
		this.counter = 0L;
	}

	private void setDnValue() {
		this.init(this.dnValue, modInitLow);
	}

	@Override
	public double[] getDnValue() {
		return this.dnValue;
	}

	private void setUpValue() {
		this.init(this.upValue, modInitUp);
	}

	@Override
	public double[] getUpValue() {
		return this.upValue;
	}

	private void setOptimum() {
		this.init(this.optimum, 420.9687); // BY Molga "Test Functions for optimization needs"
	}

	@Override
	public double[] getOptimum() {
		return this.optimum;
	}

	private void init(double t[], double val) {
		for (int i = 0; i < Const.dims; i++) {
			t[i] = val;
		}
	}

	@Override
	public double get(double[] x) {
		this.counter++;
		Integer n = Const.dims;
		double target = 0;
		for (Integer i = 0; i < n; i++) {
			if (x[i] < -modInitLow || x[i] > modInitUp) {
				return Double.MAX_VALUE;
			}
			target += -1*(Math.sin(Math.sqrt(Math.abs(x[i]))))*(x[i]);
		}
		return target;
	}
	
	@Override
	public void resetCounter() {
		counter = 0L;
	}

	@Override
	public long getCounter() {
		return counter;
	}
}