package br.com.axxiom.ped435.test.functions.lf.plugin;

import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;
import br.com.axxiom.ped435.test.functions.lf.rede.Rede;

public class RedeIEEE37NodesTestFeeder {
	private Rede rede;

	public RedeIEEE37NodesTestFeeder() {
		this.rede = new Rede();
	}

	public Rede carregaRede() {
		this.carregaBarras();
		this.carregaCargas();
		this.carregaTrechos();
		this.rede.setBarraFonte(701);
		return rede;
	}

	private void carregaTrechos() {
		ComplexMatrix config721 = new ComplexMatrix(3, 3); // ohms / mile
		config721.setElement(0, 0, new Complex(0.2926, 0.1973));
		config721.setElement(1, 1, new Complex(0.2646, 0.1900));
		config721.setElement(2, 2, new Complex(0.2926, 0.1973));

		config721.setElement(0, 1, new Complex(0.0673, -0.0368));
		config721.setElement(1, 0, new Complex(0.0673, -0.0368));

		config721.setElement(0, 2, new Complex(0.0337, 0.0417));
		config721.setElement(2, 0, new Complex(0.0337, 0.0417));

		config721.setElement(1, 2, new Complex(0.0673, -0.0368));
		config721.setElement(2, 1, new Complex(0.0673, -0.0368));

		ComplexMatrix config722 = new ComplexMatrix(3, 3); // ohms / mile
		config722.setElement(0, 0, new Complex(0.4751, 0.2973));
		config722.setElement(1, 1, new Complex(0.4488, 0.2678));
		config722.setElement(2, 2, new Complex(0.4751, 0.2973));

		config722.setElement(0, 1, new Complex(0.1629, -0.0326));
		config722.setElement(1, 0, new Complex(0.1629, -0.0326));

		config722.setElement(0, 2, new Complex(0.1234, -0.0607));
		config722.setElement(2, 0, new Complex(0.1234, -0.0607));

		config722.setElement(1, 2, new Complex(0.1629, -0.0326));
		config722.setElement(2, 1, new Complex(0.1629, -0.0326));

		ComplexMatrix config723 = new ComplexMatrix(3, 3); // ohms / mile
		config723.setElement(0, 0, new Complex(1.2936, 0.6713));
		config723.setElement(1, 1, new Complex(1.3022, 0.6326));
		config723.setElement(2, 2, new Complex(1.2936, 0.6713));

		config723.setElement(0, 1, new Complex(0.4871, 0.2111));
		config723.setElement(1, 0, new Complex(0.4871, 0.2111));

		config723.setElement(0, 2, new Complex(0.4585, 0.1521));
		config723.setElement(2, 0, new Complex(0.4585, 0.1521));

		config723.setElement(1, 2, new Complex(0.4871, 0.2111));
		config723.setElement(2, 1, new Complex(0.4871, 0.2111));

		ComplexMatrix config724 = new ComplexMatrix(3, 3); // ohms / mile
		config724.setElement(0, 0, new Complex(2.0952, 0.7758));
		config724.setElement(1, 1, new Complex(2.1068, 0.7398));
		config724.setElement(2, 2, new Complex(2.0952, 0.7758));

		config724.setElement(0, 1, new Complex(0.5204, 0.2738));
		config724.setElement(1, 0, new Complex(0.5204, 0.2738));

		config724.setElement(0, 2, new Complex(0.4926, 0.2123));
		config724.setElement(2, 0, new Complex(0.4926, 0.2123));

		config724.setElement(1, 2, new Complex(0.5204, 0.2738));
		config724.setElement(2, 1, new Complex(0.5204, 0.2738));

		// converter pés em milhas: mi =ft * 0.00018939
		this.rede.addTrecho(701, 702, "ABC", 960. * 0.00018939, config722);
		this.rede.addTrecho(702, 703, "ABC", 1320. * 0.00018939, config722);
		this.rede.addTrecho(702, 705, "ABC", 400. * 0.00018939, config724);
		this.rede.addTrecho(702, 713, "ABC", 360. * 0.00018939, config723);
		
		this.rede.addTrecho(703, 727, "ABC", 240. * 0.00018939, config724);
		this.rede.addTrecho(703, 730, "ABC", 600. * 0.00018939, config723);

		this.rede.addTrecho(705, 712, "ABC", 240. * 0.00018939, config724);
		this.rede.addTrecho(705, 742, "ABC", 320. * 0.00018939, config724);

		this.rede.addTrecho(713, 704, "ABC", 520. * 0.00018939, config723);

		this.rede.addTrecho(727, 744, "ABC", 280. * 0.00018939, config723);

		this.rede.addTrecho(744, 728, "ABC", 200. * 0.00018939, config724);
		this.rede.addTrecho(744, 729, "ABC", 280. * 0.00018939, config724);

		this.rede.addTrecho(730, 709, "ABC", 200. * 0.00018939, config723);

		this.rede.addTrecho(709, 731, "ABC", 600. * 0.00018939, config723);
		this.rede.addTrecho(709, 708, "ABC", 320. * 0.00018939, config723);

		this.rede.addTrecho(708, 732, "ABC", 320. * 0.00018939, config724);
		this.rede.addTrecho(708, 733, "ABC", 320. * 0.00018939, config723);

		this.rede.addTrecho(733, 734, "ABC", 560. * 0.00018939, config723);

		this.rede.addTrecho(734, 710, "ABC", 520. * 0.00018939, config724);

		this.rede.addTrecho(710, 735, "ABC", 200. * 0.00018939, config724);
		this.rede.addTrecho(710, 736, "ABC", 1280. * 0.00018939, config724);

		this.rede.addTrecho(734, 737, "ABC", 640. * 0.00018939, config723);

		this.rede.addTrecho(737, 738, "ABC", 400. * 0.00018939, config723);

		this.rede.addTrecho(738, 711, "ABC", 400. * 0.00018939, config723);

		this.rede.addTrecho(711, 741, "ABC", 400. * 0.00018939, config723);
		this.rede.addTrecho(711, 740, "ABC", 200. * 0.00018939, config724);

		this.rede.addTrecho(704, 714, "ABC", 80. * 0.00018939, config724);
		this.rede.addTrecho(704, 720, "ABC", 800. * 0.00018939, config723);

		this.rede.addTrecho(714, 718, "ABC", 520. * 0.00018939, config724);
		
		this.rede.addTrecho(706, 725, "ABC", 280. * 0.00018939, config724);
		
		this.rede.addTrecho(707, 724, "ABC", 760. * 0.00018939, config724);
		this.rede.addTrecho(707, 722, "ABC", 120. * 0.00018939, config724);
		
		this.rede.addTrecho(720, 707, "ABC", 920. * 0.00018939, config724);
		this.rede.addTrecho(720, 706, "ABC", 600. * 0.00018939, config723);
	}

	private void carregaCargas() { // kW / KVAr
		rede.addCargaBarra(701, 0, new Complex(140., 70.), new Complex(140.,
				70.), new Complex(350., 175.));
		rede.addCargaBarra(712, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(85., 40.));
		rede.addCargaBarra(713, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(85., 40.));
		rede.addCargaBarra(712, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(85., 40.));
		rede.addCargaBarra(714, 0, new Complex(17., 8.), new Complex(21., 10.),
				new Complex(0., 0.));
		rede.addCargaBarra(718, 0, new Complex(85., 40.), new Complex(0., 0.),
				new Complex(0., 0.));
		rede.addCargaBarra(720, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(85., 40.));
		rede.addCargaBarra(722, 0, new Complex(0., 0.), new Complex(140., 70.),
				new Complex(21., 10.));
		rede.addCargaBarra(724, 0, new Complex(0., 0.), new Complex(42., 21.),
				new Complex(0., 0.));
		rede.addCargaBarra(725, 0, new Complex(0., 0.), new Complex(42., 21.),
				new Complex(0., 0.));
		rede.addCargaBarra(727, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(42., 21.));
		rede.addCargaBarra(728, 0, new Complex(42., 21.),
				new Complex(42., 21.), new Complex(42., 21.));
		rede.addCargaBarra(729, 0, new Complex(42., 21.), new Complex(0., 0.),
				new Complex(0., 0.));
		rede.addCargaBarra(730, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(85., 40.));
		rede.addCargaBarra(731, 0, new Complex(0., 0.), new Complex(85., 40.),
				new Complex(0., 0.));
		rede.addCargaBarra(732, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(42., 21.));
		rede.addCargaBarra(733, 0, new Complex(85., 40.), new Complex(0., 0.),
				new Complex(0., 0.));
		rede.addCargaBarra(734, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(42., 21.));
		rede.addCargaBarra(735, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(85., 40.));
		rede.addCargaBarra(736, 0, new Complex(0., 0.), new Complex(42., 21.),
				new Complex(0., 0.));
		rede.addCargaBarra(737, 0, new Complex(140., 70.), new Complex(0., 0.),
				new Complex(0., 0.));
		rede.addCargaBarra(738, 0, new Complex(126., 62.), new Complex(0., 0.),
				new Complex(0., 0.));
		rede.addCargaBarra(740, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(85., 40.));
		rede.addCargaBarra(741, 0, new Complex(0., 0.), new Complex(0., 0.),
				new Complex(42., 21.));
		rede.addCargaBarra(742, 0, new Complex(8., 4.), new Complex(85., 40.),
				new Complex(0., 0.));
		rede.addCargaBarra(744, 0, new Complex(42., 21.), new Complex(0., 0.),
				new Complex(0., 0.));
	}

	private void carregaBarras() {

		double tensaoNominal = 13800.0; // v

		this.rede.addBarra(701, tensaoNominal);
		this.rede.addBarra(712, tensaoNominal);
		this.rede.addBarra(705, tensaoNominal);
		this.rede.addBarra(742, tensaoNominal);

		this.rede.addBarra(713, tensaoNominal);
		this.rede.addBarra(704, tensaoNominal);
		this.rede.addBarra(714, tensaoNominal);
		this.rede.addBarra(718, tensaoNominal);
		this.rede.addBarra(722, tensaoNominal);
		this.rede.addBarra(724, tensaoNominal);
		this.rede.addBarra(707, tensaoNominal);
		this.rede.addBarra(720, tensaoNominal);
		this.rede.addBarra(706, tensaoNominal);
		this.rede.addBarra(725, tensaoNominal);

		this.rede.addBarra(702, tensaoNominal);
		this.rede.addBarra(703, tensaoNominal);

		this.rede.addBarra(727, tensaoNominal);
		this.rede.addBarra(744, tensaoNominal);
		this.rede.addBarra(729, tensaoNominal);
		this.rede.addBarra(728, tensaoNominal);

		this.rede.addBarra(730, tensaoNominal);

		this.rede.addBarra(709, tensaoNominal);

		this.rede.addBarra(731, tensaoNominal);

		this.rede.addBarra(708, tensaoNominal);

		this.rede.addBarra(732, tensaoNominal);

		this.rede.addBarra(733, tensaoNominal);

		this.rede.addBarra(734, tensaoNominal);

		this.rede.addBarra(736, tensaoNominal);
		this.rede.addBarra(710, tensaoNominal);
		this.rede.addBarra(735, tensaoNominal);

		this.rede.addBarra(737, tensaoNominal);
		this.rede.addBarra(738, tensaoNominal);
		this.rede.addBarra(711, tensaoNominal);

		this.rede.addBarra(740, tensaoNominal);
		this.rede.addBarra(741, tensaoNominal);
	}
}
