package br.com.axxiom.ped435.test.functions.lf.plugin;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import br.com.axxiom.ped435.test.functions.lf.rede.Rede;

import flanagan.complex.Complex;

/**
 * Não inserir circuito com chaves abertas!!!
 * 
 * @author lhipolito
 * 
 */
public class Pertec {
	private static Logger log = Logger.getLogger(Pertec.class);
	private Rede redePertec;

	public Pertec() {
		redePertec = new Rede();
	}

	public Rede carregaRede(String nomeArquivo) {

		try {
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(new File(nomeArquivo));

			// normalize text representation
			// doc.getDocumentElement().normalize();
			// log.info("Root element of the doc is " +
			// doc.getDocumentElement().getNodeName());

			// Carrega a biblioteca de condutores.
			Map<String, List<Double>> mapCondutores = this.carregaBibliotecaCondutores(doc);

			Map<String, Integer> mapChave = this.carregaChave(doc);

			// Carrega o Circuito
			Double tensaoNominalCircuito = this.carregaCircuito(doc);

			// Carrega as barras
			this.carregaBarras(doc, tensaoNominalCircuito);

			// Carrega os Trechos
			this.carregaTrechoChave(doc, mapChave, mapCondutores);

			// Carrega cargas
			this.carregaCargas(doc);

		} catch (SAXParseException err) {
			log.info("** Parsing error" + ", line " + err.getLineNumber() + ", uri " + err.getSystemId());
			log.info(" " + err.getMessage());

		} catch (SAXException e) {
			Exception x = e.getException();
			((x == null) ? e : x).printStackTrace();

		} catch (Throwable t) {
			t.printStackTrace();
		}

		return this.redePertec;
	}

	private Double carregaCircuito(Document doc) {

		log.info("Carregando dados do circuito...");

		Double tensaoNominal = -1.0;
		NodeList listCircuito = doc.getElementsByTagName("CIRCUITO");
		Node circuito = listCircuito.item(0);

		if (circuito.getNodeType() == Node.ELEMENT_NODE) {

			Element circuitoElement = (Element) circuito;

			String idBarraFonteString = this.getNode(circuitoElement, "BARRA_ID");
			Integer idBarraFonte = Integer.valueOf(idBarraFonteString.substring(3, idBarraFonteString.length()));

			tensaoNominal = Double.valueOf(this.getNode(circuitoElement, "VNOM_KV"));

			redePertec.addBarra(idBarraFonte, tensaoNominal);
			redePertec.setBarraFonte(idBarraFonte);
		}

		return tensaoNominal;
	}

	private void carregaBarras(Document doc, Double tensaoNominalCircuito) {

		log.info("Carregando dados das barras...");

		NodeList listBarras = doc.getElementsByTagName("BARRA");
		// int qteBarras = listBarras.getLength();
		// log.info("Quantidade de Barras : " + qteBarras);

		for (int s = 0; s < listBarras.getLength(); s++) {

			Node barra = listBarras.item(s);
			if (barra.getNodeType() == Node.ELEMENT_NODE) {

				Element barraElement = (Element) barra;

				String idBarraString = this.getNode(barraElement, "ID");
				Integer idBarra = Integer.valueOf(idBarraString.substring(3, idBarraString.length()));
				// log.info("String " + idBarraString + " Convertido :" +
				// idBarra);

				redePertec.addBarra(idBarra, tensaoNominalCircuito);

			}

		}

	}

	private void carregaTrechoChave(Document doc, Map<String, Integer> mapChave, Map<String, List<Double>> mapCondutores) {

		log.info("Carregando dados dos trechos...");

		NodeList listTrecho = doc.getElementsByTagName("TRECHO");

		for (int s = 0; s < listTrecho.getLength(); s++) {

			Node trecho = listTrecho.item(s);

			if (trecho.getNodeType() == Node.ELEMENT_NODE) {

				Element trechoElement = (Element) trecho;

				String idBarraFonteString = this.getNode(trechoElement, "BARRA1_ID");
				Integer idBarraFonte = Integer.valueOf(idBarraFonteString.substring(3, idBarraFonteString.length()));

				String idBarraCargaString = this.getNode(trechoElement, "BARRA2_ID");
				Integer idBarraCarga = Integer.valueOf(idBarraCargaString.substring(3, idBarraCargaString.length()));

				String fases = this.getNode(trechoElement, "FASES");
				Double comprimento = Double.valueOf(this.getNode(trechoElement, "COMPR_M")) / 1000;

				String idTrecho = this.getNode(trechoElement, "EXTERN_ID");

				// se for uma chave
				if (mapChave.containsKey(idTrecho)) {

					// log.info( " **** Chave Adicionada");
					Integer statusChave = mapChave.get(idTrecho);
					Boolean status = true;

					if (statusChave == 0)
						status = false;
					// TODO retirei add chave para limpar o código com objetivo
					// de implementar apenas varredura
					// this.redePertec.addChave(idBarraFonte, idBarraCarga,
					// status);

				} else {
					// � um trecho

					String tipoCondutor = this.getNode(trechoElement, "CABO_FASE_ID");

					List<Double> listImpedancia = mapCondutores.get(tipoCondutor);

					if (listImpedancia == null) {
						listImpedancia = mapCondutores.get("CAB1081"); // condutor
																		// default
						// log.info("***** Condutor default utilizado ! ! !  Valor procurado + "
						// + tipoCondutor);
					}

					Double r1 = listImpedancia.get(0);
					Double x1 = listImpedancia.get(1);

					Double r0 = listImpedancia.get(2);
					Double x0 = listImpedancia.get(3);

					// log.info(s + " Idtrecho " + idTrecho +
					// " Barra fonte: " + idBarraFonte + " Barra carga " +
					// idBarraCarga + " fases: " +fases + " Condutor " +
					// tipoCondutor);

					redePertec.addTrecho(idBarraFonte, idBarraCarga, fases, comprimento, r1, x1, r0, x0);
				}
			}

		}
	}

	private void carregaCargas(Document doc) {

		log.info("Carregando dados das cargas...");

		NodeList listTrafo = doc.getElementsByTagName("INSTAL_TRAFO");

		Complex demFsA = new Complex(0.0, 0.0);
		Complex demFsB = new Complex(0.0, 0.0);
		Complex demFsC = new Complex(0.0, 0.0);

		for (int s = 0; s < listTrafo.getLength(); s++) {

			Node trafo = listTrafo.item(s);
			if (trafo.getNodeType() == Node.ELEMENT_NODE) {

				Element trafoElement = (Element) trafo;

				String idBarraString = this.getNode(trafoElement, "BARRA_ID");
				Integer idBarra = Integer.valueOf(idBarraString.substring(3, idBarraString.length()));

				String fases = this.getNode(trafoElement, "FASES_MT");

				Double consumoTrafo = Double.valueOf(this.getNode(trafoElement, "CONSUMO_KWH_MES"));

				Double demandaTotalAtiva = 1.3 * consumoTrafo * 1.24 / 730;
				Double demandaTotalReativa = 1.3 * consumoTrafo * 1.24 / (730 * 0.92) * Math.sin(Math.acos(0.92));

				switch (fases) {

				case "A":
					demFsA.setReal(demandaTotalAtiva);
					demFsA.setImag(demandaTotalReativa);
					break;

				case "B":
					demFsB.setReal(demandaTotalAtiva);
					demFsB.setImag(demandaTotalReativa);
					break;

				case "C":
					demFsC.setReal(demandaTotalAtiva);
					demFsC.setImag(demandaTotalReativa);
					break;

				case "ABC":
					Double demandaAtiva = demandaTotalAtiva / 3;
					Double demandaReativa = demandaTotalReativa / 3;

					demFsA.setReal(demandaAtiva);
					demFsA.setImag(demandaReativa);

					demFsB.setReal(demandaAtiva);
					demFsB.setImag(demandaReativa);

					demFsC.setReal(demandaAtiva);
					demFsC.setImag(demandaReativa);

					break;
				default:
					log.info(" Fase do transformador inv�lida: " + fases);
				}

				redePertec.addCargaBarra(idBarra, 2, demFsA, demFsB, demFsC);

			}
		}

	}

	private Map<String, Integer> carregaChave(Document doc) {

		log.info("Carregando dados das chaves...");

		Map<String, Integer> mapChave = new HashMap<String, Integer>();

		NodeList listChave = doc.getElementsByTagName("CHAVE");

		for (int s = 0; s < listChave.getLength(); s++) {

			Node chave = listChave.item(s);

			if (chave.getNodeType() == Node.ELEMENT_NODE) {

				Element chaveElement = (Element) chave;

				String idTrechoChave = this.getNode(chaveElement, "TRECHO_ID");
				Integer statusChave = Integer.valueOf(this.getNode(chaveElement, "ESTADO"));

				mapChave.put(idTrechoChave, statusChave);
			}

		}

		return mapChave;

	}

	private Map<String, List<Double>> carregaBibliotecaCondutores(Document doc) {

		log.info("Carregando biblioteca dos condutores...");

		Map<String, List<Double>> mapCondutores = new HashMap<String, List<Double>>();

		NodeList listCondutor = doc.getElementsByTagName("CABO");

		for (int s = 0; s < listCondutor.getLength(); s++) {

			Node condutor = listCondutor.item(s);

			if (condutor.getNodeType() == Node.ELEMENT_NODE) {

				Element condutorElement = (Element) condutor;

				String condutorDescricao = this.getNode(condutorElement, "EXTERN_ID");

				Double r1 = Double.valueOf(this.getNode(condutorElement, "R1_OHM_KM"));
				Double x1 = Double.valueOf(this.getNode(condutorElement, "X1_OHM_KM"));

				Double r0 = Double.valueOf(this.getNode(condutorElement, "R0_OHM_KM"));
				Double x0 = Double.valueOf(this.getNode(condutorElement, "X0_OHM_KM"));

				List<Double> listImpedancia = new ArrayList<Double>();

				listImpedancia.add(r1);
				listImpedancia.add(x1);
				listImpedancia.add(r0);
				listImpedancia.add(x0);

				mapCondutores.put(condutorDescricao, listImpedancia);

			}

		}

		return mapCondutores;
	}

	private String getNode(Element element, String tagName) {

		NodeList nodeList = element.getElementsByTagName(tagName);
		Element elementAux = (Element) nodeList.item(0);

		NodeList texto = elementAux.getChildNodes();
		// log.info( tagName + "  " +
		// ((Node)texto.item(0)).getNodeValue().trim());

		return ((Node) texto.item(0)).getNodeValue().trim();

	}
}
