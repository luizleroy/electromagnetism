package br.com.axxiom.ped435.test.functions;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.util.Const;
import br.com.axxiom.ped435.util.TestFunction;

public class Schwefel_3 implements TestFunction {
	private static Logger log = Logger.getLogger(Schwefel_3.class);
	private static final double modInit = 65.536; // BY MOLGA

	private double[] dnValue = new double[Const.dims];
	private double[] upValue = new double[Const.dims];
	private double[] optimum = new double[Const.dims];
	private long counter;
	private double offset = 100.;

	Schwefel_3() {
		this.setDnValue();
		this.setUpValue();
		this.setOptimum();
		this.counter = 0L;
	}

	private void setDnValue() {
		this.init(this.dnValue, -modInit);
	}

	@Override
	public double[] getDnValue() {
		return this.dnValue;
	}

	private void setUpValue() {
		this.init(this.upValue, modInit);
	}

	@Override
	public double[] getUpValue() {
		return this.upValue;
	}

	private void setOptimum() {
		this.init(this.optimum, offset); // BY MOLGMA
	}

	@Override
	public double[] getOptimum() {
		return this.optimum;
	}

	private void init(double t[], double val) {
		for (int i = 0; i < Const.dims; i++) {
			t[i] = val;
		}
	}

	@Override
	public double get(double[] x) {
		int n = Const.dims;
		double target = 0;
		for (int i = 0; i < n; i++) {
			double cusum = 0.;
			for (int j = 0; j < i+1; j++) {
				cusum += (x[j]-offset)*(x[j]-offset);
			}
			target+=cusum;
		}
		this.counter++;
		return target;
	}
	
	@Override
	public void resetCounter() {
		counter = 0L;
	}

	@Override
	public long getCounter() {
		return counter;
	}
	
	public static void main(String args[]) {
		double x[] = {1. , 3.};
		Schwefel_3 f = new Schwefel_3();
		log.info(f.get(x));
		
	}
}