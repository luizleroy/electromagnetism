package br.com.axxiom.ped435.test.functions.lf.rede.elementos;

import org.apache.log4j.Logger;

import br.com.axxiom.ped435.test.functions.lf.plugin.DISS;
import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;

public class Carga {

	private static Logger log = Logger.getLogger(Carga.class);

	private double tensaoNominal;
	private double expoente;

	private ComplexMatrix potenciaNominal;
	private ComplexMatrix potenciaCalculada;
	private ComplexMatrix correnteCalculada;

	public Carga(ComplexMatrix potenciaNominal, double tensaoNominal, double expoente) {

		this.potenciaNominal = potenciaNominal;
		this.potenciaCalculada = potenciaNominal.copy();
		this.tensaoNominal = tensaoNominal;
		this.expoente = expoente;
		this.correnteCalculada = new ComplexMatrix(3, 1);

	}

	public ComplexMatrix getCorrente(ComplexMatrix tensaoBarra) {
		this.atualizaPotencia(tensaoBarra);
		for (int i = 0; i <= 2; i++) {
			log.debug("Entrada-> Tensao:" + tensaoBarra.getElementCopy(i, 0).abs() + "    Potencia: "
					+ this.potenciaCalculada.getElementCopy(i, 0));
			Complex correnteAux = Complex.conjugate(this.potenciaCalculada.getElementCopy(i, 0).over(
					tensaoBarra.getElementCopy(i, 0)));
			this.correnteCalculada.setElement(i, 0, correnteAux);
			log.debug("Corrente Carga - Fase " + i + " " + Complex.abs(this.correnteCalculada.getElementCopy(i, 0)));
		}

		return this.correnteCalculada;
	}

	private void atualizaPotencia(ComplexMatrix tensaoBarra) {

		for (int i = 0; i <= 2; i++) {

			// log.info("----------- Potencia Antes - Fase " + i + " " +
			// this.potenciaCalculada.getElementCopy(i,0) +
			// "  Potencia nominal " + this.potenciaNominal.getElementCopy(i,
			// 0));

			// Magnitude da tens�o na barra
			Double tensaoBarraMag = tensaoBarra.getElementCopy(i, 0).abs();

			// Raz�o entre a tens�o a magnitude da tens�o na barra e a tens�o
			// nominal
			Double razaoTensao = (tensaoBarraMag / this.tensaoNominal);

			// Potencia calculada considerando a nova tens�o na barra
			Complex potenciaCalculadaNova = this.potenciaNominal.getElementCopy(i, 0).times(
					Math.pow(razaoTensao, this.expoente));

			// Armazena o novo valor de Potencia
			this.potenciaCalculada.setElement(i, 0, potenciaCalculadaNova);

			// log.info("----------- Potencia Depois - Fase " + i + " " +
			// this.potenciaCalculada.getElementCopy(i,0) + "\n");

		}

	}

}
